SET IDENTITY_INSERT [CMS_UserSettings] ON
INSERT INTO [CMS_UserSettings] ([UserSettingsID], [UserNickName], [UserSignature], [UserMessagingNotificationEmail], [UserSettingsUserGUID], [UserSettingsUserID], [UserLogActivities], [UserWebPartToolbarEnabled], [UserWebPartToolbarPosition]) VALUES (1, N'', N'', N'', '6415b8ce-8072-4bcd-8e48-9d7178b826b7', 53, 1, 1, N'right')
INSERT INTO [CMS_UserSettings] ([UserSettingsID], [UserNickName], [UserSignature], [UserMessagingNotificationEmail], [UserSettingsUserGUID], [UserSettingsUserID], [UserLogActivities], [UserWebPartToolbarEnabled], [UserWebPartToolbarPosition]) VALUES (144, N'', N'', N'', '3758b9b5-045c-4b7d-b020-80f9b068d990', 65, 1, 1, N'right')
SET IDENTITY_INSERT [CMS_UserSettings] OFF
