SET IDENTITY_INSERT [CMS_EmailTemplate] ON
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (744, N'Blog.NotificationToModerators', N'Blogs - Notification to blog moderators', N'<html>
  <head>
    <style>
    body, td
    {
      font-size: 12px; 
      font-family: Arial;
    }
    </style>
  </head>  
  <body>
  <p>
    New blog post comment was added and now is waiting for your approval:
  </p>
  <table>
    <tr valign="top">
    <td>
    <strong>Blog post:&nbsp;</strong>
    </td>
    <td>
    <a href="{%BlogPostLink|(user)administrator|(hash)36b5558e168e922c56383acc40fe079b2efd68f857b64f97a385862abe2844de%}">{%BlogPost.DocumentName|(user)administrator|(hash)23c64a834816c24070104232dc2a62b0f2f3cec419b2142c498a82785eb6a1f1%}</a>
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Blog:&nbsp;</strong>
    </td>
    <td>
    <a href="{%BlogLink|(user)administrator|(hash)a1ddcef316152dbb4652173cd4ac8626475803af9c5499abb3924c0b4efaeaba%}">{%Blog.DocumentName|(user)administrator|(hash)88bc58749893838a46ed8a062c8e330c497bb18402c2f9e667b20f01e617de51%}</a>
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Added by:&nbsp;</strong>
    </td>
    <td>
    {% TrimSitePrefix(Comment.CommentUserName)|(user)administrator|(hash)29882b6b930a0070e0d24425c8a762a42f4a3143248da9bc918c979f06752acf%}
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Date and time:&nbsp;</strong>
    </td>
    <td>
    {%Comment.CommentDate|(user)administrator|(hash)4ae1c31aabe12a886fb8dc49d1cf7d89e337f36da43eeef3135507b23fc6d9af%}
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Text:&nbsp;</strong>
    </td>
    <td>
    {%Comment.CommentText|(user)administrator|(hash)611f104d93acfa479ed77e946f623e0e9e58868fb17e57bf545669adb95ba37c%}   
    </td>
    </tr>
  </table>    
  </body>
</html>', NULL, '744e6923-0224-4a10-b633-7922646db03d', '20120821 16:26:03', N'New blog post comment was added and now is waiting for your approval: 
Blog post:   [url={%BlogPostLink|(user)administrator|(hash)36b5558e168e922c56383acc40fe079b2efd68f857b64f97a385862abe2844de%}]{%BlogPost.DocumentName|(user)administrator|(hash)23c64a834816c24070104232dc2a62b0f2f3cec419b2142c498a82785eb6a1f1%}[/url]
Blog:   [url={%BlogLink|(user)administrator|(hash)a1ddcef316152dbb4652173cd4ac8626475803af9c5499abb3924c0b4efaeaba%}]{%Blog.DocumentName|(user)administrator|(hash)88bc58749893838a46ed8a062c8e330c497bb18402c2f9e667b20f01e617de51%}[/url]
Added by:   {% TrimSitePrefix(Comment.CommentUserName)|(user)administrator|(hash)29882b6b930a0070e0d24425c8a762a42f4a3143248da9bc918c979f06752acf%}  
Date and time:   {%Comment.CommentDate|(user)administrator|(hash)4ae1c31aabe12a886fb8dc49d1cf7d89e337f36da43eeef3135507b23fc6d9af%}  
Text:   {%Comment.CommentText|(user)administrator|(hash)611f104d93acfa479ed77e946f623e0e9e58868fb17e57bf545669adb95ba37c%}', N'Comment needs to be approved on the blog post {%BlogPost.DocumentName|(user)administrator|(hash)23c64a834816c24070104232dc2a62b0f2f3cec419b2142c498a82785eb6a1f1%}', N'', N'', N'', N'blog')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (769, N'Blog.NewCommentNotification', N'Blogs - Notification to blog owner', N'<html>
  <head>
    <style>
    body, td
    {
      font-size: 12px; 
      font-family: Arial
    }
    </style>
  </head>  
  <body>
  <p>
    New comment was added to your blog post:
  </p>
  <table>
    <tr valign="top">
    <td>
    <strong>Blog post:&nbsp;</strong>
    </td>
    <td>
    <a href="{%BlogPostLink|(user)administrator|(hash)36b5558e168e922c56383acc40fe079b2efd68f857b64f97a385862abe2844de%}">{%BlogPost.DocumentName|(user)administrator|(hash)23c64a834816c24070104232dc2a62b0f2f3cec419b2142c498a82785eb6a1f1%}</a>
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Blog:&nbsp;</strong>
    </td>
    <td>
    <a href="{%BlogLink|(user)administrator|(hash)a1ddcef316152dbb4652173cd4ac8626475803af9c5499abb3924c0b4efaeaba%}">{%Blog.DocumentName|(user)administrator|(hash)88bc58749893838a46ed8a062c8e330c497bb18402c2f9e667b20f01e617de51%}</a>
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Added by:&nbsp;</strong>
    </td>
    <td>
    {% TrimSitePrefix(Comment.CommentUserName)|(user)administrator|(hash)29882b6b930a0070e0d24425c8a762a42f4a3143248da9bc918c979f06752acf%}
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Date and time:&nbsp;</strong>
    </td>
    <td>
    {%Comment.CommentDate|(user)administrator|(hash)4ae1c31aabe12a886fb8dc49d1cf7d89e337f36da43eeef3135507b23fc6d9af%}
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Text:&nbsp;</strong>
    </td>
    <td>
    {%Comment.CommentText|(user)administrator|(hash)611f104d93acfa479ed77e946f623e0e9e58868fb17e57bf545669adb95ba37c%}
    </td>
    </tr>
  </table>    
  </body>
</html>', NULL, 'f5083a57-1355-430a-a1b9-5679e3d0e5fc', '20110905 17:11:27', N'New comment was added to your blog post:
Blog post: [url={%BlogPostLink|(user)administrator|(hash)36b5558e168e922c56383acc40fe079b2efd68f857b64f97a385862abe2844de%}]{%BlogPost.DocumentName|(user)administrator|(hash)23c64a834816c24070104232dc2a62b0f2f3cec419b2142c498a82785eb6a1f1%}[/url]
Blog: [url={%BlogLink|(user)administrator|(hash)a1ddcef316152dbb4652173cd4ac8626475803af9c5499abb3924c0b4efaeaba%}]{%Blog.DocumentName|(user)administrator|(hash)88bc58749893838a46ed8a062c8e330c497bb18402c2f9e667b20f01e617de51%}[/url]
Added by: {%TrimSitePrefix(Comment.CommentUserName)|(user)administrator|(hash)22a181423a0e1b7b5a49ab8ffd07b47435334f17bd45d91411296cdbb9281654%}
Date and time: {%Comment.CommentDate|(user)administrator|(hash)4ae1c31aabe12a886fb8dc49d1cf7d89e337f36da43eeef3135507b23fc6d9af%}
Text: {%Comment.CommentText|(user)administrator|(hash)611f104d93acfa479ed77e946f623e0e9e58868fb17e57bf545669adb95ba37c%}', N'New comment was added to your blog post {%BlogPost.DocumentName|(user)administrator|(hash)23c64a834816c24070104232dc2a62b0f2f3cec419b2142c498a82785eb6a1f1%}', N'', N'', N'', N'blog')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (768, N'Blog.NotificationToSubcribers', N'Blogs - Notification to blog post subscribers', N'<html>
  <head>
    <style>
    body, td
    {
      font-size: 12px; 
      font-family: Arial
    }
    </style>
  </head>  
  <body>
  <p>
    New comment was added to the blog post you are subscribed to:
  </p>
  <table>
    <tr valign="top">
    <td>
    <strong>Blog post:&nbsp;</strong>
    </td>
    <td>
    <a href="{%BlogPostLink|(user)administrator|(hash)36b5558e168e922c56383acc40fe079b2efd68f857b64f97a385862abe2844de%}">{%BlogPost.DocumentName|(user)administrator|(hash)23c64a834816c24070104232dc2a62b0f2f3cec419b2142c498a82785eb6a1f1%}</a>
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Blog:&nbsp;</strong>
    </td>
    <td>
    <a href="{%BlogLink|(user)administrator|(hash)a1ddcef316152dbb4652173cd4ac8626475803af9c5499abb3924c0b4efaeaba%}">{%Blog.DocumentName|(user)administrator|(hash)88bc58749893838a46ed8a062c8e330c497bb18402c2f9e667b20f01e617de51%}</a>
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Added by:&nbsp;</strong>
    </td>
    <td>
    {%TrimSitePrefix(Comment.CommentUserName)|(user)administrator|(hash)22a181423a0e1b7b5a49ab8ffd07b47435334f17bd45d91411296cdbb9281654%}
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Date and time:&nbsp;</strong>
    </td>
    <td>
    {%Comment.CommentDate|(user)administrator|(hash)4ae1c31aabe12a886fb8dc49d1cf7d89e337f36da43eeef3135507b23fc6d9af%}
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Text:&nbsp;</strong>
    </td>
    <td>
    {%Comment.CommentText|(user)administrator|(hash)611f104d93acfa479ed77e946f623e0e9e58868fb17e57bf545669adb95ba37c%}
    </td>
    </tr>
  </table>    
  <p>
        <a href="{%unsubscriptionlink|(user)administrator|(hash)3230c3e21f6b1607e56b3f829dcd57b84dd3dfd9d5ebcd0ae34ee4d093e70503%}">Click here to unsubscribe</a>
  </p>
  </body>
</html>', NULL, 'c82d3577-1657-43b5-8fd8-b3172a87b9d1', '20110905 17:30:45', N'New comment was added to the blog post you are subscribed to:
Blog post: [url={%BlogPostLink|(user)administrator|(hash)36b5558e168e922c56383acc40fe079b2efd68f857b64f97a385862abe2844de%}]{%BlogPost.DocumentName|(user)administrator|(hash)23c64a834816c24070104232dc2a62b0f2f3cec419b2142c498a82785eb6a1f1%}[/url]
Blog: [url={%BlogLink|(user)administrator|(hash)a1ddcef316152dbb4652173cd4ac8626475803af9c5499abb3924c0b4efaeaba%}]{%Blog.DocumentName|(user)administrator|(hash)88bc58749893838a46ed8a062c8e330c497bb18402c2f9e667b20f01e617de51%}[/url]
Added by: {%TrimSitePrefix(Comment.CommentUserName)|(user)administrator|(hash)22a181423a0e1b7b5a49ab8ffd07b47435334f17bd45d91411296cdbb9281654%}
Date and time: {%Comment.CommentDate|(user)administrator|(hash)4ae1c31aabe12a886fb8dc49d1cf7d89e337f36da43eeef3135507b23fc6d9af%}
Text: {%Comment.CommentText|(user)administrator|(hash)611f104d93acfa479ed77e946f623e0e9e58868fb17e57bf545669adb95ba37c%}
[url={%unsubscriptionlink|(user)administrator|(hash)3230c3e21f6b1607e56b3f829dcd57b84dd3dfd9d5ebcd0ae34ee4d093e70503%}]Click here to unsubscribe[/url]', N'New comment was added to the blog post {%BlogPost.DocumentName|(user)administrator|(hash)23c64a834816c24070104232dc2a62b0f2f3cec419b2142c498a82785eb6a1f1%}', N'', N'', N'', N'blog')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (858, N'Blogs.SubscribeConfirmation', N'Blogs - Subscription confirmation', N'<html>
	<head>
	  <style>
		BODY, TD
		{
		  font-size: 12px; 
		  font-family: arial
		}
	  </style>
	</head>	
	<body>
	<p>
	  You have been successfully subscribed to		
	<strong>Blog post</strong> {%BlogPostTitle%}.		    
	<p/>
	<p>
	<a href="{%BlogPostLink%}">Click here to view blog post on-line</a> &nbsp;
        <a href="{%UnsubscriptionLink%}">Click here to unsubscribe</a>
	</p>
	</body>
</html>', NULL, 'b90b4311-41ba-4b3e-b3fc-1b8158697775', '20111120 23:16:31', N'You have been successfully subscribed to Blog post {%BlogPostTitle%}. 
Click here to view blog post on-line:
{%BlogPostLink%}
Click here to unsubscribe:
{%UnsubscriptionLink%}', N'Blog subscription notification', N'', N'', N'', N'blogsubscription')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (859, N'blogs.subscriptionrequest', N'Blogs - Subscription request', N'<html>
	<head>
	  <style>
		BODY, TD
		{
		  font-size: 12px; 
		  font-family: arial
		}
	  </style>
	</head>	
	<body>
	<p>
	  You have requested subscription to our <strong>Blog post</strong> {%BlogPostTitle%}. Please use the following link to confirm your subscription.<br />
          <a href="{%SubscriptionLink%}">Click here to confirm the subscription</a><br /><br />
          {%if(ToInt(OptInInterval,0)>0) {"NOTE: Confirmation link will be valid for next " + OptInInterval + " hours."} |(user)administrator|(hash)e97b671f793e9b7a00c951d365aeac78ab58c0fd974457c4d44c49a7af32fe16%}
	</p>
	</body>
</html>', NULL, '7244b0c3-746e-45bc-8b5b-619e7b9601bd', '20120328 16:20:19', N'You have requested subscription to our Blog post {%BlogPostTitle%}. Please use the following link to confirm your subscription.
[url={%SubscriptionLink%}]Click here to confirm the subscription[/url].
{%if(ToInt(OptInInterval,0)>0) {"NOTE: Confirmation link will be valid for next " + OptInInterval + " hours."} |(user)administrator|(hash)e97b671f793e9b7a00c951d365aeac78ab58c0fd974457c4d44c49a7af32fe16%}', N'Subscription request', N'', N'', N'', N'blogsubscription')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (860, N'Blogs.UnsubscribeConfirmation', N'Blogs - Unsubscription confirmation', N'<html>
	<head>
	  <style>
		BODY, TD
		{
		  font-size: 12px; 
		  font-family: arial
		}
	  </style>
	</head>	
	<body>
	<p>
	  You have been successfully unsubscribed from		
	<strong>Blog post</strong> {%BlogPostTitle%}.		    
	<p/>	
	</body>
</html>', NULL, 'd40dd620-4458-4502-9578-a2cd767bfdff', '20111118 15:19:49', N'You have been successfully unsubscribed from Blog post {%BlogPostTitle%}.', N'Blog post unsubscription notification', N'', N'', N'', N'blogsubscription')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (760, N'Boards.NotificationToModerators', N'Boards - Notification to board moderators', N'<html>
  <head>
    <style>
    body, td
    {
      font-size: 12px; 
      font-family: Arial;
    }
    </style>
  </head>  
  <body>
  <p>
    New message was added and now is waiting for your approval:
  </p>
  <table>
    <tr valign="top">
    <td>
    <strong>Board:&nbsp;</strong>
    </td>
    <td>
    <a href="{%DocumentLink%}">{%Board.BoardDisplayName|(user)administrator|(hash)5fe171c3371ca1969036dcae5d193450e82a6262219b8b077a04405901ee5b31%}</a>
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Added by:&nbsp;</strong>
    </td>
    <td>
    {%TrimSitePrefix(Message.MessageUserName)|(user)administrator|(hash)dee63632502604b1b7fe81c9689000b29614c5a86b770fc676b64f74ec1befa3%}
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Date and time:&nbsp;</strong>
    </td>
    <td>
    {%Message.MessageInserted|(user)administrator|(hash)a9b55f83d55150b624ba5dc5010b84a79a1b61fd450dc882e8a815b5494bcf3c%}
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Text:&nbsp;</strong>
    </td>
    <td>
    {%Message.MessageText|(user)administrator|(hash)6f877b5934162f49970077ad2103362719cb0aa4a70a6ce2b6a8f2d69ac74dd6%}
    </td>
    </tr>
  </table>    
  </body>
</html>', NULL, '35a95893-ee26-449e-b257-edb134a67c44', '20110922 15:45:42', N'New message was added and now is waiting for your approval: 
Board:   [url={%DocumentLink%}]{%Board.BoardDsiplayName|(user)administrator|(hash)a9b78323f9fef92bdc4d1e9a2e1cdc942345adade4e6054b431ce6a1e8c65268%}[/url]
Added by:   {%TrimSitePrefix(Message.MessageUserName)|(user)administrator|(hash)dee63632502604b1b7fe81c9689000b29614c5a86b770fc676b64f74ec1befa3%}  
Date and time:   {%Message.MessageInserted|(user)administrator|(hash)a9b55f83d55150b624ba5dc5010b84a79a1b61fd450dc882e8a815b5494bcf3c%}  
Text:   {%Message.MessageText|(user)administrator|(hash)6f877b5934162f49970077ad2103362719cb0aa4a70a6ce2b6a8f2d69ac74dd6%}', N'Message needs to be approved in the board {%Board.BoardDisplayName|(user)administrator|(hash)5fe171c3371ca1969036dcae5d193450e82a6262219b8b077a04405901ee5b31%}', N'', N'', N'', N'boards')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (751, N'Boards.NotificationToSubscribers', N'Boards - Notification to board subscribers', N'<html>
  <head>
    <style>
    body, td
    {
      font-size: 12px; 
      font-family: Arial;
    }
    </style>
  </head>  
  <body>
  <p>
    New message was added to the board you are subscribed to:
  </p>
  <table>
    <tr valign="top">
    <td>
    <strong>Board:&nbsp;</strong>
    </td>
    <td>
    <a href="{%DocumentLink%}">{%Board.BoardDisplayName|(user)administrator|(hash)5fe171c3371ca1969036dcae5d193450e82a6262219b8b077a04405901ee5b31%}</a>
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Added by:&nbsp;</strong>
    </td>
    <td>
    {%TrimSitePrefix(Message.MessageUserName)|(user)administrator|(hash)dee63632502604b1b7fe81c9689000b29614c5a86b770fc676b64f74ec1befa3%}
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Date and time:&nbsp;</strong>
    </td>
    <td>
    {%Message.MessageInserted|(user)administrator|(hash)a9b55f83d55150b624ba5dc5010b84a79a1b61fd450dc882e8a815b5494bcf3c%}
    </td>
    </tr>
    <tr valign="top">
    <td>
    <strong>Text:&nbsp;</strong>
    </td>
    <td>
    {%Message.MessageText|(user)administrator|(hash)6f877b5934162f49970077ad2103362719cb0aa4a70a6ce2b6a8f2d69ac74dd6%}
    </td>
    </tr>
  </table>    
  <p>
        <a href="{%UnsubscriptionLink%}">Click here to unsubscribe</a>
  </p>
  </body>
</html>', NULL, '856a1cbf-6340-4c20-b7da-ac32810b8546', '20110922 15:46:21', N'New message was added to the board you are subscribed to: 
Board:   [url={%DocumentLink%}"]{%Board.BoardDisplayName|(user)administrator|(hash)5fe171c3371ca1969036dcae5d193450e82a6262219b8b077a04405901ee5b31%}[/url]
Added by:   {%TrimSitePrefix(Message.MessageUserName)|(user)administrator|(hash)dee63632502604b1b7fe81c9689000b29614c5a86b770fc676b64f74ec1befa3%}  
Date and time:   {%Message.MessageInserted|(user)administrator|(hash)a9b55f83d55150b624ba5dc5010b84a79a1b61fd450dc882e8a815b5494bcf3c%}  
Text:   {%Message.MessageText|(user)administrator|(hash)6f877b5934162f49970077ad2103362719cb0aa4a70a6ce2b6a8f2d69ac74dd6%}  
[url={%UnsubscriptionLink%}]Click here to unsubscribe[/url]', N'New message was added to the board {%Board.BoardDisplayName|(user)administrator|(hash)5fe171c3371ca1969036dcae5d193450e82a6262219b8b077a04405901ee5b31%}', N'', N'', N'', N'boards')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (862, N'Boards.SubscribeConfirmation', N'Boards - Subscription confirmation', N'<html>
	<head>
	  <style>
		BODY, TD
		{
		  font-size: 12px; 
		  font-family: arial
		}
	  </style>
	</head>	
	<body>
	<p>
	  You have been successfully subscribed to		
	<strong>Message board</strong> {%Board.BoardDisplayName|(user)administrator|(hash)5fe171c3371ca1969036dcae5d193450e82a6262219b8b077a04405901ee5b31%}.		    
	<p/>
	<p>
	<a href="{%DocumentLink%}">Click here to view message board on-line</a> &nbsp;
        <a href="{%UnsubscriptionLink%}">Click here to unsubscribe</a>
	</p>
	</body>
</html>', NULL, '6422a9bd-95b0-41cc-9ef7-68e1e93be2a8', '20111124 22:39:44', N'You have been successfully subscribed to Message board {%Board.BoardDisplayName|(user)administrator|(hash)5fe171c3371ca1969036dcae5d193450e82a6262219b8b077a04405901ee5b31%}.
[url={%BlogPostLink%}]Click here to view message board on-line[/url]
[url={%UnsubscriptionLink%}] Click here to unsubscribe[/url]', N'Board subscription notification', N'', N'', N'', N'boardssubscription')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (863, N'Boards.subscriptionrequest', N'Boards - Subscription request', N'<html>
	<head>
	  <style>
		BODY, TD
		{
		  font-size: 12px; 
		  font-family: arial
		}
	  </style>
	</head>	
	<body>
	<p>
	  You have requested subscription to our <strong>Message board</strong> {%Board.BoardDisplayName|(user)administrator|(hash)5fe171c3371ca1969036dcae5d193450e82a6262219b8b077a04405901ee5b31%}. Please use the following link to confirm your subscription.<br />
          <a href="{%SubscriptionLink%}">Click here to confirm the subscription</a><br /><br />
          {%if(ToInt(OptInInterval,0)>0) {"NOTE: Confirmation link will be valid for next " + OptInInterval + " hours."} |(user)administrator|(hash)e97b671f793e9b7a00c951d365aeac78ab58c0fd974457c4d44c49a7af32fe16%}
	</p>
	</body>
</html>', NULL, 'fe8ae59a-5f07-46f1-8856-c13a4412f360', '20120328 16:21:38', N'You have requested subscription to our Message board {%Board.BoardDisplayName|(user)administrator|(hash)5fe171c3371ca1969036dcae5d193450e82a6262219b8b077a04405901ee5b31%}. Please use the following link to confirm your subscription.
[url={%SubscriptionLink%}]Click here to confirm the subscription[/url].
{%if(ToInt(OptInInterval,0)>0) {"NOTE: Confirmation link will be valid for next " + OptInInterval + " hours."} |(user)administrator|(hash)e97b671f793e9b7a00c951d365aeac78ab58c0fd974457c4d44c49a7af32fe16%}', N'Subscription request', N'', N'', N'', N'boardssubscription')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (864, N'Boards.UnsubscribeConfirmation', N'Boards - Unsubscription confirmation', N'<html>
	<head>
	  <style>
		BODY, TD
		{
		  font-size: 12px; 
		  font-family: arial
		}
	  </style>
	</head>	
	<body>
	<p>
	  You have been successfully unsubscribed from		
	<strong>Message board</strong> {%Board.BoardDisplayName|(user)administrator|(hash)5fe171c3371ca1969036dcae5d193450e82a6262219b8b077a04405901ee5b31%}.		    
	<p/>	
	</body>
</html>', NULL, 'e5b8609e-94c6-4096-8aa3-f37fa4b7d320', '20120328 16:22:08', N'You have been successfully unsubscribed from Message board {%Board.BoardDisplayName|(user)administrator|(hash)5fe171c3371ca1969036dcae5d193450e82a6262219b8b077a04405901ee5b31%}.', N'Message board unsubscription notification', N'', N'', N'', N'boardssubscription')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (705, N'BookingEvent.Invitation', N'Booking system - Event invitation', N'<html><head></head><body>
<p>Hello,</p>
<p>Thank you for your registration for event {%EventName|(encode)false%}. This is an e-mail confirmation that you have been registered. Below, you can find event details:</p>
<p><strong>Event: {%EventName|(encode)false%}</strong></p>
<p><em>{%EventSummary|(encode)false%}</em></p>
<p>{%EventDetails|(encode)false%}</p>
<p><strong>Location:</strong><br />
{%EventLocation|(encode)false%}</p>
<p><strong>Date:</strong><br />
{%EventDateString|(encode)false%}</p>
</body>
</html>', NULL, 'eb37ce02-7853-4f91-bbd1-127597ebce66', '20110717 12:06:11', N'Hello,
Thank you for your registration for event {%EventName|(encode)false%}. This is an e-mail confirmation that you have been registered. Below, you can find event details:
Event: {%EventName|(encode)false%}
{%EventSummary|(encode)false%}
{%EventDetails|(encode)false%}
Location:
{%EventLocation|(encode)false%}
Date:
{%EventDateString|(encode)false%}', N'', N'', N'', N'', N'bookingevent')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (843, N'Ecommerce.EproductExpirationNotification', N'E-commerce - E-product expiration notification', N'You have bought the folowing e-products, please download them until their download links expire. Once the download link expires, you won''t be able to download the file.
<br />
{%EproductsTable.ApplyTransformation("Ecommerce.Transformations.Order_EproductsTable")|(user)administrator|(hash)58832fc072ffc268445d28f6b9aa52f835c7ad6edef5369bb1cc2979e81371a3%}
<br />
You can download your e-products also from My profile -> Orders section until their expiration.
<br />
This is an automatic reminder, please do not respond.
<br />
Thank you.', NULL, '26c89400-44e4-4208-92ba-cdd7d6bd407e', '20110907 17:14:42', N'You have bought the folowing e-products, please download them until their download links expire. Once the download link expires, you won''t be able to download the file.
{%EproductsTable.ApplyTransformation("Ecommerce.Transformations.Order_EproductsTable")|(user)administrator|(hash)58832fc072ffc268445d28f6b9aa52f835c7ad6edef5369bb1cc2979e81371a3%}
You can download your e-products also from My profile -> Orders section until their expiration.
This is an automatic reminder, please do not respond.
Thank you.', N'', N'', N'', N'', N'ecommerceeproductexpiration')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (167, N'Ecommerce.OrderNotificationToAdmin', N'E-commerce - Order notification to administrator', N'<html><head></head><body>
<table cellspacing="0" cellpadding="5" bordercolor="black" border="1" width="600">
    <tbody>
        <tr>
            <td height="50" valign="bottom" colspan="2">
            <table height="100%" width="100%">
                <tbody>
                    <tr>
                        <td style="text-align: left; vertical-align: bottom;"><span style="font-size: 18pt;">New order</span></td>
                        <td style="text-align: center; vertical-align: middle;"><span style="font-family: Garamond,Times,serif; font-size: 24pt; font-style: italic;">Company logo</span></td>
                    </tr>
                </tbody>
            </table>
            </td>
        </tr>
        <tr>
            <td style="text-align: left;"><br />
            <table width="100%">
                <tbody>
                    <tr>
                        <td valign="bottom" style="text-align: left;"><strong>Invoice number:</strong></td>
                        <td style="text-align: right; padding-right: 10px;">{%Order.OrderInvoiceNumber|(user)administrator|(hash)a95e0a748a38406f0e49d6d4599317a54b5b84ce2a517e44102fbbe141caf5b9%}</td>
                    </tr>
                </tbody>
            </table>
            </td>
            <td style="text-align: left;"><br />
            <table width="100%">
                <tbody>
                    <tr>
                        <td valign="bottom" style="text-align: left;"><strong>Order date:</strong></td>
                        <td style="text-align: right; padding-right: 10px;">{%Format(Order.OrderDate, "{0:d}")|(user)administrator|(hash)917baa66d3079eb4259d92dd9ca858f7c39135d9145fa30d075260fc4fbb87fb%}</td>
                    </tr>
                    <tr>
                        <td valign="bottom" style="text-align: left;"><strong>Order status:</strong></td>
                        <td style="text-align: right; padding-right: 10px;">{%GetResourceString(OrderStatus.StatusDisplayName)|(user)administrator|(hash)70418ac3e69df3f93816b61326efc22a135f8ff5e5a488c0e92f9dd2332898e5%} </td>
                    </tr>
                </tbody>
            </table>
            </td>
        </tr>
        <tr>
            <td width="50%" style="text-align: left; vertical-align: top;"><strong>Supplier</strong>
            <br />
            <br />
            <table>
                <tbody>
                    <tr>
                        <td>Company address</td>
                    </tr>
                </tbody>
            </table>
            </td>
            <td width="50%" style="text-align: left; vertical-align: top;"><span style="font-weight: bold;">Customer</span><br />
            <br />
            {%BillingAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)32278747a390cbf184b898b50cb9cecba5351e74f1b21f32c9e74499509c89e7%}
            <br />
            <strong>Company address:</strong>
            {%CompanyAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)a7e59664f6adcb4279bc33a0c3b28ca81249e4289ec4c4b6220d7deed02bd77a%}
            </td>
        </tr>
        <tr>
            <td colspan="2">
            <table width="100%">
                <tbody>
                    <tr>
                        <td style="text-align: left;"><span style="font-weight: bold;">Payment option</span></td>
                    </tr>
                    <tr>
                        <td style="text-align: center;">{%GetResourceString(PaymentOption.PaymentOptionDisplayName)|(user)administrator|(hash)4f0bbe11b052df9335eb5b9de7fac8caee44420a2a949612b6d2dc26534575ba%}</td>
                    </tr>
                </tbody>
            </table>
            </td>
        </tr>
        <tr>
            <td colspan="2">
            <table width="100%">
                <tbody>
                    <tr>
                        <td style="text-align: left;"><span style="font-weight: bold;">Shipping option</span></td>
                    </tr>
                    <tr>
                        <td style="text-align: center;">{%GetResourceString(ShippingOption.ShippingOptionDisplayName)|(user)administrator|(hash)3af59432f5a90940a17c77bd023e11435d578b1245f74b76be49313e4ca562f9%}</td>
                    </tr>
                </tbody>
            </table>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: left;">
            {%ContentTable.ApplyTransformation("Ecommerce.Transformations.Order_ContentTable", "Ecommerce.Transformations.Order_ContentTableHeader", "Ecommerce.Transformations.Order_ContentTableFooter")|(user)administrator|(hash)9e56a53dbd5bf3e32802ce8dae1042f123cb7719fa66db3750e7c586c3789b1d%}
            <hr size="1" />
            <div style="text-align: right;">
            <table cellpadding="5" style="text-align: left;">
                <tbody>
                    <tr>
                        <td><strong>Total shipping:</strong></td>
                        <td style="text-align: right; padding-right: 0px;"><strong>{%TotalShipping.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)fe4747867dd60dc8b40000eca1069ed43b20b675882946895074c47a112052c1%}</strong></td>
                    </tr>
                    <tr>
                        <td><strong>Total price:</strong></td>
                        <td style="text-align: right; padding-right: 0px;"><strong>{%TotalPrice.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)b63ec0b2ccb82b700c64d1b50b3a5336a74e5d6727a747719e1ec39698fb445d%}</strong></td>
                    </tr>
                    <tr>
                        <td style="vertical-align: top;"><strong>Tax summary:</strong></td>
                        <td style="text-align: right; padding-right: 0px;">{%ContentTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)eda185fc7fac9ede5dc2a686ec381a205bada144d7e116e1b50508fe3f11006b%}</td>
                    </tr>
                </tbody>
            </table>
            </div>
            <div style="height: 120px;">&nbsp;</div>
            </td>
        </tr>
        <tr>
            <td colspan="2">
            <table width="100%">
                <tbody>
                    <tr>
                        <td style="text-align: left;"><span style="font-weight: bold;">Order note</span></td>
                    </tr>
                    <tr>
                        <td style="text-align: left;">{%Order.OrderNote|(encode)|(user)administrator|(hash)7aa262f6abfeea5a9136a093c575725fc1ead41635b57727e1ffc1b1b96f3fa8%}</td>
                    </tr>
                </tbody>
            </table>
            </td>
        </tr>
    </tbody>
</table>
<div style="padding-top-10px;">{%NewOrderLink%}</div>
</body>
</html>', NULL, 'f49163f2-32c3-4c7b-ab1b-c128d621c02f', '20110930 08:13:28', N'New order Company logo 
 
Invoice number: {%Order.OrderInvoiceNumber|(user)administrator|(hash)a95e0a748a38406f0e49d6d4599317a54b5b84ce2a517e44102fbbe141caf5b9%}
 
Order date: {%Format(Order.OrderDate, "{0:d}")|(user)administrator|(hash)917baa66d3079eb4259d92dd9ca858f7c39135d9145fa30d075260fc4fbb87fb%}
Order status: {%GetResourceString(OrderStatus.StatusDisplayName)|(user)administrator|(hash)70418ac3e69df3f93816b61326efc22a135f8ff5e5a488c0e92f9dd2332898e5%} 
 
Supplier 
Company address 
Customer 
{%BillingAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)32278747a390cbf184b898b50cb9cecba5351e74f1b21f32c9e74499509c89e7%}
Company address: {%CompanyAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)a7e59664f6adcb4279bc33a0c3b28ca81249e4289ec4c4b6220d7deed02bd77a%}
Payment option  
{%GetResourceString(PaymentOption.PaymentOptionDisplayName)|(user)administrator|(hash)4f0bbe11b052df9335eb5b9de7fac8caee44420a2a949612b6d2dc26534575ba%}
 
Shipping option  
{%GetResourceString(ShippingOption.ShippingOptionDisplayName)|(user)administrator|(hash)3af59432f5a90940a17c77bd023e11435d578b1245f74b76be49313e4ca562f9%}
 
{%ContentTable.ApplyTransformation("Ecommerce.Transformations.Order_ContentTable", "Ecommerce.Transformations.Order_ContentTableHeader", "Ecommerce.Transformations.Order_ContentTableFooter")|(user)administrator|(hash)9e56a53dbd5bf3e32802ce8dae1042f123cb7719fa66db3750e7c586c3789b1d%}
--------------------------------------------------------------------------------
Total shipping: {%TotalShipping.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)fe4747867dd60dc8b40000eca1069ed43b20b675882946895074c47a112052c1%}
Total price: {%TotalPrice.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)b63ec0b2ccb82b700c64d1b50b3a5336a74e5d6727a747719e1ec39698fb445d%}
Tax summary: {%ContentTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)eda185fc7fac9ede5dc2a686ec381a205bada144d7e116e1b50508fe3f11006b%}
  
Order note  
{%Order.OrderNote|(encode)|(user)administrator|(hash)7aa262f6abfeea5a9136a093c575725fc1ead41635b57727e1ffc1b1b96f3fa8%}', N'', N'', N'', N'', N'ecommerce')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (166, N'Ecommerce.OrderNotificationToCustomer', N'E-commerce - Order notification to customer', N'<html><head></head><body>
<p>Thank you for your order. Below you can find the order details.</p>
<table width="600" cellspacing="0" cellpadding="5" bordercolor="black" border="1">
    <tbody>
        <tr>
            <td height="50" valign="bottom" colspan="2">
            <table height="100%" width="100%">
                <tbody>
                    <tr>
                        <td style="text-align: left; vertical-align: bottom;"><span style="font-size: 18pt;">Your order</span></td>
                        <td style="text-align: center; vertical-align: middle;"><span style="font-family: Garamond,Times,serif; font-size: 24pt; font-style: italic;">Company logo</span></td>
                    </tr>
                </tbody>
            </table>
            </td>
        </tr>
        <tr>
            <td style="text-align: left;"><br />
            <table width="100%">
                <tbody>
                    <tr>
                        <td valign="bottom" style="text-align: left;"><strong>Invoice number:</strong></td>
                        <td style="text-align: right; padding-right: 10px;">{%Order.OrderInvoiceNumber|(user)administrator|(hash)a95e0a748a38406f0e49d6d4599317a54b5b84ce2a517e44102fbbe141caf5b9%}</td>
                    </tr>
                </tbody>
            </table>
            </td>
            <td style="text-align: left;"><br />
            <table width="100%">
                <tbody>
                    <tr>
                        <td valign="bottom" style="text-align: left;"><strong>Order date:</strong></td>
                        <td style="text-align: right; padding-right: 10px;">{%Format(Order.OrderDate, "{0:d}")|(user)administrator|(hash)917baa66d3079eb4259d92dd9ca858f7c39135d9145fa30d075260fc4fbb87fb%}</td>
                    </tr>
                    <tr>
                        <td valign="bottom" style="text-align: left;"><strong>Order status:</strong></td>
                        <td style="text-align: right; padding-right: 10px;">{%GetResourceString(OrderStatus.StatusDisplayName)|(user)administrator|(hash)70418ac3e69df3f93816b61326efc22a135f8ff5e5a488c0e92f9dd2332898e5%}</td>
                    </tr>
                </tbody>
            </table>
            </td>
        </tr>
        <tr>
            <td width="50%" style="text-align: left; vertical-align: top;"><strong>Supplier</strong><br />
            <br />
            <table>
                <tbody>
                    <tr>
                        <td>Company address</td>
                    </tr>
                </tbody>
            </table>
            </td>
            <td width="50%" style="text-align: left; vertical-align: top;"><span style="font-weight: bold;">Customer</span><br />
            <br />
            {%BillingAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)32278747a390cbf184b898b50cb9cecba5351e74f1b21f32c9e74499509c89e7%}
            <br />
            <strong>Company address:</strong>
            {%CompanyAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)a7e59664f6adcb4279bc33a0c3b28ca81249e4289ec4c4b6220d7deed02bd77a%}
            </td>
        </tr>
        <tr>
            <td colspan="2">
            <table width="100%">
                <tbody>
                    <tr>
                        <td style="text-align: left;"><span style="font-weight: bold;">Payment option</span></td>
                    </tr>
                    <tr>
                        <td style="text-align: center;">{%GetResourceString(PaymentOption.PaymentOptionDisplayName)|(user)administrator|(hash)4f0bbe11b052df9335eb5b9de7fac8caee44420a2a949612b6d2dc26534575ba%}</td>
                    </tr>
                </tbody>
            </table>
            </td>
        </tr>
        <tr>
            <td colspan="2">
            <table width="100%">
                <tbody>
                    <tr>
                        <td style="text-align: left;"><span style="font-weight: bold;">Shipping option</span></td>
                    </tr>
                    <tr>
                        <td style="text-align: center;">{%GetResourceString(ShippingOption.ShippingOptionDisplayName)|(user)administrator|(hash)3af59432f5a90940a17c77bd023e11435d578b1245f74b76be49313e4ca562f9%}</td>
                    </tr>
                </tbody>
            </table>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: left;">{%ContentTable.ApplyTransformation("Ecommerce.Transformations.Order_ContentTable", "Ecommerce.Transformations.Order_ContentTableHeader", "Ecommerce.Transformations.Order_ContentTableFooter")|(user)administrator|(hash)9e56a53dbd5bf3e32802ce8dae1042f123cb7719fa66db3750e7c586c3789b1d%}<hr size="1" />
            <div style="text-align: right;">
            <table cellpadding="5" style="text-align: left;">
                <tbody>
                    <tr>
                        <td><strong>Total shipping:</strong></td>
                        <td style="text-align: right; padding-right: 0px;"><strong>{%TotalShipping.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)fe4747867dd60dc8b40000eca1069ed43b20b675882946895074c47a112052c1%}</strong></td>
                    </tr>
                    <tr>
                        <td><strong>Total price:</strong></td>
                        <td style="text-align: right; padding-right: 0px;"><strong>{%TotalPrice.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)b63ec0b2ccb82b700c64d1b50b3a5336a74e5d6727a747719e1ec39698fb445d%}</strong></td>
                    </tr>
                    <tr>
                        <td style="vertical-align: top;"><strong>Tax summary:</strong></td>
                        <td style="text-align: right; padding-right: 0px;">{%ContentTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)eda185fc7fac9ede5dc2a686ec381a205bada144d7e116e1b50508fe3f11006b%}</td>
                    </tr>
                </tbody>
            </table>
            </div>
            <div style="height: 120px;">&nbsp;</div>
            </td>
        </tr>
        <tr>
            <td colspan="2">
            <table width="100%">
                <tbody>
                    <tr>
                        <td style="text-align: left;"><span style="font-weight: bold;">Order note</span></td>
                    </tr>
                    <tr>
                        <td style="text-align: left;">{%Order.OrderNote|(encode)|(user)administrator|(hash)7aa262f6abfeea5a9136a093c575725fc1ead41635b57727e1ffc1b1b96f3fa8%}</td>
                    </tr>
                </tbody>
            </table>
            </td>
        </tr>
    </tbody>
</table>
</body>
</html>', NULL, '674d1b85-ce19-40bd-b2df-166a5891090a', '20110930 08:14:08', N'Thank you for your order!
Your order Company logo
 
Invoice number: {%Order.OrderInvoiceNumber|(user)administrator|(hash)a95e0a748a38406f0e49d6d4599317a54b5b84ce2a517e44102fbbe141caf5b9%}
 
Order date: {%Format(Order.OrderDate, "{0:d}")|(user)administrator|(hash)917baa66d3079eb4259d92dd9ca858f7c39135d9145fa30d075260fc4fbb87fb%}
Order status: {%GetResourceString(OrderStatus.StatusDisplayName)|(user)administrator|(hash)70418ac3e69df3f93816b61326efc22a135f8ff5e5a488c0e92f9dd2332898e5%}
 
Supplier
Company address
 Customer
{%BillingAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)32278747a390cbf184b898b50cb9cecba5351e74f1b21f32c9e74499509c89e7%}
Company address: {%CompanyAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)a7e59664f6adcb4279bc33a0c3b28ca81249e4289ec4c4b6220d7deed02bd77a%}
Payment option
{%GetResourceString(PaymentOption.PaymentOptionDisplayName)|(user)administrator|(hash)4f0bbe11b052df9335eb5b9de7fac8caee44420a2a949612b6d2dc26534575ba%}
Shipping option  
{%GetResourceString(ShippingOption.ShippingOptionDisplayName)|(user)administrator|(hash)3af59432f5a90940a17c77bd023e11435d578b1245f74b76be49313e4ca562f9%}
 
{%ContentTable.ApplyTransformation("Ecommerce.Transformations.Order_ContentTable", "Ecommerce.Transformations.Order_ContentTableHeader", "Ecommerce.Transformations.Order_ContentTableFooter")|(user)administrator|(hash)9e56a53dbd5bf3e32802ce8dae1042f123cb7719fa66db3750e7c586c3789b1d%}
--------------------------------------------------------------------------------
Total shipping: {%TotalShipping.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)fe4747867dd60dc8b40000eca1069ed43b20b675882946895074c47a112052c1%}
Total price: {%TotalPrice.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)b63ec0b2ccb82b700c64d1b50b3a5336a74e5d6727a747719e1ec39698fb445d%}
Tax summary: {%ContentTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)eda185fc7fac9ede5dc2a686ec381a205bada144d7e116e1b50508fe3f11006b%}
  
Order note  
{%Order.OrderNote|(encode)|(user)administrator|(hash)7aa262f6abfeea5a9136a093c575725fc1ead41635b57727e1ffc1b1b96f3fa8%}', N'', N'', N'', N'', N'ecommerce')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (706, N'Ecommerce.OrderPaymentNotificationToAdmin', N'E-commerce - Order payment notification to administrator', N'<html>
<head>
</head>
<body>
<p>Payment for the order below received.</p>
<table cellspacing="0" cellpadding="5" border="1" bordercolor="black" width="600px">
  <tr>
    <td colspan="2" valign="bottom" height="50">
      <table width="100%" height="100%">
        <tr>
          <td style="text-align: left; vertical-align: bottom;"
            <span style="font-size: 18pt">New order</span>
          </td>
          <td style="text-align: center; vertical-align: middle;">
            <span style="font-family: Garamond, Times, serif; font-size: 24pt; font-style: italic;">Company logo</span>
          </td>
        </tr>
      </table> 
    </td>
  </tr>
  <tr>
    <td style="text-align: left">    
      <br />
      <table width="100%">
        <tr>
          <td style="text-align: left;" valign="bottom"> 
            <strong>Invoice number:</strong>
          </td>
          <td style="text-align: right; padding-right: 10px">
            {%Order.OrderInvoiceNumber|(user)administrator|(hash)a95e0a748a38406f0e49d6d4599317a54b5b84ce2a517e44102fbbe141caf5b9%}
          </td>
        </tr>
      </table> 
      <br />
    </td>
    <td style="text-align: left">    
      <br />
      <table width="100%">
        <tr>
          <td style="text-align: left;" valign="bottom"> 
            <strong>Order date:</strong>
          </td>
          <td style="text-align: right; padding-right: 10px">
            {%Format(Order.OrderDate, "{0:d}")|(user)administrator|(hash)917baa66d3079eb4259d92dd9ca858f7c39135d9145fa30d075260fc4fbb87fb%}
          </td>
        </tr>
  <tr>
          <td style="text-align: left;" valign="bottom"> 
            <strong>Order status:</strong>
          </td>
          <td style="text-align: right; padding-right: 10px">
            {%GetResourceString(OrderStatus.StatusDisplayName)|(user)administrator|(hash)70418ac3e69df3f93816b61326efc22a135f8ff5e5a488c0e92f9dd2332898e5%}
          </td>
        </tr>
      </table>  
      <br />
    </td>
  </tr>
  <tr>
    <td style="text-align: left; vertical-align: top" width="50%">
      <strong>Supplier</strong>
      <br/>
      <br/>
      <table>
        <tr>
          <td>
            Company address
          </td>
        </tr>
      </table>
      <br />
    </td>
    <td style="text-align: left; vertical-align: top" width="50%">
      <span style="font-weight: bold"> Customer </span><br />
      <br />
        {%BillingAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)32278747a390cbf184b898b50cb9cecba5351e74f1b21f32c9e74499509c89e7%}
      <br />
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <table width="100%">
        <tr>
          <td style="text-align: left">
            <span style="font-weight: bold"> Payment option </span>
          </td>
        </tr>
        <tr>
          <td style="text-align: center">
            {%GetResourceString(PaymentOption.PaymentOptionDisplayName)|(user)administrator|(hash)4f0bbe11b052df9335eb5b9de7fac8caee44420a2a949612b6d2dc26534575ba%}
          </td>
        </tr>
      </table> 
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <table width="100%">
        <tr>
          <td style="text-align: left">
            <span style="font-weight: bold"> Shipping option </span>
          </td>
        </tr>
        <tr>
          <td style="text-align: center">
            {%GetResourceString(ShippingOption.ShippingOptionDisplayName)|(user)administrator|(hash)3af59432f5a90940a17c77bd023e11435d578b1245f74b76be49313e4ca562f9%}
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td style="text-align: left" colspan="2">
      {%ContentTable.ApplyTransformation("Ecommerce.Transformations.Order_ContentTable", "Ecommerce.Transformations.Order_ContentTableHeader", "Ecommerce.Transformations.Order_ContentTableFooter")|(user)administrator|(hash)9e56a53dbd5bf3e32802ce8dae1042f123cb7719fa66db3750e7c586c3789b1d%}
      <hr size="1" />
      <div style="text-align: right;">
      <table style="text-align: left;" cellpadding="5">
  <tr>
    <td><strong>Total shipping:</strong></td>
          <td style="text-align: right; padding-right: 0px;">
            <strong>{%TotalShipping.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)fe4747867dd60dc8b40000eca1069ed43b20b675882946895074c47a112052c1%}</strong>
          </td>
  </tr>
  <tr>
    <td style="vertical-align:top;"><strong>Shipping tax summary:</strong></td>
          <td style="text-align: right; padding-right: 0px;">
            {%ShippingTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)1078a0131c3dec03c7671cf956a60b4411645e70b2bd4793372192c9b9fd3aa0%}
          </td>
  </tr>  
  <tr>
    <td><strong>Total price:</strong></td>
          <td style="text-align: right; padding-right: 0px;">
            <strong>{%TotalPrice.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)b63ec0b2ccb82b700c64d1b50b3a5336a74e5d6727a747719e1ec39698fb445d%}</strong>
          </td>
  </tr>
  <tr>
    <td style="vertical-align:top;"><strong>Tax summary:</strong></td>
          <td style="text-align: right; padding-right: 0px;">
            {%ContentTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)eda185fc7fac9ede5dc2a686ec381a205bada144d7e116e1b50508fe3f11006b%}
          </td>
  </tr>
      </table>
      </div>
      <div style="height: 120px;">&nbsp;</div>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <table width="100%">
        <tr>
          <td style="text-align: left">
            <span style="font-weight: bold"> Order note </span>
          </td>
        </tr>
        <tr>
          <td style="text-align: left">
            {%Order.OrderNote|(encode)|(user)administrator|(hash)7aa262f6abfeea5a9136a093c575725fc1ead41635b57727e1ffc1b1b96f3fa8%}
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<div style="padding-top-10px;">
   {%NewOrderLink%}
</div>
</body>
</html>', NULL, '7b821e4a-d695-42a7-85f2-1ca14c208953', '20110930 08:10:59', N'Payment for the order below received.
New order  Company logo  
 
Invoice number:  {%Order.OrderInvoiceNumber|(user)administrator|(hash)a95e0a748a38406f0e49d6d4599317a54b5b84ce2a517e44102fbbe141caf5b9%} 
 
Order date:  {%Format(Order.OrderDate, "{0:d}")|(user)administrator|(hash)917baa66d3079eb4259d92dd9ca858f7c39135d9145fa30d075260fc4fbb87fb%}  
Order status:  {%GetResourceString(OrderStatus.StatusDisplayName)|(user)administrator|(hash)70418ac3e69df3f93816b61326efc22a135f8ff5e5a488c0e92f9dd2332898e5%}  
 
Supplier 
Company address  
Customer 
{%BillingAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)32278747a390cbf184b898b50cb9cecba5351e74f1b21f32c9e74499509c89e7%} 
 
Payment option  
{%GetResourceString(PaymentOption.PaymentOptionDisplayName)|(user)administrator|(hash)4f0bbe11b052df9335eb5b9de7fac8caee44420a2a949612b6d2dc26534575ba%}  
 
Shipping option  
{%GetResourceString(ShippingOption.ShippingOptionDisplayName)|(user)administrator|(hash)3af59432f5a90940a17c77bd023e11435d578b1245f74b76be49313e4ca562f9%}
 
{%ContentTable.ApplyTransformation("Ecommerce.Transformations.Order_ContentTable", "Ecommerce.Transformations.Order_ContentTableHeader", "Ecommerce.Transformations.Order_ContentTableFooter")|(user)administrator|(hash)9e56a53dbd5bf3e32802ce8dae1042f123cb7719fa66db3750e7c586c3789b1d%}
--------------------------------------------------------------------------------
Total shipping: {%TotalShipping.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)fe4747867dd60dc8b40000eca1069ed43b20b675882946895074c47a112052c1%}
Shipping tax summary:
{%ShippingTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)1078a0131c3dec03c7671cf956a60b4411645e70b2bd4793372192c9b9fd3aa0%}
Total price: {%TotalPrice.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)b63ec0b2ccb82b700c64d1b50b3a5336a74e5d6727a747719e1ec39698fb445d%}
Tax summary: 
{%ContentTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)eda185fc7fac9ede5dc2a686ec381a205bada144d7e116e1b50508fe3f11006b%}
  
Order note  
{%Order.OrderNote|(encode)|(user)administrator|(hash)7aa262f6abfeea5a9136a093c575725fc1ead41635b57727e1ffc1b1b96f3fa8%}', N'', N'', N'', N'', N'ecommerce')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (707, N'Ecommerce.OrderPaymentNotificationToCustomer', N'E-commerce - Order payment notification to customer', N'<html>
<head>
</head>
<body>
<p>We have received your payment for the order bellow:</p>
<table cellspacing="0" cellpadding="5" border="1" bordercolor="black" width="600px">
  <tr>
    <td colspan="2" valign="bottom" height="50">
      <table width="100%" height="100%">
        <tr>
          <td style="text-align: left; vertical-align: bottom;"
            <span style="font-size: 18pt">Your order</span>
          </td>
          <td style="text-align: center; vertical-align: middle;">
            <span style="font-family: Garamond, Times, serif; font-size: 24pt; font-style: italic;">Company logo</span>
          </td>
        </tr>
      </table> 
    </td>
  </tr>
  <tr>
    <td style="text-align: left">    
      <br />
      <table width="100%">
        <tr>
          <td style="text-align: left;" valign="bottom"> 
            <strong>Invoice number:</strong>
          </td>
          <td style="text-align: right; padding-right: 10px">
            {%Order.OrderInvoiceNumber|(user)administrator|(hash)a95e0a748a38406f0e49d6d4599317a54b5b84ce2a517e44102fbbe141caf5b9%}
          </td>
        </tr>
      </table> 
      <br />
    </td>
    <td style="text-align: left">    
      <br />
      <table width="100%">
        <tr>
          <td style="text-align: left;" valign="bottom"> 
            <strong>Order date:</strong>
          </td>
          <td style="text-align: right; padding-right: 10px">
            {%Format(Order.OrderDate, "{0:d}"|(user)administrator|(hash)69848a7f7e3c881f21776bf752c4452f566cb9a2e10ce655aef1fd287a7e2146%}
          </td>
        </tr>
  <tr>
          <td style="text-align: left;" valign="bottom"> 
            <strong>Order status:</strong>
          </td>
          <td style="text-align: right; padding-right: 10px">
            {%GetResourceString(OrderStatus.StatusDisplayName)|(user)administrator|(hash)70418ac3e69df3f93816b61326efc22a135f8ff5e5a488c0e92f9dd2332898e5%} 
          </td>
        </tr>
      </table>  
      <br />
    </td>
  </tr>
  <tr>
    <td style="text-align: left; vertical-align: top" width="50%">
      <strong>Supplier</strong>
      <br/>
      <br/>
      <table>
        <tr>
          <td>
            Company address
          </td>
        </tr>
      </table>
      <br />
    </td>
    <td style="text-align: left; vertical-align: top" width="50%">
      <span style="font-weight: bold"> Customer </span><br />
      <br />
        {%BillingAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)32278747a390cbf184b898b50cb9cecba5351e74f1b21f32c9e74499509c89e7%}
      <br />
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <table width="100%">
          <tbody>
              <tr>
                  <td style="text-align: left;"><span style="font-weight: bold;">Payment option</span></td>
              </tr>
              <tr>
                  <td style="text-align: center;">{%GetResourceString(PaymentOption.PaymentOptionDisplayName)|(user)administrator|(hash)4f0bbe11b052df9335eb5b9de7fac8caee44420a2a949612b6d2dc26534575ba%}</td>
              </tr>
          </tbody>
      </table>
    </td>    
  </tr>
  <tr>
    <td colspan="2">
      <table width="100%">
          <tbody>
              <tr>
                  <td style="text-align: left;"><span style="font-weight: bold;">Shipping option</span></td>
              </tr>
              <tr>
                  <td style="text-align: center;">{%GetResourceString(ShippingOption.ShippingOptionDisplayName)|(user)administrator|(hash)3af59432f5a90940a17c77bd023e11435d578b1245f74b76be49313e4ca562f9%}</td>
              </tr>
          </tbody>
      </table>
    </td>  
  </tr>
  <tr>
    <td style="text-align: left" colspan="2">
      {%ContentTable.ApplyTransformation("Ecommerce.Transformations.Order_ContentTable", "Ecommerce.Transformations.Order_ContentTableHeader", "Ecommerce.Transformations.Order_ContentTableFooter")|(user)administrator|(hash)9e56a53dbd5bf3e32802ce8dae1042f123cb7719fa66db3750e7c586c3789b1d%}
      <hr size="1" />
      <div style="text-align: right;">
      <table style="text-align: left;" cellpadding="5">
  <tr>
    <td><strong>Total shipping:</strong></td>
          <td style="text-align: right; padding-right: 0px;">
            <strong>{%TotalShipping.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)fe4747867dd60dc8b40000eca1069ed43b20b675882946895074c47a112052c1%}</strong>
          </td>
  </tr>
  <tr>
    <td style="vertical-align:top;"><strong>Shipping tax summary:</strong></td>
          <td style="text-align: right; padding-right: 0px;">
            {%ShippingTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)1078a0131c3dec03c7671cf956a60b4411645e70b2bd4793372192c9b9fd3aa0%}
          </td>
  </tr>  
  <tr>
    <td><strong>Total price:</strong></td>
          <td style="text-align: right; padding-right: 0px;">
            <strong>{%TotalPrice.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)b63ec0b2ccb82b700c64d1b50b3a5336a74e5d6727a747719e1ec39698fb445d%}</strong>
          </td>
  </tr>
  <tr>
    <td style="vertical-align:top;"><strong>Tax summary:</strong></td>
          <td style="text-align: right; padding-right: 0px;">
            {%ContentTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)eda185fc7fac9ede5dc2a686ec381a205bada144d7e116e1b50508fe3f11006b%}
          </td>
  </tr>
      </table>
      </div>
      <div style="height: 120px;">&nbsp;</div>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <table width="100%">
        <tr>
          <td style="text-align: left">
            <span style="font-weight: bold"> Order note </span>
          </td>
        </tr>
        <tr>
          <td style="text-align: left">
            {%Order.OrderNote|(encode)|(user)administrator|(hash)7aa262f6abfeea5a9136a093c575725fc1ead41635b57727e1ffc1b1b96f3fa8%}
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
{%IfDataSourceIsEmpty(EproductsTable, "",
"<p>Your <b>e-products download links were activated</b>, please download the files before their expiration. Once the files expire, you won''t be able to download them.</p>" +
EproductsTable.ApplyTransformation("Ecommerce.Transformations.Order_EproductsTable")|(user)administrator|(hash)7005710a13d187772115061c8cc8962bebee0abaaa2a69f019311dc57abc05ac%}
</body>
</html>', NULL, '5da46ce2-23bf-4c2e-9dbb-22d67c550399', '20110930 10:02:32', N'We have received your payment for the order below.
Your order  Company logo  
 
Invoice number: {%Order.OrderInvoiceNumber|(user)administrator|(hash)a95e0a748a38406f0e49d6d4599317a54b5b84ce2a517e44102fbbe141caf5b9%} 
 
Order date: {%Format(Order.OrderDate, "{0:d}")|(user)administrator|(hash)917baa66d3079eb4259d92dd9ca858f7c39135d9145fa30d075260fc4fbb87fb%} 
Order status: {%GetResourceString(OrderStatus.StatusDisplayName)|(user)administrator|(hash)70418ac3e69df3f93816b61326efc22a135f8ff5e5a488c0e92f9dd2332898e5%}
 
Supplier 
Company address  
Customer 
{%BillingAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)32278747a390cbf184b898b50cb9cecba5351e74f1b21f32c9e74499509c89e7%} 
 
Payment option  
{%GetResourceString(PaymentOption.PaymentOptionDisplayName)|(user)administrator|(hash)4f0bbe11b052df9335eb5b9de7fac8caee44420a2a949612b6d2dc26534575ba%}
 
Shipping option  
{%GetResourceString(ShippingOption.ShippingOptionDisplayName)|(user)administrator|(hash)3af59432f5a90940a17c77bd023e11435d578b1245f74b76be49313e4ca562f9%}
 
{%ContentTable.ApplyTransformation("Ecommerce.Transformations.Order_ContentTable", "Ecommerce.Transformations.Order_ContentTableHeader", "Ecommerce.Transformations.Order_ContentTableFooter")|(user)administrator|(hash)9e56a53dbd5bf3e32802ce8dae1042f123cb7719fa66db3750e7c586c3789b1d%}
--------------------------------------------------------------------------------
Total shipping: {%TotalShipping.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)fe4747867dd60dc8b40000eca1069ed43b20b675882946895074c47a112052c1%} 
Shipping tax summary: {%ShippingTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)1078a0131c3dec03c7671cf956a60b4411645e70b2bd4793372192c9b9fd3aa0%}
Total price: {%TotalPrice.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)b63ec0b2ccb82b700c64d1b50b3a5336a74e5d6727a747719e1ec39698fb445d%}  
Tax summary: {%ContentTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)eda185fc7fac9ede5dc2a686ec381a205bada144d7e116e1b50508fe3f11006b%}  
  
Order note  
{%Order.OrderNote|(encode)|(user)administrator|(hash)7aa262f6abfeea5a9136a093c575725fc1ead41635b57727e1ffc1b1b96f3fa8%}
{%EproductsTable.ApplyTransformation("Ecommerce.Transformations.Order_EproductsTable",
"Your e-products download links were activated, please download the files before their expiration. Once the files expire, you won''t be able to download them.")|(user)administrator|(hash)2dad5bde981aa5cfe6863c3bf5e8fc4668785ab8294b59e7a9462ad88c7985d3%}', N'', N'', N'', N'', N'ecommerce')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (731, N'Ecommerce.OrderStatusNotificationToAdmin', N'E-commerce - Order status notification to administrator', N'<html>
<head>
</head>
<body>
<p>Status of the order bellow has changed</p>
<table cellspacing="0" cellpadding="5" border="1" bordercolor="black" width="600px">
  <tr>
    <td colspan="2" valign="bottom" height="50">
      <table width="100%" height="100%">
        <tr>
          <td style="text-align: left; vertical-align: bottom;"
            <span style="font-size: 18pt">New order</span>
          </td>
          <td style="text-align: center; vertical-align: middle;">
            <span style="font-family: Garamond, Times, serif; font-size: 24pt; font-style: italic;">Company logo</span>
          </td>
        </tr>
      </table> 
    </td>
  </tr>
  <tr>
    <td style="text-align: left">    
      <br />
      <table width="100%">
        <tr>
          <td style="text-align: left;" valign="bottom"> 
            <strong>Invoice number:</strong>
          </td>
          <td style="text-align: right; padding-right: 10px">
            {%Order.OrderInvoiceNumber|(user)administrator|(hash)a95e0a748a38406f0e49d6d4599317a54b5b84ce2a517e44102fbbe141caf5b9%}
          </td>
        </tr>
      </table> 
      <br />
    </td>
    <td style="text-align: left">    
      <br />
      <table width="100%">
        <tr>
          <td style="text-align: left;" valign="bottom"> 
            <strong>Order date:</strong>
          </td>
          <td style="text-align: right; padding-right: 10px">
            {%Format(Order.OrderDate, "{0:d}")|(user)administrator|(hash)917baa66d3079eb4259d92dd9ca858f7c39135d9145fa30d075260fc4fbb87fb%}
          </td>
        </tr>
  <tr>
          <td style="text-align: left;" valign="bottom"> 
            <strong>Order status:</strong>
          </td>
          <td style="text-align: right; padding-right: 10px">
            {%OrderStatus.StatusDisplayName|(user)administrator|(hash)13c07bbd5b6f0c43f9846257d431e74010c6fc7e34bc81a37f4370d42d0459a1%} 
          </td>
        </tr>
      </table>  
      <br />
    </td>
  </tr>
  <tr>
    <td style="text-align: left; vertical-align: top" width="50%">
      <strong>Supplier</strong>
      <br/>
      <br/>
      <table>
        <tr>
          <td>
            Company address
          </td>
        </tr>
      </table>
      <br />
    </td>
    <td style="text-align: left; vertical-align: top" width="50%">
      <span style="font-weight: bold"> Customer </span><br />
      <br />
        {%BillingAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)32278747a390cbf184b898b50cb9cecba5351e74f1b21f32c9e74499509c89e7%}
      <br />
  <strong>Company address:</strong>
  {%CompanyAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)a7e59664f6adcb4279bc33a0c3b28ca81249e4289ec4c4b6220d7deed02bd77a%}
      <br />
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <table width="100%">
        <tr>
          <td style="text-align: left">
            <span style="font-weight: bold"> Payment option </span>
          </td>
        </tr>
        <tr>
          <td style="text-align: center">
            {%GetResourceString(PaymentOption.PaymentOptionDisplayName)|(user)administrator|(hash)4f0bbe11b052df9335eb5b9de7fac8caee44420a2a949612b6d2dc26534575ba%}
          </td>
        </tr>
      </table> 
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <table width="100%">
        <tr>
          <td style="text-align: left">
            <span style="font-weight: bold"> Shipping option </span>
          </td>
        </tr>
        <tr>
          <td style="text-align: center">
            {%GetResourceString(ShippingOption.ShippingOptionDisplayName)|(user)administrator|(hash)3af59432f5a90940a17c77bd023e11435d578b1245f74b76be49313e4ca562f9%}
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td style="text-align: left" colspan="2">
      {%ContentTable.ApplyTransformation("Ecommerce.Transformations.Order_ContentTable", "Ecommerce.Transformations.Order_ContentTableHeader", "Ecommerce.Transformations.Order_ContentTableFooter")|(user)administrator|(hash)9e56a53dbd5bf3e32802ce8dae1042f123cb7719fa66db3750e7c586c3789b1d%} 
      <hr size="1" />
      <div style="text-align: right;">
      <table style="text-align: left;" cellpadding="5">
  <tr>
    <td><strong>Total shipping:</strong></td>
          <td style="text-align: right; padding-right: 0px;">
            <strong>{%TotalShipping.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)fe4747867dd60dc8b40000eca1069ed43b20b675882946895074c47a112052c1%}</strong>
          </td>
  </tr>
  <tr>
    <td><strong>Total price:</strong></td>
          <td style="text-align: right; padding-right: 0px;">
            <strong>{%TotalPrice.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)b63ec0b2ccb82b700c64d1b50b3a5336a74e5d6727a747719e1ec39698fb445d%}</strong>
          </td>
  </tr>
  <tr>
    <td style="vertical-align:top;"><strong>Tax summary:</strong></td>
          <td style="text-align: right; padding-right: 0px;">
            {%ContentTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)eda185fc7fac9ede5dc2a686ec381a205bada144d7e116e1b50508fe3f11006b%}
          </td>
  </tr>
      </table>
      </div>
      <div style="height: 120px;">&nbsp;</div>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <table width="100%">
        <tr>
          <td style="text-align: left">
            <span style="font-weight: bold"> Order note </span>
          </td>
        </tr>
        <tr>
          <td style="text-align: left">
            {%Order.OrderNote|(encode)|(user)administrator|(hash)7aa262f6abfeea5a9136a093c575725fc1ead41635b57727e1ffc1b1b96f3fa8%}
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<div style="padding-top-10px;">
   {%NewOrderLink%}
</div>
</body>
</html>', NULL, 'a32836fb-5d7e-4e71-9dcf-33bc920859b6', '20110930 08:15:19', N'Status of the order bellow has changed
New order  Company logo  
 
Invoice number:  {%Order.OrderInvoiceNumber|(user)administrator|(hash)a95e0a748a38406f0e49d6d4599317a54b5b84ce2a517e44102fbbe141caf5b9%}  
 
Order date:  {%Format(Order.OrderDate, "{0:d}")|(user)administrator|(hash)917baa66d3079eb4259d92dd9ca858f7c39135d9145fa30d075260fc4fbb87fb%} 
Order status:  {%GetResourceString(OrderStatus.StatusDisplayName)|(user)administrator|(hash)70418ac3e69df3f93816b61326efc22a135f8ff5e5a488c0e92f9dd2332898e5%}  
 
Supplier 
Company address  
Customer 
{%BillingAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)32278747a390cbf184b898b50cb9cecba5351e74f1b21f32c9e74499509c89e7%}
Company address: {%CompanyAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)a7e59664f6adcb4279bc33a0c3b28ca81249e4289ec4c4b6220d7deed02bd77a%}
 
Payment option  
{%GetResourceString(PaymentOption.PaymentOptionDisplayName)|(user)administrator|(hash)4f0bbe11b052df9335eb5b9de7fac8caee44420a2a949612b6d2dc26534575ba%}  
 
Shipping option  
{%GetResourceString(ShippingOption.ShippingOptionDisplayName)|(user)administrator|(hash)3af59432f5a90940a17c77bd023e11435d578b1245f74b76be49313e4ca562f9%} 
 
{%ContentTable.ApplyTransformation("Ecommerce.Transformations.Order_ContentTable", "Ecommerce.Transformations.Order_ContentTableHeader", "Ecommerce.Transformations.Order_ContentTableFooter")|(user)administrator|(hash)9e56a53dbd5bf3e32802ce8dae1042f123cb7719fa66db3750e7c586c3789b1d%} 
--------------------------------------------------------------------------------
Total shipping: {%TotalShipping.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)fe4747867dd60dc8b40000eca1069ed43b20b675882946895074c47a112052c1%}  
Total price: {%TotalPrice.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)b63ec0b2ccb82b700c64d1b50b3a5336a74e5d6727a747719e1ec39698fb445d%} 
Tax summary: 
{%ContentTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)eda185fc7fac9ede5dc2a686ec381a205bada144d7e116e1b50508fe3f11006b%}  
  
Order note  
{%Order.OrderNote|(encode)|(user)administrator|(hash)7aa262f6abfeea5a9136a093c575725fc1ead41635b57727e1ffc1b1b96f3fa8%}
 
{%NewOrderLink%}', N'', N'', N'', N'', N'ecommerce')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (732, N'Ecommerce.OrderStatusNotificationToCustomer', N'E-commerce - Order status notification to customer', N'<html>
<head>
</head>
<body>
<p>Status of your order has changed.</p>
<table cellspacing="0" cellpadding="5" border="1" bordercolor="black" width="600px">
  <tr>
    <td colspan="2" valign="bottom" height="50">
      <table width="100%" height="100%">
        <tr>
          <td style="text-align: left; vertical-align: bottom;"
            <span style="font-size: 18pt">Your order</span>
          </td>
          <td style="text-align: center; vertical-align: middle;">
            <span style="font-family: Garamond, Times, serif; font-size: 24pt; font-style: italic;">Company logo</span>
          </td>
        </tr>
      </table> 
    </td>
  </tr>
  <tr>
    <td style="text-align: left">    
      <br />
      <table width="100%">
        <tr>
          <td style="text-align: left;" valign="bottom"> 
            <strong>Invoice number:</strong>
          </td>
          <td style="text-align: right; padding-right: 10px">
            {%Order.OrderInvoiceNumber|(user)administrator|(hash)a95e0a748a38406f0e49d6d4599317a54b5b84ce2a517e44102fbbe141caf5b9%}
          </td>
        </tr>
      </table> 
      <br />
    </td>
    <td style="text-align: left">    
      <br />
      <table width="100%">
        <tr>
          <td style="text-align: left;" valign="bottom"> 
            <strong>Order date:</strong>
          </td>
          <td style="text-align: right; padding-right: 10px">
            {%Format(Order.OrderDate, "{0:d}")|(user)administrator|(hash)917baa66d3079eb4259d92dd9ca858f7c39135d9145fa30d075260fc4fbb87fb%}
          </td>
        </tr>
  <tr>
          <td style="text-align: left;" valign="bottom"> 
            <strong>Order status:</strong>
          </td>
          <td style="text-align: right; padding-right: 10px">
            {%GetResourceString(OrderStatus.StatusDisplayName)|(user)administrator|(hash)70418ac3e69df3f93816b61326efc22a135f8ff5e5a488c0e92f9dd2332898e5%}
          </td>
        </tr>
      </table>  
      <br />
    </td>
  </tr>
  <tr>
    <td style="text-align: left; vertical-align: top" width="50%">
      <strong>Supplier</strong>
      <br/>
      <br/>
      <table>
        <tr>
          <td>
            Company address
          </td>
        </tr>
      </table>
      <br />
    </td>
    <td style="text-align: left; vertical-align: top" width="50%">
      <span style="font-weight: bold"> Customer </span><br />
      <br />
        {%BillingAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)32278747a390cbf184b898b50cb9cecba5351e74f1b21f32c9e74499509c89e7%}
      <br />
  <strong>Company address:</strong>
  {%CompanyAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)a7e59664f6adcb4279bc33a0c3b28ca81249e4289ec4c4b6220d7deed02bd77a%}
      <br />
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <table width="100%">
        <tr>
          <td style="text-align: left">
            <span style="font-weight: bold"> Payment option </span>
          </td>
        </tr>
        <tr>
          <td style="text-align: center">
            {%GetResourceString(PaymentOption.PaymentOptionDisplayName)|(user)administrator|(hash)4f0bbe11b052df9335eb5b9de7fac8caee44420a2a949612b6d2dc26534575ba%}
          </td>
        </tr>
      </table> 
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <table width="100%">
        <tr>
          <td style="text-align: left">
            <span style="font-weight: bold"> Shipping option </span>
          </td>
        </tr>
        <tr>
          <td style="text-align: center">
            {%GetResourceString(ShippingOption.ShippingOptionDisplayName)|(user)administrator|(hash)3af59432f5a90940a17c77bd023e11435d578b1245f74b76be49313e4ca562f9%}
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td style="text-align: left" colspan="2">
      {%ContentTable.ApplyTransformation("Ecommerce.Transformations.Order_ContentTable", "Ecommerce.Transformations.Order_ContentTableHeader", "Ecommerce.Transformations.Order_ContentTableFooter")|(user)administrator|(hash)9e56a53dbd5bf3e32802ce8dae1042f123cb7719fa66db3750e7c586c3789b1d%}
      <hr size="1" />
      <div style="text-align: right;">
      <table style="text-align: left;" cellpadding="5">
  <tr>
    <td><strong>Total shipping:</strong></td>
          <td style="text-align: right; padding-right: 0px;">
            <strong>{%TotalShipping.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)fe4747867dd60dc8b40000eca1069ed43b20b675882946895074c47a112052c1%}</strong>
          </td>
  </tr>
  <tr>
    <td><strong>Total price:</strong></td>
          <td style="text-align: right; padding-right: 0px;">
            <strong>{%TotalPrice.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)b63ec0b2ccb82b700c64d1b50b3a5336a74e5d6727a747719e1ec39698fb445d%}</strong>
          </td>
  </tr>
  <tr>
    <td style="vertical-align:top;"><strong>Tax summary:</strong></td>
          <td style="text-align: right; padding-right: 0px;">
            {%ContentTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)eda185fc7fac9ede5dc2a686ec381a205bada144d7e116e1b50508fe3f11006b%}
          </td>
  </tr>
      </table>
      </div>
      <div style="height: 120px;">&nbsp;</div>
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <table width="100%">
        <tr>
          <td style="text-align: left">
            <span style="font-weight: bold"> Order note </span>
          </td>
        </tr>
        <tr>
          <td style="text-align: left">
            {%Order.OrderNote|(encode)|(user)administrator|(hash)7aa262f6abfeea5a9136a093c575725fc1ead41635b57727e1ffc1b1b96f3fa8%}
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>', NULL, '68ca5608-f80f-4972-88f3-24daaf669c32', '20110930 08:15:55', N'Status of your order has changed.
Your order  Company logo  
 
Invoice number:  {%Order.OrderInvoiceNumber|(user)administrator|(hash)a95e0a748a38406f0e49d6d4599317a54b5b84ce2a517e44102fbbe141caf5b9%} 
 
Order date:  {%Format(Order.OrderDate, "{0:d}")|(user)administrator|(hash)917baa66d3079eb4259d92dd9ca858f7c39135d9145fa30d075260fc4fbb87fb%}  
Order status:  {%GetResourceString(OrderStatus.StatusDisplayName)|(user)administrator|(hash)70418ac3e69df3f93816b61326efc22a135f8ff5e5a488c0e92f9dd2332898e5%}  
 
Supplier 
Company address  
Customer 
{%BillingAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)32278747a390cbf184b898b50cb9cecba5351e74f1b21f32c9e74499509c89e7%}
Company address: {%CompanyAddress.ApplyTransformation("Ecommerce.Transformations.Order_Address"|(user)administrator|(hash)a7e59664f6adcb4279bc33a0c3b28ca81249e4289ec4c4b6220d7deed02bd77a%}
 
Payment option  
{%GetResourceString(PaymentOption.PaymentOptionDisplayName)|(user)administrator|(hash)4f0bbe11b052df9335eb5b9de7fac8caee44420a2a949612b6d2dc26534575ba%}  
 
Shipping option  
{%GetResourceString(ShippingOption.ShippingOptionDisplayName)|(user)administrator|(hash)3af59432f5a90940a17c77bd023e11435d578b1245f74b76be49313e4ca562f9%}  
 
{%ContentTable.ApplyTransformation("Ecommerce.Transformations.Order_ContentTable", "Ecommerce.Transformations.Order_ContentTableHeader", "Ecommerce.Transformations.Order_ContentTableFooter")|(user)administrator|(hash)9e56a53dbd5bf3e32802ce8dae1042f123cb7719fa66db3750e7c586c3789b1d%} 
--------------------------------------------------------------------------------
Total shipping: {%TotalShipping.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)fe4747867dd60dc8b40000eca1069ed43b20b675882946895074c47a112052c1%}  
Total price: {%TotalPrice.Format(Currency.CurrencyFormatString)|(user)administrator|(hash)b63ec0b2ccb82b700c64d1b50b3a5336a74e5d6727a747719e1ec39698fb445d%}  
Tax summary: 
{%ContentTaxesTable.ApplyTransformation("Ecommerce.Transformations.Order_TaxesTable", "Ecommerce.Transformations.Order_TaxesTableHeader", "Ecommerce.Transformations.Order_TaxesTableFooter")|(user)administrator|(hash)eda185fc7fac9ede5dc2a686ec381a205bada144d7e116e1b50508fe3f11006b%}  
  
Order note  
{%Order.OrderNote|(encode)|(user)administrator|(hash)7aa262f6abfeea5a9136a093c575725fc1ead41635b57727e1ffc1b1b96f3fa8%}', N'', N'', N'', N'', N'ecommerce')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (161, N'Forums.NewPost', N'Forums -  New post', N'<html>
	<head>
	  <style>
		BODY, TD
		{
		  font-size: 12px; 
		  font-family: arial
		}
	  </style>
	</head>	
	<body>
	<p>
	  This is a notification of a new post added to the forum you subscribed to:
	</p>
	<table>
	  <tr valign="top">
		<td>
		<strong>Forum:</strong>
		</td>
		<td>
		{%forumdisplayname|(user)administrator|(hash)dd1dfb82deb7c9b2e3b197a001a5291d802843e3f0ce9c0bfdd95e91df9d7ca3%}
		</td>
	  </tr>
	  <tr valign="top">
		<td>
		<strong>Subject:</strong>
		</td>
		<td>
		{%postsubject|(user)administrator|(hash)e56d5792480ad52910a80e58c2b291c828171c7ac0b44710a5359226c3e4aec2%}
		</td>
	  </tr>
	  <tr valign="top">
		<td>
		<strong>Posted by:</strong>
		</td>
		<td>
		{%TrimSitePrefix(postusername)|(user)administrator|(hash)b0ae51562f7d1a17e88e14c7f874fb3d4c073375d0b0448a6c652333e7b23c96%}
		</td>
	  </tr>
	  <tr valign="top">
		<td>
		<strong>Date and time:</strong>
		</td>
		<td>
		{%posttime|(user)administrator|(hash)f62620daa9b076c5f0285f62df043c342623be119a9a078b1b0f1f229b640610%}
		</td>
	  </tr>
	  <tr valign="top">
		<td>
		<strong>Text:</strong>
		</td>
		<td>
		{%posttext|(user)administrator|(hash)a6b362d6212ce0833b9639c862a1474c2130a4d345367fbf6ccdfb82efac0133%}
		</td>
	  </tr>
	</table>	  
	<p>
	<a href="{%link|(user)administrator|(hash)3a1cd5192d11737a7dd51e04d3f31fd32d1dfa837d7f9baf3bb13e133a9d4cbc%}">Click here to view forum on-line</a> &nbsp;
        <a href="{%unsubscribelink|(user)administrator|(hash)17d4337051c12b345cb95ff96aa289a8b83328b81456e734143603b41afe40c1%}">Click here to unsubscribe</a>
	</p>
	</body>
</html>', NULL, '2fd97ef6-d0c3-4cd0-99fa-2cda6928773d', '20110905 17:35:19', N'This is a notification of a new post added to the forum you subscribed to: 
Forum:  {%forumdisplayname|(user)administrator|(hash)dd1dfb82deb7c9b2e3b197a001a5291d802843e3f0ce9c0bfdd95e91df9d7ca3%}  
Subject:  {%postsubject|(user)administrator|(hash)e56d5792480ad52910a80e58c2b291c828171c7ac0b44710a5359226c3e4aec2%}  
Posted by:  {%TrimSitePrefix(postusername)|(user)administrator|(hash)b0ae51562f7d1a17e88e14c7f874fb3d4c073375d0b0448a6c652333e7b23c96%}  
Date and time:  {%posttime|(user)administrator|(hash)f62620daa9b076c5f0285f62df043c342623be119a9a078b1b0f1f229b640610%}  
Text:  {%posttextplain|(user)administrator|(hash)0de8ef6ca151a2f05cffce3719512013956667dc6e76600b594108e9d0200912%}  
Click here to view forum on-line:
{%link|(user)administrator|(hash)3a1cd5192d11737a7dd51e04d3f31fd32d1dfa837d7f9baf3bb13e133a9d4cbc%} 
Click here to unsubscribe:
{%unsubscribelink|(user)administrator|(hash)17d4337051c12b345cb95ff96aa289a8b83328b81456e734143603b41afe40c1%}', N'', N'', N'', N'', N'forum')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (165, N'Forums.ModeratorNotice', N'Forums - Moderator notification', N'<html>
	<head>
	  <style>
		BODY, TD
		{
		  font-size: 12px; 
		  font-family: arial
		}
	  </style>
	</head>	
	<body>
	<p>
	  A new forum post is waiting for your approval.
	</p>
	<table>
	  <tr valign="top">
		<td>
		<strong>Forum:</strong>
		</td>
		<td>
		{%forumdisplayname|(user)administrator|(hash)dd1dfb82deb7c9b2e3b197a001a5291d802843e3f0ce9c0bfdd95e91df9d7ca3%}
		</td>
	  </tr>
	  <tr valign="top">
		<td>
		<strong>Subject:</strong>
		</td>
		<td>
		{%postsubject|(user)administrator|(hash)e56d5792480ad52910a80e58c2b291c828171c7ac0b44710a5359226c3e4aec2%}
		</td>
	  </tr>
	  <tr valign="top">
		<td>
		<strong>Posted by:</strong>
		</td>
		<td>
		{%TrimSitePrefix(postusername)|(user)administrator|(hash)b0ae51562f7d1a17e88e14c7f874fb3d4c073375d0b0448a6c652333e7b23c96%}
		</td>
	  </tr>
	  <tr valign="top">
		<td>
		<strong>Date and time:</strong>
		</td>
		<td>
		{%posttime|(user)administrator|(hash)f62620daa9b076c5f0285f62df043c342623be119a9a078b1b0f1f229b640610%}
		</td>
	  </tr>
	  <tr valign="top">
		<td>
		<strong>Text:</strong>
		</td>
		<td>
		{%posttext|(user)administrator|(hash)a6b362d6212ce0833b9639c862a1474c2130a4d345367fbf6ccdfb82efac0133%}
		</td>
	  </tr>
	</table>	  
	<p>
	<a href="{%link|(user)administrator|(hash)3a1cd5192d11737a7dd51e04d3f31fd32d1dfa837d7f9baf3bb13e133a9d4cbc%}">Click here to view the forum on-line</a> &nbsp;
	</p>
	</body>
</html>', NULL, 'f1fc231d-d1c4-425c-83d0-dd5197bc4c7b', '20110905 17:36:01', N'A new forum post is waiting for your approval. 
Forum:  {%forumdisplayname|(user)administrator|(hash)dd1dfb82deb7c9b2e3b197a001a5291d802843e3f0ce9c0bfdd95e91df9d7ca3%}  
Subject:  {%postsubject|(user)administrator|(hash)e56d5792480ad52910a80e58c2b291c828171c7ac0b44710a5359226c3e4aec2%}  
Posted by:  {%TrimSitePrefix(postusername)|(user)administrator|(hash)b0ae51562f7d1a17e88e14c7f874fb3d4c073375d0b0448a6c652333e7b23c96%}  
Date and time:  {%posttime|(user)administrator|(hash)f62620daa9b076c5f0285f62df043c342623be119a9a078b1b0f1f229b640610%}  
Text:  {%posttext|(user)administrator|(hash)a6b362d6212ce0833b9639c862a1474c2130a4d345367fbf6ccdfb82efac0133%}  
Click here to view the forum on-line:
{%link|(user)administrator|(hash)3a1cd5192d11737a7dd51e04d3f31fd32d1dfa837d7f9baf3bb13e133a9d4cbc%}', N'', N'', N'', N'', N'forum')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (764, N'Forums.SubscribeConfirmation', N'Forums - Subscription confirmation', N'<html>
	<head>
	  <style>
		BODY, TD
		{
		  font-size: 12px; 
		  font-family: arial
		}
	  </style>
	</head>	
	<body>
	<p>
	  You have been successfully subscribed to		
	<strong>Forum</strong> {%forumdisplayname%}{%separator%}{%subject%}.		    
	<p/>
	<p>
	<a href="{%link%}">Click here to view forum on-line</a> &nbsp;
        <a href="{%unsubscribelink%}">Click here to unsubscribe</a>
	</p>
	</body>
</html>', NULL, 'dc4a0178-3055-4339-bab5-5dc1011b9a41', '20111116 17:20:43', N'You have been successfully subscribed to Forum {%forumdisplayname%}{%separator%}{%subject%}. 
Click here to view forum on-line:
{%link%}
Click here to unsubscribe:
{%unsubscribelink%}', N'Forum subscription notification', N'', N'', N'', N'forumsubscribtion')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (855, N'forums.subscriptionrequest', N'Forums - Subscription request', N'<html>
	<head>
	  <style>
		BODY, TD
		{
		  font-size: 12px; 
		  font-family: arial
		}
	  </style>
	</head>	
	<body>
	<p>
	  You have requested subscription to our <strong>Forum</strong> {%ForumDisplayName%}. Please use the following link to confirm your subscription.<br />
          <a href="{%SubscribeLink%}">Click here to confirm the subscription</a><br /><br />
          {%if(ToInt(OptInInterval,0)>0) {"NOTE: Confirmation link will be valid for next " + OptInInterval + " hours."} |(user)administrator|(hash)e97b671f793e9b7a00c951d365aeac78ab58c0fd974457c4d44c49a7af32fe16%}
	</p>
	</body>
</html>', NULL, 'b6b7b63e-9b73-4297-8fa3-22f3067622ec', '20120328 16:23:42', N'You have requested subscription to our Forum {%ForumDisplayName%}. Please use the following link to confirm your subscription.
[url={%SubscribeLink%}]Click here to confirm the subscription[/url].
{%if(ToInt(OptInInterval,0)>0) {"NOTE: Confirmation link will be valid for next " + OptInInterval + " hours."} |(user)administrator|(hash)e97b671f793e9b7a00c951d365aeac78ab58c0fd974457c4d44c49a7af32fe16%}', N'Subscription request', N'', N'', N'', N'forumsubscribtion')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (765, N'Forums.UnsubscribeConfirmation', N'Forums - Unsubscription confirmation', N'<html>
	<head>
	  <style>
		BODY, TD
		{
		  font-size: 12px; 
		  font-family: arial
		}
	  </style>
	</head>	
	<body>
	<p>
	  You have been successfully unsubscribed from		
	<strong>Forum</strong> {%forumdisplayname%}{%separator%}{%subject%}.		    
	<p/>	
	</body>
</html>', NULL, '1d636437-f61c-40dc-8bc1-383c66a1bfc1', '20111116 17:20:25', N'You have been successfully unsubscribed from Forum {%forumdisplayname%}{%separator%}{%subject%}.', N'Forum unsubscription notification', N'', N'', N'', N'forumsubscribtion')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (745, N'Friends.Approve', N'Friends - Friend approval', N'<html>
  <head>
  </head>
  <body>
    <p>{%FORMATTEDSENDERNAME|(user)administrator|(hash)f47bafdfed3b5e831fc6bb1308aa1753430d41955b3734aa41c3e1b63bae7476%} is now your friend.</p>
    <p>Comment: {%Friendship.FriendComment.HTMLEncode()|(user)administrator|(hash)a99cd01db0e99a1ba4b5c1d86a19075457310f8a47b8f0434124547bce9ce080%}</p>
    <p>Sent: {%Friendship.FriendApprovedWhen|(user)administrator|(hash)d04428819d8a2cb00098ed7c36ec65315095ece8da055a3b6096db65241bc4e6%}</p>
  </body>
</html>', NULL, '14926c79-639a-414b-b22d-2ca7cea58f2b', '20110906 01:37:38', N'{%FORMATTEDSENDERNAME|(user)administrator|(hash)f47bafdfed3b5e831fc6bb1308aa1753430d41955b3734aa41c3e1b63bae7476%} is now your friend.
Comment: {%Friendship.FriendComment|(user)administrator|(hash)17d63c1f281cc499f2d180bfe0c048b63e23ae6be8e3dad969133c6cb494811d%}
Sent: {%Friendship.FriendApprovedWhen|(user)administrator|(hash)d04428819d8a2cb00098ed7c36ec65315095ece8da055a3b6096db65241bc4e6%}', N'{%FORMATTEDSENDERNAME|(user)administrator|(hash)f47bafdfed3b5e831fc6bb1308aa1753430d41955b3734aa41c3e1b63bae7476%} is now your friend', N'', N'', N'', N'friends')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (746, N'Friends.Reject', N'Friends - Friend rejection', N'<html>
  <head>
  </head>
  <body>
    <p>{%FORMATTEDSENDERNAME|(user)administrator|(hash)f47bafdfed3b5e831fc6bb1308aa1753430d41955b3734aa41c3e1b63bae7476%} rejected the friendship.</p>
    <p>Comment: {%Friendship.FriendComment.HTMLEncode()|(user)administrator|(hash)a99cd01db0e99a1ba4b5c1d86a19075457310f8a47b8f0434124547bce9ce080%}</p>
    <p>Sent: {%Friendship.FriendRejectedWhen|(user)administrator|(hash)c1ceaa790d858a0c1dc5fddf756473365f1c1e21092e1273c15d6c0173e085a5%}</p>
  </body>
</html>', NULL, 'd5d2b5f4-bcbc-4746-a5af-08833dd4c51a', '20110906 01:37:22', N'{%FORMATTEDSENDERNAME|(user)administrator|(hash)f47bafdfed3b5e831fc6bb1308aa1753430d41955b3734aa41c3e1b63bae7476%} has rejected the friendship.
Comment: {%Friendship.FriendComment|(user)administrator|(hash)17d63c1f281cc499f2d180bfe0c048b63e23ae6be8e3dad969133c6cb494811d%}
Sent: {%Friendship.FriendRejectedWhen|(user)administrator|(hash)c1ceaa790d858a0c1dc5fddf756473365f1c1e21092e1273c15d6c0173e085a5%}', N'{%FORMATTEDSENDERNAME|(user)administrator|(hash)f47bafdfed3b5e831fc6bb1308aa1753430d41955b3734aa41c3e1b63bae7476%} rejected the friendship', N'', N'', N'', N'friends')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (747, N'Friends.Request', N'Friends - Friend request', N'<html>
  <head>
  </head>
  <body>
    <p>{%FORMATTEDSENDERNAME|(user)administrator|(hash)f47bafdfed3b5e831fc6bb1308aa1753430d41955b3734aa41c3e1b63bae7476%} wants to be your friend.</p>
    <p>Comment: {%Friendship.FriendComment|(user)administrator|(hash)17d63c1f281cc499f2d180bfe0c048b63e23ae6be8e3dad969133c6cb494811d%}</p>
    <p>Sent: {%Friendship.FriendRequestedWhen.HTMLEncode()|(user)administrator|(hash)806c12cf7cf59fd3092c008998e1e84be7e7838696f88300abf42fced7d2cc2b%}</p>
    <p>Choose one of the following actions:</p>    
    <p><a href="{%MANAGEMENTURL|(user)administrator|(hash)c64ae4c1e0944b29837b5f5e765bc0b4818e3a165abc39c2fd685d9e8fd400c9%}">Accept or reject</a></p>
    <p><a href="{%PROFILEURL|(user)administrator|(hash)d76fde75600a5758fb51fd90644e5c86640312b83071a8ea41aba17ee66bf4fd%}">Open user profile</a></p>
  </body>
</html>', NULL, '6fe616ca-b9d8-4980-90be-9124c2546cde', '20110906 01:37:08', N'{%FORMATTEDSENDERNAME|(user)administrator|(hash)f47bafdfed3b5e831fc6bb1308aa1753430d41955b3734aa41c3e1b63bae7476%} wants to be your friend.
Comment: {%Friendship.FriendComment|(user)administrator|(hash)17d63c1f281cc499f2d180bfe0c048b63e23ae6be8e3dad969133c6cb494811d%}
Sent: {%Friendship.FriendRequestedWhen|(user)administrator|(hash)1bc7516f4364112875fcaaa9b5991799d8e73d5da18c2e474809ff23063636f1%}
Choose one of the following actions:
[url={%MANAGEMENTURL|(user)administrator|(hash)c64ae4c1e0944b29837b5f5e765bc0b4818e3a165abc39c2fd685d9e8fd400c9%}]Accept or reject[/url]
[url={%PROFILEURL|(user)administrator|(hash)d76fde75600a5758fb51fd90644e5c86640312b83071a8ea41aba17ee66bf4fd%}]Open user profile[/url]', N'{%FORMATTEDSENDERNAME|(user)administrator|(hash)f47bafdfed3b5e831fc6bb1308aa1753430d41955b3734aa41c3e1b63bae7476%} wants to be your friend', N'', N'', N'', N'friends')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (763, N'Groups.MemberAcceptedInvitation', N'Groups - Member accepted invitation', N'<html>
	<head>
	</head>
	<body>
		<p>{%Sender.FullName|(user)administrator|(hash)9c9fd73381377b005c593870cccfef6713ad5d1e0c78018685122aa3fbffc352%}({%TrimSitePrefix(Sender.UserName)|(user)administrator|(hash)6a18137ec1d2ca1105829f460354816b93163878b7e7c20aaae96cd0e927d976%}) has accepted your invitation to group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.<br />
		When: {%GroupMember.MemberJoined|(user)administrator|(hash)c9f636e00073318c4d123e816c2c1eb6d0f2b2979cc7797efa5841ba4be94fda%}</p>
		<br />
		<br />
		Best Regards,<br />
		<br />
		The Community Team
	</body>
</html>', NULL, '0f68bc2f-bf08-40cf-b4e4-c2550e94f570', '20110905 17:37:05', N'{%Sender.FullName|(user)administrator|(hash)9c9fd73381377b005c593870cccfef6713ad5d1e0c78018685122aa3fbffc352%}({%TrimSitePrefix(Sender.UserName)|(user)administrator|(hash)6a18137ec1d2ca1105829f460354816b93163878b7e7c20aaae96cd0e927d976%}) has accepted your invitation to group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.
When: {%GroupMember.MemberJoined|(user)administrator|(hash)c9f636e00073318c4d123e816c2c1eb6d0f2b2979cc7797efa5841ba4be94fda%}
Best Regards,
The Community Team', N'Invitation to group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}'' was accepted', N'', N'', N'', N'groupmemberinvitation')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (758, N'Groups.MemberApproved', N'Groups - Member approved', N'<html>
  <head>
  </head>
  <body>
    <p>Dear {%MemberUser.FirstName|(user)administrator|(hash)597eda6fb2453c5fc0b53aa31ef9a20eca7c8814292d66855802a01eca09c931%},<br />
    <br />
    you have been approved as a full member of group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.</p>
    <br />
    <br />
    Best Regards,<br />
    <br />
    The Community Team
  </body>
</html>', NULL, 'd57092d8-28c3-4784-98d2-7d02f4a73a66', '20101123 10:28:50', N'Dear {%MemberUser.FirstName|(user)administrator|(hash)597eda6fb2453c5fc0b53aa31ef9a20eca7c8814292d66855802a01eca09c931%},
you have been approved as a full member of group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.
Best Regards,
The Community Team', N'', N'', N'', N'', N'groupmember')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (761, N'Groups.Invitation', N'Groups - Member invitation', N'<html>
	<head>
	</head>
	<body>
		<p>User {%InvitedBy%} invites you to group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.<br />
		With comment "{%Invitation.InvitationComment|(user)administrator|(hash)96b81159c2133c542d8375a38433649b65329b27653bafdefe8494470501ef7b%}"<br /><br />
		Follow the link below to join the group:<br /><br />
		<a href="{%ACCEPTIONURL%}">{%ACCEPTIONURL%}</a>
		</p>
		<br />
		<br />
		Best Regards,
		<br />
		<br />
		The Community Team
	</body>
</html>', NULL, '8909e20f-80b3-4be1-9c47-61000e856784', '20090127 20:21:24', N'User {%InvitedBy%} invites you to group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.
With comment "{%Invitation.InvitationComment|(user)administrator|(hash)96b81159c2133c542d8375a38433649b65329b27653bafdefe8494470501ef7b%}"
Follow the link below to join the group:
[url={%ACCEPTIONURL%}]{%ACCEPTIONURL%}[/url]
Best Regards,
The Community Team', N'Invitation to group "{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}"', N'', N'', N'', N'groupinvitation')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (753, N'Groups.MemberJoin', N'Groups - Member join', N'<html>
	<head>
	</head>
	<body>
		<p>User {%MemberUser.FullName|(user)administrator|(hash)389d50901ceb8cd6c2cbca4efb4a64ebfbdbbeac0d85bf448ded62edff7c96b8%}({%TrimSitePrefix(MemberUser.UserName)|(user)administrator|(hash)4027bcfa4f876fa6adcb91a97a334fe6348e4b4f7add08ceb6eb3e23a7e68658%}) joined group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.</p>
		<br />
		<br />
		Best Regards,<br />
		<br />
		The Community Team
	</body>
</html>', NULL, '7125b6a1-d72b-4e14-9995-2a4e73b910bc', '20110905 17:37:38', N'User {%MemberUser.FullName|(user)administrator|(hash)389d50901ceb8cd6c2cbca4efb4a64ebfbdbbeac0d85bf448ded62edff7c96b8%}({%TrimSitePrefix(MemberUser.UserName)|(user)administrator|(hash)4027bcfa4f876fa6adcb91a97a334fe6348e4b4f7add08ceb6eb3e23a7e68658%}) joined group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.
Best Regards,
The Community Team', N'', N'', N'', N'', N'groupmember')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (757, N'Groups.MemberJoinedConfirmation', N'Groups - Member joined confirmation', N'<html>
	<head>
	</head>
	<body>
		<p>Dear {%MemberUser.FirstName|(user)administrator|(hash)597eda6fb2453c5fc0b53aa31ef9a20eca7c8814292d66855802a01eca09c931%},<br />
		<br />
		welcome to group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.</p>
		<br />
		<br />
		Best Regards,
		<br />
		<br />
		The Community Team
	</body>
</html>', NULL, '03636c82-1f7f-44e0-9b51-b7a6c705114e', '20090127 20:20:25', N'Dear {%MemberUser.FirstName|(user)administrator|(hash)597eda6fb2453c5fc0b53aa31ef9a20eca7c8814292d66855802a01eca09c931%},
welcome to group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.
Best Regards,
The Community Team', N'', N'', N'', N'', N'groupmember')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (756, N'Groups.MemberJoinedWaitingForApproval', N'Groups - Member joined waiting for approval', N'<html>
	<head>
	</head>
	<body>
		<p>Dear {%MemberUser.FirstName|(user)administrator|(hash)597eda6fb2453c5fc0b53aa31ef9a20eca7c8814292d66855802a01eca09c931%},<br />
		<br />
		you are now waiting for approval to group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.</p>
		<br />
		<br />
		Best Regards,<br />
		<br />
		The Community Team
	</body>
</html>', NULL, '4c80e736-d3b4-4288-9d67-bf764634a32e', '20090127 20:19:55', N'Dear {%MemberUser.FirstName|(user)administrator|(hash)597eda6fb2453c5fc0b53aa31ef9a20eca7c8814292d66855802a01eca09c931%},
you are now waiting for approval to group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.
Best Regards,
The Community Team', N'', N'', N'', N'', N'groupmember')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (754, N'Groups.MemberLeave', N'Groups - Member leave', N'<html>
	<head>
	</head>
	<body>
		<p>User {%MemberUser.FullName|(user)administrator|(hash)389d50901ceb8cd6c2cbca4efb4a64ebfbdbbeac0d85bf448ded62edff7c96b8%}({%TrimSitePrefix(MemberUser.UserName)|(user)administrator|(hash)4027bcfa4f876fa6adcb91a97a334fe6348e4b4f7add08ceb6eb3e23a7e68658%}) just left group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.</p>
		<br />
		<br />
		Best Regards,<br />
		<br />
		The Community Team
	</body>
</html>', NULL, '85636277-a9a7-46ba-80f0-50e3fd30bc24', '20110905 17:38:47', N'User {%MemberUser.FullName|(user)administrator|(hash)389d50901ceb8cd6c2cbca4efb4a64ebfbdbbeac0d85bf448ded62edff7c96b8%}({%TrimSitePrefix(MemberUser.UserName)|(user)administrator|(hash)4027bcfa4f876fa6adcb91a97a334fe6348e4b4f7add08ceb6eb3e23a7e68658%}) just left group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.
Best Regards,
The Community Team', N'', N'', N'', N'', N'groupmember')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (759, N'Groups.MemberRejected', N'Groups - Member rejected', N'<html>
	<head>
	</head>
	<body>
		<p>Dear {%MemberUser.FirstName|(user)administrator|(hash)597eda6fb2453c5fc0b53aa31ef9a20eca7c8814292d66855802a01eca09c931%},<br />
		<br />
		you have been rejected from group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.</p>
		<br />
		<br />
		Best Regards,<br />
		<br />
		The Community Team
	</body>
</html>', NULL, '0d52d7da-4ab4-4342-b52c-a94f14f23ee9', '20090127 20:21:48', N'Dear {%MemberUser.FirstName|(user)administrator|(hash)597eda6fb2453c5fc0b53aa31ef9a20eca7c8814292d66855802a01eca09c931%},
you have been rejected from group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.
Best Regards,
The Community Team', N'', N'', N'', N'', N'groupmember')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (755, N'Groups.MemberWaitingForApproval', N'Groups - Member waiting for approval', N'<html>
	<head>
	</head>
	<body>
		<p>User {%MemberUser.FullName|(user)administrator|(hash)389d50901ceb8cd6c2cbca4efb4a64ebfbdbbeac0d85bf448ded62edff7c96b8%}({%TrimSitePrefix(MemberUser.UserName)|(user)administrator|(hash)4027bcfa4f876fa6adcb91a97a334fe6348e4b4f7add08ceb6eb3e23a7e68658%}) is waiting for approval into group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.</p>
		<br />
		<br />
		Best Regards,<br />
		<br />
		The Community Team
	</body>
</html>', NULL, '719d4419-0b2d-49db-ba8b-a5e29648d98c', '20110905 17:39:48', N'User {%MemberUser.FullName|(user)administrator|(hash)389d50901ceb8cd6c2cbca4efb4a64ebfbdbbeac0d85bf448ded62edff7c96b8%}({%TrimSitePrefix(MemberUser.UserName)|(user)administrator|(hash)4027bcfa4f876fa6adcb91a97a334fe6348e4b4f7add08ceb6eb3e23a7e68658%}) is waiting for approval into group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}''.
Best Regards,
The Community Team', N'', N'', N'', N'', N'groupmember')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (781, N'Groups.WaitingForApproval', N'Groups - Waiting for approval', N'<html>
  <head>
  </head>
  <body>    
    Group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}'' is waiting for your approval.
    <br />
    Best Regards,<br />
    <br />
    The Community Team
  </body>
</html>', NULL, '08d21450-4431-46c9-b654-a35b622fad10', '20101123 14:20:48', N'Group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}'' is waiting for your approval.
Best Regards,
The Community Team', N'Group ''{%Group.GroupDisplayName|(user)administrator|(hash)58f2ff40892e9ca0e8f3729133346d0ea6d2c681eae4e5de37f7d2f55b468c38%}'' is waiting for approval', N'', N'', N'', N'groupmember')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (842, N'Membership.ChangePasswordRequest', N'Membership - Change password request', N'<html>
  <head>
  </head>
  <body style="font-size:12px; font-family: Arial">
    <p>
       You have submitted a request to change your existing password. Please click <a href="{%ResetPasswordUrl%}">this link</a> to generate a new password.
    </p>
    <p>
       If you want to cancel your request or you did not send request please click <a href="{%CancelUrl%}">this link</a> to invalidate the operation.
    </p>
  </body>
</html>', NULL, 'c97cec10-ecac-4f15-ab20-99f5008d49cf', '20120821 18:36:28', N'You have submitted a request to change your existing password. Please go to this link {%ResetPasswordUrl%} to generate a new password.
If you want to cancel your request or you did not send request please go to this link {%CancelUrl%} to invalidate the operation.', N'{$membership.passwreqsubject$}', N'', N'', N'', N'membershipchangepassword')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (738, N'Membership.ChangedPassword', N'Membership - Changed password', N'<html>
<head>
</head>
<body>
Your password has been changed.<br />
<p>Your user name and new password are:</p>
<p><strong>User name:</strong> {%TrimSitePrefix(UserName)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}<br />
<strong>Password:</strong> {%Password|(user)administrator|(hash)3fa3e7dfc7ed2fd25117e5ac94ee3cc91c4597aa0db425e8e9c5e316b9fc019c%}</p>
<br />
<br />
</body>
</html>', NULL, '97b2f851-0693-40e6-8be1-6edd27d138d4', '20110905 17:40:30', N'Your password has been changed.
Your user name and new password are:
User name: {%TrimSitePrefix(UserName)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}
Password: {%Password|(user)administrator|(hash)3fa3e7dfc7ed2fd25117e5ac94ee3cc91c4597aa0db425e8e9c5e316b9fc019c%}', N'', N'', N'', N'', N'password')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (807, N'Membership.ExpirationNotification', N'Membership - Expiration notification', N'The following memberships will expire soon:
{%MembershipsTable.ApplyTransformation("Ecommerce.Transformations.Order_MembershipsTable")|(user)administrator|(hash)dd03c77fb67739b9e3a7b2f5144426e458b5abb1da5756e82f41bfcdfe0f8b02%}
<br />
To renew it, please follow these steps:
<ol>
<li>In My profile section on My memberships tab click the Buy membership button. You will be redirected to the Buy membership page.</li>
<li>Choose the required membership and add it to your shopping cart.</li>
<li>Finish your order.</li>
<li>Once the order is paid, your membership will be renewed.</li>
</ol>
This is an automatic reminder, please do not respond.<br />
Thank you.', NULL, '96db7d3f-e7ca-41eb-926a-9fe92babe634', '20110907 17:13:50', N'The following memberships will expire soon:
{%MembershipsTable.ApplyTransformation("Ecommerce.Transformations.Order_MembershipsTable")|(user)administrator|(hash)dd03c77fb67739b9e3a7b2f5144426e458b5abb1da5756e82f41bfcdfe0f8b02%}
To renew it, please follow these steps:
1) In My profile section on My memberships tab click the Buy membership button. You will be redirected to the Buy membership page.
2) Choose the required membership and add it to your shopping cart.
3) Finish your order.
4) Once the order is paid, your membership will be renewed.
This is an automatic reminder, please do not respond.
Thank you.', N'', N'', N'', N'', N'membershipexpiration')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (162, N'forgottenPassword', N'Membership - Forgotten password', N'<html>
	<head>
	</head>
	<body style="font-size:12px; font-family: Arial">
		<p>
                You requested a password reset at <a href="{%LogonUrl%}">{%LogonUrl%}</a>. 
		</p>
		<p>
		Your user name and new password are:
		</p>
		<p>
		<strong>User name:</strong> {%TrimSitePrefix(UserName)%}
                <br/>
                <strong>Password:</strong> {%Password%}
		</p>
	</body>
</html>', NULL, 'd46985fb-e598-4b35-88e1-32bc8508aff5', '20120125 17:29:28', N'You requested a password reset at [url={%LogonUrl%}]{%LogonUrl%}[/url]. 
Your user name and new password are: 
User name: {%TrimSitePrefix(UserName)%} 
Password: {%Password%}', N'Password reset', N'', N'', N'', N'forgottenpassword')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (861, N'Membership.NewPassword', N'Membership - New password', N'<html>
<head>
</head>
<body>
<p>You requested new password.</p>
<p>Your user name and new password are:</p>
<p><strong>User name:</strong> {%TrimSitePrefix(UserName)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}<br />
<strong>Password:</strong> {%Password|(user)administrator|(hash)3fa3e7dfc7ed2fd25117e5ac94ee3cc91c4597aa0db425e8e9c5e316b9fc019c%}</p>
</body>
</html>', NULL, 'fe695a9a-5268-40d4-93ae-ff59b2f7c712', '20110905 17:41:48', N'You requested new password.
Your user name and new password are:
User name: {%TrimSitePrefix(UserName)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}
Password: {%Password|(user)administrator|(hash)3fa3e7dfc7ed2fd25117e5ac94ee3cc91c4597aa0db425e8e9c5e316b9fc019c%}', N'', N'', N'', N'', N'password')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (164, N'Registration.New', N'Membership - Notification - New registration', N'<html>
	<head>
	</head>
	<body style="font-size:12px; font-family: Arial">
		<p>
This is a notification that a new user has just registered:<br />
<br />
First name: {%firstname|(user)administrator|(hash)998d81dab6b7c37aa5cb71222ca28b587031d87d21d551ece5124d71cd3f0b3b%} <br />
<br />
Last name: {%lastname|(user)administrator|(hash)3ad2cd3e3f348a3a067a7f0e619e1feaa48311bd86528e7002f1b274a3f7feb2%}<br />
<br />
E-mail: {%email|(user)administrator|(hash)9f9aec987582acb781e33b9dcb2652019c289ff93253dbfff1ba9230f2032ed6%}<br />
<br />
User name: {%TrimSitePrefix(username)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}<br />
<br />
This e-mail is only for your information. No action is required.
<br />
</p>
</body>
</html>', NULL, '89e8fed9-3316-435e-8ea6-630e64de1a12', '20110905 17:42:27', N'This is a notification that a new user has just registered:
First name: {%firstname|(user)administrator|(hash)998d81dab6b7c37aa5cb71222ca28b587031d87d21d551ece5124d71cd3f0b3b%} 
Last name: {%lastname|(user)administrator|(hash)3ad2cd3e3f348a3a067a7f0e619e1feaa48311bd86528e7002f1b274a3f7feb2%}
E-mail: {%email|(user)administrator|(hash)9f9aec987582acb781e33b9dcb2652019c289ff93253dbfff1ba9230f2032ed6%}
User name: {%TrimSitePrefix(username)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}
This e-mail is only for your information. No action is required.', N'', N'', N'', N'', N'registration')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (163, N'Registration.Approve', N'Membership - Notification - Waiting for approval', N'<html>
	<head>
	</head>
	<body style="font-size:12px; font-family: Arial">
		<p>
This is a notification that a new user has just registered and waiting for your approval:
<br />
<br />
First name: {%firstname|(user)administrator|(hash)998d81dab6b7c37aa5cb71222ca28b587031d87d21d551ece5124d71cd3f0b3b%} <br />
<br />
Last name: {%lastname|(user)administrator|(hash)3ad2cd3e3f348a3a067a7f0e619e1feaa48311bd86528e7002f1b274a3f7feb2%}<br />
<br />
E-mail: {%email|(user)administrator|(hash)9f9aec987582acb781e33b9dcb2652019c289ff93253dbfff1ba9230f2032ed6%}<br />
<br />
User name: {%TrimSitePrefix(username)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}<br />
<br />
Please go to CMS Desk or CMS Site Manager -> Administration -> Users -> Waiting for approval and approve or reject the user.<br />
</p>
</body>
</html>', NULL, '8ee2a9d2-0ddd-4ae9-9066-f9edc6261938', '20110905 17:43:26', N'This is a notification that a new user has just registered and waiting for your approval: 
First name: {%firstname|(user)administrator|(hash)998d81dab6b7c37aa5cb71222ca28b587031d87d21d551ece5124d71cd3f0b3b%} 
Last name: {%lastname|(user)administrator|(hash)3ad2cd3e3f348a3a067a7f0e619e1feaa48311bd86528e7002f1b274a3f7feb2%}
E-mail: {%email|(user)administrator|(hash)9f9aec987582acb781e33b9dcb2652019c289ff93253dbfff1ba9230f2032ed6%}
User name: {%TrimSitePrefix(username)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}
Please go to CMS Desk or CMS Site Manager -> Administration -> Users -> Waiting for approval and approve or reject the user.', N'Registration notification - Waiting for approval', N'', N'', N'', N'registration')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (869, N'Membership.PasswordExpired', N'Membership - Password expired', N'<html>
  <head>
  </head>
  <body style="font-size:12px; font-family: Arial">
    <p>
       Your password has expired. Please click <a href="{%ResetPasswordUrl+"&exp=1"%}">this link</a> to generate a new password.
    </p>
  </body>
</html>', NULL, '5142ffc7-9810-45ee-9c5b-e4dd78a401e4', '20120116 14:36:09', N'Your password has expired. Please click [url={%ResetPasswordUrl+"&exp=1"%}][/url] to generate a new password.', N'User account lock - Password expired', N'', N'', N'', N'membershipchangepassword')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (766, N'Membership.Registration', N'Membership - Registration', N'<html>
	<head>
	</head>
	<body>
		Thank you for registering at our site. You can find your credentials below:<br />
		<br />
		Username: {%TrimSitePrefix(username)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}<br />
		Password: {%password|(user)administrator|(hash)3fa3e7dfc7ed2fd25117e5ac94ee3cc91c4597aa0db425e8e9c5e316b9fc019c%}<br />
	</body>
</html>', NULL, 'dcac774e-5ddb-4645-9704-cdadb8eda10a', '20110905 17:44:03', N'Thank you for registering at our site. You can find your credentials below:
Username: {%TrimSitePrefix(username)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}
Password: {%password|(user)administrator|(hash)3fa3e7dfc7ed2fd25117e5ac94ee3cc91c4597aa0db425e8e9c5e316b9fc019c%}', N'Registration information', N'', N'', N'', N'membershipregistration')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (750, N'RegistrationUserApproved', N'Membership - Registration approved', N'<html>
	<head>
	</head>
	<body>
		Your registration has been approved by administrator. Now you can sign in using your username and password.  <br />
<br />
<a href="{%homepageurl%}">Click here to navigate to the web site</a>
	</body>
</html>', NULL, '017c6bf7-16bf-4c65-ac16-03b5fa8ed5b7', '20090113 16:55:10', N'Your registration has been approved by administrator. Now you can sign in using your username and password. 
Click to the following link to navigate to the website:
{%homepageurl%}', N'', N'', N'', N'', N'registrationapproval')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (739, N'RegistrationConfirmation', N'Membership - Registration confirmation', N'<html>
	<head>
	</head>
	<body>
		Thank you for registering at our site. Please click the link below to complete your registration:  <br />
<a href="{%confirmaddress|(user)administrator|(hash)c549f9374a2480bfc11f07d26c3aa47e6cfbb34bd470cf380f0918806960c1cc%}">{%confirmaddress|(user)administrator|(hash)c549f9374a2480bfc11f07d26c3aa47e6cfbb34bd470cf380f0918806960c1cc%}</a>
<br />
<br />
You can find your credentials below:<br />
		Username: {%TrimSitePrefix(username)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}<br />
		Password: {%password|(user)administrator|(hash)3fa3e7dfc7ed2fd25117e5ac94ee3cc91c4597aa0db425e8e9c5e316b9fc019c%}<br />
	</body>
</html>', NULL, '11e9d672-0fbc-46ae-8f0d-6cf8001578ce', '20110905 17:45:48', N'Thank you for registering at our site. Please click the link below to complete your registration:
{%confirmaddress|(user)administrator|(hash)c549f9374a2480bfc11f07d26c3aa47e6cfbb34bd470cf380f0918806960c1cc%}
You can find your credentials below:
Username: {%TrimSitePrefix(username)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}
Password: {%password|(user)administrator|(hash)3fa3e7dfc7ed2fd25117e5ac94ee3cc91c4597aa0db425e8e9c5e316b9fc019c%}', N'Confirm your registration', N'', N'', N'', N'membershipregistration')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (767, N'Membership.RegistrationWaitingForApproval', N'Membership - Registration waiting for approval', N'<html>
	<head>
	</head>
	<body>
		Thank you for registering at our site&nbsp;{%currentsite.sitename|(user)administrator|(hash)91cb7d0950a4aca3acd3f455346e0229e2ad187f52256e47faf8302e763b741b%}. Your registration must be approved by administrator.<br />
		<br />
		<br />
		Registration details:<br />
		<br />
		Username: {%TrimSitePrefix(username)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}<br />
		Password: {%password|(user)administrator|(hash)3fa3e7dfc7ed2fd25117e5ac94ee3cc91c4597aa0db425e8e9c5e316b9fc019c%}<br />
	</body>
</html>', NULL, '132be2c1-2db6-4c7d-8165-40041f2e4938', '20110905 17:47:01', N'Thank you for registering at our site {%currentsite.sitename|(user)administrator|(hash)91cb7d0950a4aca3acd3f455346e0229e2ad187f52256e47faf8302e763b741b%}. Your registration must be approved by administrator.
Registration details:
Username: {%TrimSitePrefix(username)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}
Password: {%password|(user)administrator|(hash)3fa3e7dfc7ed2fd25117e5ac94ee3cc91c4597aa0db425e8e9c5e316b9fc019c%}', N'', N'', N'', N'', N'membershipregistration')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (737, N'Membership.ResendPassword', N'Membership - Resend password', N'<html>
<head>
</head>
<body>
<p>You have requested the current password information.</p>
<p>Your user name and current password are:</p>
<p><strong>User name:</strong> {%TrimSitePrefix(UserName)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}<br />
<strong>Password:</strong> {%Password|(user)administrator|(hash)3fa3e7dfc7ed2fd25117e5ac94ee3cc91c4597aa0db425e8e9c5e316b9fc019c%}</p>
</body>
</html>', NULL, '30db61b9-2737-4e8e-90b0-0ec304baffda', '20110905 17:48:59', N'You have requested the current password information.
Your user name and current password are:
User name: {%TrimSitePrefix(UserName)|(user)administrator|(hash)ae84cc044b37369545eb088351375699fb72d2742101a18cb3cc50597b49e736%}
Password: {%Password|(user)administrator|(hash)3fa3e7dfc7ed2fd25117e5ac94ee3cc91c4597aa0db425e8e9c5e316b9fc019c%}', N'', N'', N'', N'', N'password')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (867, N'Membership.UserAccountLock', N'Membership - User account locked', N'<html>
	<head>
	</head>
	<body style="FONT-SIZE: 12px; FONT-FAMILY: arial">
		<p>
                 You have reached maximum invalid logon attempts and your user account was locked. Please follow this <a href="{%UnlockAccountUrl%}">link</a> to unlock your account. 
                </p>
                <p>
                If you don''t remember your password you can alternatively reset you password by following this <a href="{%ResetPasswordUrl%}">link</a>. 		
                </p>
	</body>
</html>', NULL, 'cea25592-8535-429d-9ba0-9da37907c2d7', '20111219 00:50:04', N'You have reached maximum invalid logon attempts and your user account was locked. Please follow this [url={%UnlockAccountUrl%}]link[/url] to unlock your account. 
If you don''t remember your password you can alternatively reset you password by following this [url={%ResetPasswordUrl%}]link[/url].', N'User account lock', N'', N'', N'', N'membershipunlockaccount')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (719, N'messaging.messagenotification', N'Messaging  - Notification e-mail', N'<html>
	<head>
	</head>
	<body style="font-size: 12px; font-family: arial">
<p>
Hello {%TrimSitePrefix(Recipient.UserName)|(user)administrator|(hash)9e64c8058c943a11b5979319c216310e304b743dc7c73ce234857063d638ed99%},
<br />
you''ve just recieved new message from user <strong>''{%TrimSitePrefix(Sender.UserName)|(user)administrator|(hash)6a18137ec1d2ca1105829f460354816b93163878b7e7c20aaae96cd0e927d976%}''</strong>.
<br />
Original message:
<br />
<hr />
{%Message.MessageBody|(resolvebbcode)|(user)administrator|(hash)9be59ccb249f71aa631c3ddfe7279f5da589f7d26f4e525d9892c40078f925ad%}
<hr/>
<br />
You can use following <a href="{%LogonUrl%}">link</a> to logon to site and check new message.
</p>
</body>
</html>', NULL, '3d863d80-a3ab-46d8-99c5-1bcd9c2bd570', '20120215 18:33:01', N'Hello {%TrimSitePrefix(Recipient.UserName)|(user)administrator|(hash)9e64c8058c943a11b5979319c216310e304b743dc7c73ce234857063d638ed99%}, 
you''ve just recieved new message from user ''{%TrimSitePrefix(Sender.UserName)|(user)administrator|(hash)6a18137ec1d2ca1105829f460354816b93163878b7e7c20aaae96cd0e927d976%}''. 
Original message: 
--------------------------------------------------------------------------------
{%Message.MessageBody|(resolvebbcode)|(user)administrator|(hash)9be59ccb249f71aa631c3ddfe7279f5da589f7d26f4e525d9892c40078f925ad%} 
--------------------------------------------------------------------------------
You can use following [url={%LogonUrl%}]link[/url] to logon to site and check new message.', N'', N'', N'', N'', N'messaging')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (762, N'newsletter.unsubscriptionrequest', N'Newsletters - Unsubscription request', N'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title>Newsletter</title>
    <meta http-equiv="content-type"
    content="text/html; charset=UTF-8" />
    <style type="text/css">
		h1,h2,h3,h4,h5 { 
			color: #2a537e;
			font-family: Arial;
		} 
		p {
			font-family: Arial;
		} 
		h1 {
			font-size: 16px;
			color: #2a537e;
		}
		h2 {
			font-size: 14px;
		}
		h3 {
			font-size: 12px;
		}
		a {
			color: #000000;
			text-decoration: underline;
		}
		img {
			border: 0;
			padding:0;
			margin: 0;
		}
		body {
			font-family: Arial;
			font-size: 12px;
		}
		#page {
			margin: auto; width: 700px;
		}
	</style>
  </head>
  <body>
    <div id="page">
      <table border="0" cellpadding="0" cellspacing="0" style="width: 696px;">
        <tbody>
          <tr>
            <td>
              <img alt="Company Logo" src="~/App_Themes/CorporateSite/Images/newsletterLogo.png" />
            </td>
          </tr>
          <tr>
            <td style="padding: 20px 0px; text-align: justify;">
            <h1>You have requested unsubscription from our newsletter - {%NewsletterDisplayName|(user)administrator|(hash)3d4e9e15e4c0ee6eaaf80bfc00ed81ee7594a4739bf5d94bc8251c7c84426d67%}.</h1>
            <br />If you would like to unsubscribe please use the following link {%UnsubscribeLink%}</td>
          </tr>
          <tr>
            <td style="border-top: 1px solid rgb(34, 34, 34); padding: 3px 0px;">
              <font color="#222222" size="1">Company, address, state&#160; All rights reserved.</font>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </body>
</html>', NULL, '0e0cbe1c-7349-426a-9937-dd84a20496c2', '20110907 17:20:31', N'You have requested unsubscription from our newsletter - {%NewsletterDisplayName|(user)administrator|(hash)3d4e9e15e4c0ee6eaaf80bfc00ed81ee7594a4739bf5d94bc8251c7c84426d67%}.
If you would like to unsubscribe please use the following link {%UnsubscribeLink%} 
Company, address, state  All rights reserved.', N'Unsubscription request', N'', N'', N'', N'newsletter')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (787, N'ProjectManagement.ChangedTask', N'Project Management - Changed task', N'<html>
  <head>
  <style type="text/css">
    table{      
      border-collapse:collapse;
      width : 600px;
    }
    td{      
      border: solid 1px black;
    }
    .firstColumn{
      width:20%;
    }
  </style>
  </head>  
       <body>
      <table cellspacing="0" cellpadding= "3"   >
        <tr>
                 <td class="firstColumn">
              {$pm.projecttask.id$}: 
                 </td>
           <td>
      {%ProjectTask.ProjectTaskID|(user)administrator|(hash)a1ca301e1401d7df93d3d7bdef8c1282883897cb4532fcf1b68331efc61b8f8a%}
     </td> 
              </tr>  
        <tr>
                 <td>
              {$pm.projecttask.taskname$}:  
                 </td>
           <td>
      {%ProjectTask.ProjectTaskDisplayName|(user)administrator|(hash)d0a60a23f62d60146777a67b085dc89ffc0c93038a4333b05b9f3d206c491a65%}
     </td> 
              </tr>
        <tr>
                 <td>
              {$pm.project.projectname$}:  
                 </td>
           <td>
      {%Project.ProjectDisplayName|(user)administrator|(hash)28efbbb3b4821399f5de62da39ee9ba47bbb52413d9e981ca9b2a234d83218ab%}
     </td> 
              </tr>
        <tr>
                 <td>
              {$general.status$}:  
                 </td>
           <td>
      {%ProjectTaskStatus.TaskStatusDisplayName|(user)administrator|(hash)a39615a754e6d60eade24a7648827d6683a6bf5e23df8cb5f5091e242b8c6c38%}
     </td> 
              </tr>
        <tr>
                 <td>
              {$pm.projecttask.owner$}:  
                 </td>
           <td>
       {%Owner.FullName|(user)administrator|(hash)a07c8912ec15f0e709bfc465c139973f2c6fe3fe7fd71b08f9d6422b0036ab44%} ({%TrimSitePrefix(Owner.UserName)|(user)administrator|(hash)fb61a589a56b4d977b4590f5fddc28b09974b92cecc6b459155b00af89c24794%})
     </td> 
              </tr>
        <tr>
                 <td>
              {$pm.projecttask.asignee$}:  
                 </td>
           <td>
      {%Assignee.FullName|(user)administrator|(hash)a91a9a673f4a4f9b498f6ab5f26289ddadbee2a047617a4ae8fc3dea3da929bd%} ({%TrimSitePrefix(Assignee.UserName)|(user)administrator|(hash)441bad4647c85986419f900c8a528e152f1d191875de3988c2d387c2baba0167%})
     </td> 
              </tr>
        <tr>
                 <td>
              {$pm.project.deadline$}: 
                 </td>
           <td>
      {%ProjectTask.ProjectTaskDeadline|(user)administrator|(hash)f2fd54a0897d8d260dd05975722574f06535cb9449fba20e8d894c3a58d925a5%}
     </td> 
              </tr>
        <tr>
                 <td>
              {$general.Link$}:  
                 </td>
           <td>
      <a href="{%TaskURL%}">{%ProjectTask.ProjectTaskDisplayName|(user)administrator|(hash)d0a60a23f62d60146777a67b085dc89ffc0c93038a4333b05b9f3d206c491a65%}</a>
     </td> 
              </tr>
        <tr>
                 <td>
              {$pm.projecttask.description$}:
                 </td>
           <td>
      {%ProjectTask.ProjectTaskDescription|(encode)false|(user)administrator|(hash)5fcd6f439cb66d2fcac0ac310f7d779e7fa48f68ea2325b5e3a6518490506192%} 
     </td> 
              </tr>
          </table>      
  </body>
</html>', NULL, '2bf93fbb-c906-42c2-ab23-534ead0c36ad', '20111005 17:04:58', N'{$pm.projecttask.id$}: {%ProjectTask.ProjectTaskID|(user)administrator|(hash)a1ca301e1401d7df93d3d7bdef8c1282883897cb4532fcf1b68331efc61b8f8a%}
{$pm.projecttask.taskname$}: {%ProjectTask.ProjectTaskDisplayName|(user)administrator|(hash)d0a60a23f62d60146777a67b085dc89ffc0c93038a4333b05b9f3d206c491a65%}
{$pm.project.projectname$}: {%Project.ProjectDisplayName|(user)administrator|(hash)28efbbb3b4821399f5de62da39ee9ba47bbb52413d9e981ca9b2a234d83218ab%}
{$general.status$}: {%ProjectTaskStatus.TaskStatusDisplayName|(user)administrator|(hash)a39615a754e6d60eade24a7648827d6683a6bf5e23df8cb5f5091e242b8c6c38%}
{$pm.projecttask.owner$}: {%Owner.FullName|(user)administrator|(hash)a07c8912ec15f0e709bfc465c139973f2c6fe3fe7fd71b08f9d6422b0036ab44%} ({%TrimSitePrefix(Owner.UserName)|(user)administrator|(hash)fb61a589a56b4d977b4590f5fddc28b09974b92cecc6b459155b00af89c24794%})
{$pm.projecttask.asignee$}: {%Assignee.FullName|(user)administrator|(hash)a91a9a673f4a4f9b498f6ab5f26289ddadbee2a047617a4ae8fc3dea3da929bd%} ({%TrimSitePrefix(Assignee.UserName)|(user)administrator|(hash)441bad4647c85986419f900c8a528e152f1d191875de3988c2d387c2baba0167%})
{$pm.project.deadline$}: {%ProjectTask.ProjectTaskDeadline|(user)administrator|(hash)f2fd54a0897d8d260dd05975722574f06535cb9449fba20e8d894c3a58d925a5%}
{$general.Link$}: {%TaskURL%}
{$pm.projecttask.description$}: {%ProjectTaskDescriptionPlain%}', N'Project manager notification - task changed', N'', N'', N'', N'projectmanagement')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (788, N'ProjectManagement.NewTask', N'Project Management - New task', N'<html>
  <head>
  <style type="text/css">
    table{      
      border-collapse:collapse;
      width : 600px;
    }
    td{      
      border: solid 1px black;
    }
    .firstColumn{
      width:20%;
    }
  </style>
  </head>  
       <body>
      <table cellspacing="0" cellpadding= "3"   >
        <tr>
                 <td class="firstColumn">
              {$pm.projecttask.id$}: 
                 </td>
           <td>
      {%ProjectTask.ProjectTaskID|(user)administrator|(hash)a1ca301e1401d7df93d3d7bdef8c1282883897cb4532fcf1b68331efc61b8f8a%}
     </td> 
              </tr>  
        <tr>
                 <td>
              {$pm.projecttask.taskname$}:  
                 </td>
           <td>
      {%ProjectTask.ProjectTaskDisplayName|(user)administrator|(hash)d0a60a23f62d60146777a67b085dc89ffc0c93038a4333b05b9f3d206c491a65%}
     </td> 
              </tr>
        <tr>
                 <td>
              {$pm.project.projectname$}:  
                 </td>
           <td>
      {%Project.ProjectDisplayName|(user)administrator|(hash)28efbbb3b4821399f5de62da39ee9ba47bbb52413d9e981ca9b2a234d83218ab%}
     </td> 
              </tr>
        <tr>
                 <td>
              {$general.status$}:  
                 </td>
           <td>
      {%ProjectTaskStatus.TaskStatusDisplayName|(user)administrator|(hash)a39615a754e6d60eade24a7648827d6683a6bf5e23df8cb5f5091e242b8c6c38%}
     </td> 
              </tr>
        <tr>
                 <td>
              {$pm.projecttask.owner$}:  
                 </td>
           <td>
       {%Owner.FullName|(user)administrator|(hash)a07c8912ec15f0e709bfc465c139973f2c6fe3fe7fd71b08f9d6422b0036ab44%} ({%TrimSitePrefix(Owner.UserName)|(user)administrator|(hash)fb61a589a56b4d977b4590f5fddc28b09974b92cecc6b459155b00af89c24794%})
     </td> 
              </tr>
        <tr>
                 <td>
              {$pm.projecttask.asignee$}:  
                 </td>
           <td>
      {%Assignee.FullName|(user)administrator|(hash)a91a9a673f4a4f9b498f6ab5f26289ddadbee2a047617a4ae8fc3dea3da929bd%} ({%TrimSitePrefix(Assignee.UserName)|(user)administrator|(hash)441bad4647c85986419f900c8a528e152f1d191875de3988c2d387c2baba0167%})
     </td> 
              </tr>
        <tr>
                 <td>
              {$pm.project.deadline$}: 
                 </td>
           <td>
      {%ProjectTask.ProjectTaskDeadline|(user)administrator|(hash)f2fd54a0897d8d260dd05975722574f06535cb9449fba20e8d894c3a58d925a5%}
     </td> 
              </tr>
        <tr>
                 <td>
              {$general.Link$}:  
                 </td>
           <td>
      <a href="{%TaskURL|(user)administrator|(hash)60bdefe9971d232f1dd04d8e8b20dbda91ef0e869485b9f84efc82da437a3eac%}">{%ProjectTask.ProjectTaskDisplayName|(user)administrator|(hash)d0a60a23f62d60146777a67b085dc89ffc0c93038a4333b05b9f3d206c491a65%}</a>
     </td> 
              </tr>
        <tr>
                 <td>
              {$pm.projecttask.description$}:
                 </td>
           <td>
      {%ProjectTask.ProjectTaskDescription|(encode)false|(user)administrator|(hash)5fcd6f439cb66d2fcac0ac310f7d779e7fa48f68ea2325b5e3a6518490506192%} 
     </td> 
              </tr>
          </table>      
  </body>
</html>', NULL, 'aed39df2-ba19-4042-adc7-c9850268f8d7', '20110905 17:52:25', N'{$pm.projecttask.id$}: {%ProjectTask.ProjectTaskID|(user)administrator|(hash)a1ca301e1401d7df93d3d7bdef8c1282883897cb4532fcf1b68331efc61b8f8a%}
{$pm.projecttask.taskname$}: {%ProjectTask.ProjectTaskDisplayName|(user)administrator|(hash)d0a60a23f62d60146777a67b085dc89ffc0c93038a4333b05b9f3d206c491a65%}
{$pm.project.projectname$}: {%Project.ProjectDisplayName|(user)administrator|(hash)28efbbb3b4821399f5de62da39ee9ba47bbb52413d9e981ca9b2a234d83218ab%}
{$general.status$}: {%ProjectStatus.TaskStatusDisplayName|(user)administrator|(hash)252bbfaf7b59438f30d8816cdf005a84bc22d6263784daac67bf096545112006%}
{$pm.projecttask.owner$}: {%Owner.FullName|(user)administrator|(hash)a07c8912ec15f0e709bfc465c139973f2c6fe3fe7fd71b08f9d6422b0036ab44%} ({%TrimSitePrefix(Owner.UserName)|(user)administrator|(hash)fb61a589a56b4d977b4590f5fddc28b09974b92cecc6b459155b00af89c24794%})
{$pm.projecttask.asignee$}: {%Assignee.FullName|(user)administrator|(hash)a91a9a673f4a4f9b498f6ab5f26289ddadbee2a047617a4ae8fc3dea3da929bd%} ({%TrimSitePrefix(Assignee.UserName)|(user)administrator|(hash)441bad4647c85986419f900c8a528e152f1d191875de3988c2d387c2baba0167%})
{$pm.project.deadline$}: {%ProjectTask.ProjectTaskDeadline|(user)administrator|(hash)f2fd54a0897d8d260dd05975722574f06535cb9449fba20e8d894c3a58d925a5%}
{$general.Link$}: {%TaskURL|(user)administrator|(hash)60bdefe9971d232f1dd04d8e8b20dbda91ef0e869485b9f84efc82da437a3eac%}
{$pm.projecttask.description$}: {%ProjectTaskDescriptionPlain|(user)administrator|(hash)7df124fe6b8a3004c2f7cae401d86640a8745988b6a73fc06ff503cd50e9ab03%}', N'Project manager notification - task created', N'', N'', N'', N'projectmanagement')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (789, N'ProjectManagement.OverdueTask', N'Project Management - Overdue task', N'<html>
  <head>
  <style type="text/css">
    table{      
      border-collapse:collapse;
      width : 600px;
    }
    td{      
      border: solid 1px black;
    }
    .firstColumn{
      width:20%;
    }
  </style>
  </head>  
       <body>
  <p>
    This is an automatically generated task overdue notification. See task details below.
  </p>
      <table cellspacing="0" cellpadding= "3"   >
        <tr>
                 <td>
              {$pm.projecttask.taskname$}:  
                 </td>
           <td>
      {%ProjectTask.ProjectTaskDisplayName|(user)administrator|(hash)d0a60a23f62d60146777a67b085dc89ffc0c93038a4333b05b9f3d206c491a65%}
     </td> 
              </tr>
       
        <tr>
                 <td>
              {$pm.project.deadline$}:  
                 </td>
           <td>
      {%ProjectTask.ProjectTaskDeadline|(user)administrator|(hash)f2fd54a0897d8d260dd05975722574f06535cb9449fba20e8d894c3a58d925a5%}
     </td> 
              </tr>
        <tr>
                 <td>
              {$general.Link$}:  
                 </td>
           <td>
      <a href="{%TaskURL%}">{%ProjectTask.ProjectTaskDisplayName|(user)administrator|(hash)d0a60a23f62d60146777a67b085dc89ffc0c93038a4333b05b9f3d206c491a65%}</a>
     </td> 
              </tr>
          </table>      
  </body>
</html>', NULL, '71e2cb67-4866-4f61-a2b1-daeaf4cb3b6a', '20110818 14:25:39', N'This is an automatically generated task overdue notification. See task details below.
{$pm.projecttask.taskname$}: {%ProjectTask.ProjectTaskDisplayName|(user)administrator|(hash)d0a60a23f62d60146777a67b085dc89ffc0c93038a4333b05b9f3d206c491a65%}
{$pm.project.deadline$}: {%ProjectTask.ProjectTaskDeadline|(user)administrator|(hash)f2fd54a0897d8d260dd05975722574f06535cb9449fba20e8d894c3a58d925a5%}
{$general.Link$}: {%TaskURL%}', N'Project manager notification - overdue task', N'', N'', N'', N'projectmanagement')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (790, N'ProjectManagement.TaskReminder', N'Project Management - Task reminder', N'<html>
  <head>
  </head>  
       <body>
    <p>
      This is a reminder message related to task <strong>{%ProjectTask.ProjectTaskDisplayName|(user)administrator|(hash)d0a60a23f62d60146777a67b085dc89ffc0c93038a4333b05b9f3d206c491a65%}</strong>, sent by {%currentuser.fullname|(user)administrator|(hash)69c56d41f747c9a5c4c1769bb7351d7a58d4d8bee297a22281d0384390170488%} ({%TrimSitePrefix(currentuser.username)|(user)administrator|(hash)6f5cb37025ed929cf2cd8d26f60a0ce7420c9124264c8d6e729605ea81330e56%}).
    </p>
    <p>
      {%ReminderMessage|(encode)false|(user)administrator|(hash)b3a985ed76577724b34e74acd2b8c6eb4a03611e65729697730469aa4dba4c8a%}
    </p>
    <hr />
    <p>
      Click here <a href="{%TaskURL|(user)administrator|(hash)60bdefe9971d232f1dd04d8e8b20dbda91ef0e869485b9f84efc82da437a3eac%}">{%ProjectTask.ProjectTaskDisplayName|(user)administrator|(hash)d0a60a23f62d60146777a67b085dc89ffc0c93038a4333b05b9f3d206c491a65%}</a> to open the task.
    </p>
  </body>
</html>', NULL, '23eedb5a-1ae6-4a4a-8a34-139eb2b9c54d', '20110905 17:53:17', N'This is a reminder message related to task {%ProjectTask.ProjectTaskDisplayName|(user)administrator|(hash)d0a60a23f62d60146777a67b085dc89ffc0c93038a4333b05b9f3d206c491a65%}({%TaskURL|(user)administrator|(hash)60bdefe9971d232f1dd04d8e8b20dbda91ef0e869485b9f84efc82da437a3eac%}), sent by {%currentuser.fullname|(user)administrator|(hash)69c56d41f747c9a5c4c1769bb7351d7a58d4d8bee297a22281d0384390170488%} ({%TrimSitePrefix(currentuser.username)|(user)administrator|(hash)6f5cb37025ed929cf2cd8d26f60a0ce7420c9124264c8d6e729605ea81330e56%}).
{%ReminderMessagePlain|(user)administrator|(hash)8c36103e505838efd34692108f2b144b56d9ee736e10975b7a63fef1305d7ec2%}', N'Project manager - Reminder', N'', N'', N'', N'projectmanagement')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (874, N'Reporting_Subscription_information', N'Reporting - Subscription confirmation', N'<html>
	<head>
	  <style>
		BODY, TD
		{
		  font-size: 12px; 
		  font-family: arial
		}
	  </style>   
	</head>	
	<body>
      <h3>{%ReportSubscription.ReportSubscriptionSubject|(user)administrator|(hash)b7cdf7d29d2d421e788505ed4b291675111a0a62ee3935dd9611b18f5cbfeff8%}</h3>
	<p>
        You have been successfully subscribed to {%ItemName%}		
       report <strong> {%Report.ReportDisplayName |(user)administrator|(hash)c45b74b873c13296a645071d245baf5b6374ea712145aed8ab552a503f98a9d9%} </strong>.
	<p/>
	<p>
      <a href="{%UnsubscriptionLink%}">Click here to unsubscribe</a>
	</p>
	</body>
</html>', NULL, '8a4938c3-ef94-4bec-b4c9-0a8ecbab8d79', '20120525 15:54:20', N'{%ReportSubscription.ReportSubscriptionSubject|(user)administrator|(hash)b7cdf7d29d2d421e788505ed4b291675111a0a62ee3935dd9611b18f5cbfeff8%}
You have been successfully subscribed to {%ItemName%} report {%Report.ReportDisplayName |(user)administrator|(hash)c45b74b873c13296a645071d245baf5b6374ea712145aed8ab552a503f98a9d9%}.
Click here to unsubscribe:
{%UnsubscriptionLink%}', N'Report subscription information', N'', N'', N'', N'reporting')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (872, N'Report_subscription_template', N'Reporting - Subscription template', N'<html>
  <head>
     <style type="text/css">
        {%DefaultSubscriptionCSS%}
     </style>
  </head>
<body>
    <h3>{%ReportSubscription.ReportSubscriptionSubject|(user)administrator|(hash)b7cdf7d29d2d421e788505ed4b291675111a0a62ee3935dd9611b18f5cbfeff8%}</h3>
    <p>
      {%SubscriptionBody%}
    </p>
    <p>  
      <a href="{%UnsubscriptionLink%}">Click here to unsubscribe</a>
    </p>
</body>
</html>', NULL, 'd7386fb3-f98e-47bf-8833-5574e7945eb9', '20120514 17:40:00', N'{%ReportSubscription.ReportSubscriptionSubject|(user)administrator|(hash)b7cdf7d29d2d421e788505ed4b291675111a0a62ee3935dd9611b18f5cbfeff8%}
{%SubscriptionBody%}
Click here to unsubscribe:
{%UnsubscriptionLink%}', N'', N'', N'', N'', N'reporting')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (873, N'Reporting_Unsubscription_template', N'Reporting - Unsubscription confirmation', N'<html>
	<head>
	  <style>
		BODY, TD
		{
		  font-size: 12px; 
		  font-family: arial
		}
	  </style>
	</head>	
	<body>
	<p>
      <h3>{%ReportSubscription.ReportSubscriptionSubject|(user)administrator|(hash)b7cdf7d29d2d421e788505ed4b291675111a0a62ee3935dd9611b18f5cbfeff8%}</h3>
      
	  You have been successfully unsubscribed from {%ItemName%}		
	report <strong>{%Report.ReportDisplayName|(user)administrator|(hash)5e6d2a502be7a095abe125d8a8c786041e7a32a3055c684166af34661566e186%}</strong>.
	<p/>	
	</body>
</html>', NULL, '5422657c-2602-4f80-a12f-858012baf4b9', '20120504 10:56:48', N'{%ReportSubscription.ReportSubscriptionSubject|(user)administrator|(hash)b7cdf7d29d2d421e788505ed4b291675111a0a62ee3935dd9611b18f5cbfeff8%}
You have been successfully unsubscribed from {%ItemName%} report {%Report.ReportDisplayName|(user)administrator|(hash)5e6d2a502be7a095abe125d8a8c786041e7a32a3055c684166af34661566e186%}.', N'Report unsubscription', N'', N'', N'', N'reporting')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (852, N'scoring.notification', N'Scoring - Notification e-mail', N'<html>
  <head>
  </head>
  <body style="font-size: 12px; font-family: arial">
    <p>
    This is an automatic notification sent by Kentico CMS.
    </p>
    <p>
    Contact {%Contact.ContactFirstName|(user)administrator|(hash)8d1ae22118fb25932bce393233bd8815db88f53efa6fccb9b4f92db678b6cbdb%} {%Contact.ContactLastName|(user)administrator|(hash)858525584f6b00291670d8a0ea9e770f6f17e8b74b5ae57f9d818249b3264faf%} has reached limit in score ''{%Score.ScoreDisplayName|(user)administrator|(hash)8567478ff53a06094262be4655e7dc5006a270827802c0a91ce30095ccab0f0f%}''.
    </p>
    <p>
    Contact''s current score is {%ScoreValue|(user)administrator|(hash)a5d80558851b95f4dfce35c43ea1cfc2887b4b1dd4a3ac314cd3671c562a54d1%}.
    </p>
  </body>
</html>', NULL, '5aea940d-ade5-4419-9f21-4744db45e917', '20110902 15:30:53', N'This is an automatic notification sent by Kentico CMS.
Contact {%Contact.ContactFirstName|(user)administrator|(hash)8d1ae22118fb25932bce393233bd8815db88f53efa6fccb9b4f92db678b6cbdb%} {%Contact.ContactLastName|(user)administrator|(hash)858525584f6b00291670d8a0ea9e770f6f17e8b74b5ae57f9d818249b3264faf%} has reached limit in score ''{%Score.ScoreDisplayName|(user)administrator|(hash)8567478ff53a06094262be4655e7dc5006a270827802c0a91ce30095ccab0f0f%}''.
Contact''s current score is {%ScoreValue|(user)administrator|(hash)a5d80558851b95f4dfce35c43ea1cfc2887b4b1dd4a3ac314cd3671c562a54d1%}.', N'', N'', N'', N'', N'scoring')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (870, N'translationservice.submittranslation', N'Translation services - Submit translation', N'<html>
  <head>
  </head>
  <body style="font-size: 12px; font-family: arial">
    <p>
    Documents have been submitted for translation. The source text and instructions are enclosed in a ZIP file.
    </p>
    <p>
    This submission was created with priority {% GetTranslationPriority(Submission.SubmissionPriority) |(user)administrator|(hash)b75482a8a1fa28d1eb82c226b91f8cd614894ac690320ddee95711806134dbc0%} and is due by {% Submission.SubmissionDeadline |(user)administrator|(hash)8cfb555f2d10ac3e49cfc6591e8fe222c940cce1fff6705761debbc759ce03b0%}.
    </p>
    <p>
    To upload a ZIP archive with the completed translation, click this link: <a href="{% SubmissionLink %}">{% SubmissionLink %}</a>
    </p>
  </body>
</html>', NULL, 'de1a03d4-99b4-4ed5-9451-74cc1e75da4e', '20120824 08:25:12', N'Documents have been submitted for translation. The source text and instructions are enclosed in a ZIP file.
This submission was created with priority {% GetTranslationPriority(Submission.SubmissionPriority) |(user)administrator|(hash)b75482a8a1fa28d1eb82c226b91f8cd614894ac690320ddee95711806134dbc0%} and is due by {% Submission.SubmissionDeadline |(user)administrator|(hash)8cfb555f2d10ac3e49cfc6591e8fe222c940cce1fff6705761debbc759ce03b0%}.
To upload a ZIP archive with the completed translation, go to the following URL {% SubmissionLink %}.', N'New translation submission', N'', N'', N'', N'translationservices')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (160, N'Workflow.Approved', N'Workflow - Document approved', N'<html>
  <head>
  </head>
  <body style="font-size: 12px; font-family: arial">
    <p>
    This is an automatic notification sent by Kentico CMS. The following document was approved.
    </p>
    <p>
    <strong>Document:</strong> <a href="{%DocumentEditUrl%}">{%documentname%}</a> {% ifEmpty(DocumentPreviewUrl, "", "(<a href=\"" + DocumentPreviewUrl + "\">preview</a>)")|(encode)false%}
    <br />
    <br />
    <strong>Approved by:</strong> {%ApprovedBy%}
    <br />
    <strong>Approved when:</strong> {%ApprovedWhen%}
    <br />
    <strong>Original step:</strong> {%originalstepname%}
    <br />
    <strong>Current step:</strong> {%currentstepname%}
    <br />
    <strong>Comment:</strong>
    <br />
    {%Comment%}
    </p>
  </body>
</html>', NULL, '5d4c7b49-0a86-457e-b39c-79be2cc48173', '20111216 17:11:02', N'This is an automatic notification sent by Kentico CMS. The following document was approved. 
Document: [url={%DocumentEditUrl%}]{%documentname%}[/url] {% ifEmpty(DocumentPreviewUrl, "", "([url=" + DocumentPreviewUrl + "]preview[/url])")|(user)administrator|(hash)ce5daaf7bb544b5b988ff411e05fdd066e9a13367425a7ea482797f414c1389d%}
Approved by: {%approvedby%} 
Approved when: {%approvedwhen%} 
Original step: {%originalstepname%} 
Current step: {%currentstepname%} 
Comment: 
{%comment%}', N'Document ''{%DocumentName%}'' approved', N'', N'', N'', N'workflow')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (158, N'Workflow.Archived', N'Workflow - Document archived', N'<html>
  <head>
  </head>
  <body style="font-size: 12px; font-family: arial">
    <p>
    This is an automatic notification sent by Kentico CMS. The following document has been archived.</p>
    <p>
    <strong>Document:</strong> <a href="{%DocumentEditUrl%}">{%documentname%}</a> {% ifEmpty(DocumentPreviewUrl, "", "(<a href=\"" + DocumentPreviewUrl + "\">preview</a>)")|(encode)false%}
    <br />
    <br />
    <strong>Archived by:</strong> {%approvedby%}
    <br />
    <strong>Archived when:</strong> {%approvedwhen%}
    <br />
    <strong>Comment:</strong>
    <br />
    {%comment%}
    </p>
  </body>
</html>', NULL, '53d086cb-dc0c-4e5a-b48d-77a6b58fd549', '20111216 17:11:11', N'This is an automatic notification sent by Kentico CMS. The following document has been archived.
Document: [url={%DocumentEditUrl%}]{%documentname%}[/url] {% ifEmpty(DocumentPreviewUrl, "", "([url=" + DocumentPreviewUrl + "]preview[/url])")|(user)administrator|(hash)ce5daaf7bb544b5b988ff411e05fdd066e9a13367425a7ea482797f414c1389d%}
Archived by: {%approvedby%}
Archived when: {%approvedwhen%}
Comment: 
{%comment%}', N'Document ''{%DocumentName%}'' archived', N'', N'', N'', N'workflow')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (159, N'Workflow.Published', N'Workflow - Document published', N'<html>
  <head>
  </head>
  <body style="font-size: 12px; font-family: arial">
    <p>
    This is an automatic notification sent by Kentico CMS. The following document was published.
    </p>
    <p>
    <strong>Document:</strong> <a href="{%DocumentEditUrl%}">{%documentname%}</a> {% ifEmpty(DocumentPreviewUrl, "", "(<a href=\"" + DocumentPreviewUrl + "\">preview</a>)")|(encode)false%}
    <br />
    <br />
    <strong>Last approved by:</strong> {%approvedby%}
    <br />
    <strong>Last approved when:</strong> {%approvedwhen%}
    <br />
    <strong>Original step:</strong> {%originalstepname%}
    <br />
    <strong>Comment:</strong>
    <br />
    {%comment%}
    </p>
  </body>
</html>', NULL, 'd2c5a1b0-c434-4427-ab81-22c0ca8f2313', '20111216 17:11:21', N'This is an automatic notification sent by Kentico CMS. The following document was published. 
Document: [url={%DocumentEditUrl%}]{%documentname%}[/url] {% ifEmpty(DocumentPreviewUrl, "", "([url=" + DocumentPreviewUrl + "]preview[/url])")|(user)administrator|(hash)ce5daaf7bb544b5b988ff411e05fdd066e9a13367425a7ea482797f414c1389d%}
Last approved by: {%approvedby%} 
Last approved when: {%approvedwhen%} 
Original step: {%originalstepname%} 
Comment: 
{%comment%}', N'Document ''{%DocumentName%}'' published', N'', N'', N'', N'workflow')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (155, N'Workflow.ReadyForApproval', N'Workflow - Document ready for approval', N'<html>
  <head>
  </head>
  <body style="font-size: 12px; font-family: arial">
    <p>
    This is an automatic notification sent by Kentico CMS. The following document is waiting for your approval. Please sign in to Kentico CMS Desk and approve it.
    </p>
    <p>
    <strong>Document:</strong> <a href="{%DocumentEditUrl%}">{%documentname%}</a> {% ifEmpty(DocumentPreviewUrl, "", "(<a href=\"" + DocumentPreviewUrl + "\">preview</a>)")|(encode)false%}
    <br />
    <strong>Last approved by:</strong> {%approvedby%}
    <br />
    <strong>Last approved when:</strong> {%approvedwhen%}
    <br />
    <strong>Original step:</strong> {%originalstepname%}
    <br />
    <strong>Current step:</strong> {%currentstepname%}
    <br />
    <strong>Comment:</strong>
    <br />
    {%comment%}
    </p>
  </body>
</html>', NULL, 'cfa7ee6c-4ee1-4594-9760-d07fe8545336', '20111216 17:11:30', N'This is an automatic notification sent by Kentico CMS. The following document is waiting for your approval. Please sign in to Kentico CMS Desk and approve it. 
Document: [url={%DocumentEditUrl%}]{%documentname%}[/url] {% ifEmpty(DocumentPreviewUrl, "", "([url=" + DocumentPreviewUrl + "]preview[/url])")|(user)administrator|(hash)ce5daaf7bb544b5b988ff411e05fdd066e9a13367425a7ea482797f414c1389d%}
Last approved by: {%approvedby%} 
Last approved when: {%approvedwhen%} 
Original step: {%originalstepname%} 
Current step: {%currentstepname%} 
Comment: 
{%comment%}', N'Document ''{%DocumentName%}'' is waiting for approval', N'', N'', N'', N'workflow')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (156, N'Workflow.Rejected', N'Workflow - Document rejected', N'<html>
  <head>
  </head>
  <body style="font-size: 12px; font-family: arial">
    <p>
    This is an automatic notification sent by Kentico CMS. The following document was rejected.
    </p>
    <p>
    <strong>Document:</strong> <a href="{%DocumentEditUrl%}">{%documentname%}</a> {% ifEmpty(DocumentPreviewUrl, "", "(<a href=\"" + DocumentPreviewUrl + "\">preview</a>)")|(encode)false%}
    <br />
    <br />
    <strong>Rejected by:</strong> {%approvedby%}
    <br />
    <strong>Rejected when:</strong> {%approvedwhen%}
    <br />
    <strong>Original step:</strong> {%originalstepname%}
    <br />
    <strong>Current step:</strong> {%currentstepname%}
    <br />
    <strong>Comment:</strong>
    <br />
    {%comment%}
    </p>
  </body>
</html>', NULL, '5b98fd54-1db8-4f57-b802-c7639fe08184', '20111216 17:11:39', N'This is an automatic notification sent by Kentico CMS. The following document was rejected. 
Document: [url={%DocumentEditUrl%}]{%documentname%}[/url] {% ifEmpty(DocumentPreviewUrl, "", "([url=" + DocumentPreviewUrl + "]preview[/url])")|(user)administrator|(hash)ce5daaf7bb544b5b988ff411e05fdd066e9a13367425a7ea482797f414c1389d%}
Rejected by: {%approvedby%} 
Rejected when: {%approvedwhen%} 
Original step: {%originalstepname%} 
Current step: {%currentstepname%} 
Comment: 
{%comment%}', N'Document ''{%DocumentName%}'' rejected', N'', N'', N'', N'workflow')
INSERT INTO [CMS_EmailTemplate] ([EmailTemplateID], [EmailTemplateName], [EmailTemplateDisplayName], [EmailTemplateText], [EmailTemplateSiteID], [EmailTemplateGUID], [EmailTemplateLastModified], [EmailTemplatePlainText], [EmailTemplateSubject], [EmailTemplateFrom], [EmailTemplateCc], [EmailTemplateBcc], [EmailTemplateType]) VALUES (868, N'Workflow.Notification', N'Workflow - Notification', N'<html>
  <head>
  </head>
  <body style="font-size: 12px; font-family: arial">
    <p>
    This is an automatic notification sent by Kentico CMS. The following document status has changed.
    </p>
    <p>
    <strong>Document:</strong> <a href="{%DocumentEditUrl%}">{%documentname%}</a> {% ifEmpty(DocumentPreviewUrl, "", "(<a href=\"" + DocumentPreviewUrl + "\">preview</a>)")|(encode)false%}
    <br />
    <br />
    <strong>Action:</strong> {%ActionName%}
    <br />
    <strong>Modified by:</strong> {%User.Email|(user)administrator|(hash)43dcbe191cf3d851a43356357f77d048c9b9baa642c5258cea3c54b26cfecd4b%}
    <br />
    <strong>Modified when:</strong> {%approvedwhen%}
    <br />
    <strong>Original step:</strong> {%originalstepname%}
    <br />
    <strong>Current step:</strong> {%currentstepname%}
    <br />
    <strong>Comment:</strong>
    <br />
    {%comment%}
    </p>
  </body>
</html>', NULL, '27f608f0-0a20-4a1b-9474-97bde3c7a725', '20120522 07:56:59', N'This is an automatic notification sent by Kentico CMS. The following document status has changed. 
Document: [url={%DocumentEditUrl%}]{%documentname%}[/url] {% ifEmpty(DocumentPreviewUrl, "", "([url=" + DocumentPreviewUrl + "]preview[/url])")|(user)administrator|(hash)ce5daaf7bb544b5b988ff411e05fdd066e9a13367425a7ea482797f414c1389d%}
Action: {%ActionName%} 
Modified by: {%User.Email|(user)administrator|(hash)43dcbe191cf3d851a43356357f77d048c9b9baa642c5258cea3c54b26cfecd4b%} 
Modified when: {%approvedwhen%} 
Original step: {%originalstepname%} 
Current step: {%currentstepname%} 
Comment: 
{%comment%}', N'Document ''{%DocumentName%}'' status changed', N'', N'', N'', N'workflow')
SET IDENTITY_INSERT [CMS_EmailTemplate] OFF
