SET IDENTITY_INSERT [CMS_Transformation] ON
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (1115, N'AtomItem', N'<entry>
  <title><%# EvalCDATA("DocumentName") %></title>
  <link href="<%# GetAbsoluteUrl(GetDocumentUrlForFeed(), Eval("SiteName")) %>" />
  <id>urn:uuid:<%# Eval("NodeGUID") %></id>
  <published><%# GetAtomDateTime(Eval("DocumentCreatedWhen")) %></published>
  <updated><%# GetAtomDateTime(Eval("DocumentModifiedWhen")) %></updated>
  <author>
    <name><%# Eval("NodeOwnerFullName") %></name>
  </author>
  <summary><%# EvalCDATA("NodeAliasPath") %></summary>
</entry>', N'ascx', 1095, N'c9bf954b-0f95-491e-9c8e-6cd658308071', 'ce31d65b-f97e-4967-824c-c65bb10543ad', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (676, N'Attachment', N'<%@ Register TagPrefix="cc1" Namespace="CMS.GlobalHelper" Assembly="CMS.GlobalHelper" %>
<div>
<a target="_blank" href="<%# GetAbsoluteUrl(GetAttachmentUrl(Eval("AttachmentName"), Eval("NodeAliasPath")), Eval<int>("AttachmentSiteID")) %>">
<img style="border: none;" src="<%# IfCompare(ImageHelper.IsImage((string)Eval("AttachmentExtension")), true, GetAttachmentIconUrl(Eval("AttachmentExtension"), null), GetAbsoluteUrl(GetAttachmentUrl(Eval("AttachmentName"), Eval("NodeAliasPath")), Eval<int>("AttachmentSiteID"))) %>?maxsidesize=150" alt="<%# Eval("AttachmentName", true) %>" />
</a>
<%# IfCompare(ImageHelper.IsImage((string)Eval("AttachmentExtension")), true, "<br />" + ResHelper.GetString("attach.openfile"), "") %>
<br />
<%# Eval("AttachmentName",true) %>
<br />
</div>', N'ascx', 1095, N'06df7da2-6dfe-445a-b9f1-83c04456ac81', '6eba21c8-7c1a-49a6-937e-974627c9224b', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (1982, N'AttachmentCarousel2D', N'<%@ Register TagPrefix="cc1" Namespace="CMS.GlobalHelper" Assembly="CMS.GlobalHelper" %>
<%# IfCompare(ImageHelper.IsImage((string)Eval("AttachmentExtension")), true,"<li><div style=''text-align:center;''><div style=''font-size: 11px;line-height: 12px;position:relative;z-index:1000;margin:auto;''><a target=''_blank'' href=''" + GetAbsoluteUrl(GetAttachmentUrl(Eval("AttachmentName"), Eval("NodeAliasPath")), Eval<int>("AttachmentSiteID")) + "''><img style=''border: none;'' src=''" + GetAttachmentIconUrl(Eval("AttachmentExtension"), null) + "'' alt=''" + Eval("AttachmentName") + "'' /></a></div><p>" + ResHelper.GetString("attach.openfile") + "</p></div></li>",
"<li><img src=''" + GetAbsoluteUrl(GetAttachmentUrl(Eval("AttachmentName"), Eval("NodeAliasPath")), Eval<int>("AttachmentSiteID")) + "?maxsidesize=150'' class=''cloudcarousel2d'' alt=''" + Eval("AttachmentTitle", true) + "'' title=''" + Eval("AttachmentDescription", true) + "'' /></li>") %>', N'ascx', 1095, N'be1141f6-3344-40a1-a4f1-3ea35a11121f', '1813bc8e-8791-4a0a-b6b2-acb90f0fa599', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (1739, N'AttachmentCarousel3D', N'<%@ Register TagPrefix="cc1" Namespace="CMS.GlobalHelper" Assembly="CMS.GlobalHelper" %>
<%# IfCompare(ImageHelper.IsImage((string)Eval("AttachmentExtension")), true,
"<div style=\"text-align:center;width: 350px;\"><div style=\"font-size: 11px;line-height: 12px;position:relative;z-index:1000;margin:auto;width:140px;\"><a target=\"_blank\" href=\"" + GetAbsoluteUrl(GetAttachmentUrl(Eval("AttachmentName"), Eval("NodeAliasPath")), Eval<int>("AttachmentSiteID")) + "\"><img style=\"border: none;\" src=\"" + GetAttachmentIconUrl(Eval("AttachmentExtension"), null) + "\" alt=\"" + Eval("AttachmentName") + "\" /></a><p>" + ResHelper.GetString("attach.openfile") + "</p></div></div>",
"<img src=\"" + GetAbsoluteUrl(GetAttachmentUrl(Eval("AttachmentName"), Eval("NodeAliasPath")), Eval<int>("AttachmentSiteID")) + "?maxsidesize=150\" class=\"cloudcarousel3d\" alt=\"" + Eval("AttachmentTitle", true) + "\" title=\"" + Eval("AttachmentDescription", true) + "\" />") %>', N'ascx', 1095, N'70d3e8e3-38b0-4e60-9739-15811edb997d', '49c7568b-113e-41eb-b183-4712344811a3', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (713, N'AttachmentLightbox', N'<%@ Register TagPrefix="cc1" Namespace="CMS.GlobalHelper" Assembly="CMS.GlobalHelper" %>
<a style="text-decoration: none;" href="<%# GetAbsoluteUrl(GetAttachmentUrl(Eval("AttachmentName"), Eval("NodeAliasPath")), Eval<int>("AttachmentSiteID")) %>" rel="lightbox" rev="<%# Eval("AttachmentID") %>" title="<%# Eval("AttachmentName", true) %>">
<img style="border: none;" src="<%# IfCompare(ImageHelper.IsImage((string)Eval("AttachmentExtension")), true, GetAttachmentIconUrl(Eval("AttachmentExtension"), null), GetAbsoluteUrl(GetAttachmentUrl(Eval("AttachmentName"), Eval("NodeAliasPath")), Eval<int>("AttachmentSiteID"))) %>?maxsidesize=150" alt="<%# Eval("AttachmentTitle", true) %>" />
</a>', N'ascx', 1095, N'4c43f013-5f63-4f69-9841-ee5c49682366', 'f0460e74-2509-4b1e-8665-5e68cf947e86', '20120911 12:17:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (714, N'AttachmentLightboxDetail', N'<%@ Register TagPrefix="cc1" Namespace="CMS.GlobalHelper" Assembly="CMS.GlobalHelper" %>
<%# IfCompare(ImageHelper.IsImage((string)Eval("AttachmentExtension")), true,
"<div style=\"text-align:center;width: 350px;\"><div style=\"font-size: 11px;line-height: 12px;position:relative;z-index:1000;margin:auto;width:140px;\"><a target=\"_blank\" href=\"" + GetAbsoluteUrl(GetAttachmentUrl(Eval("AttachmentName"), Eval("NodeAliasPath")), Eval<int>("AttachmentSiteID")) + "\"><img style=\"border: none;\" src=\"" + GetAttachmentIconUrl(Eval("AttachmentExtension"), null) + "\" alt=\"" + Eval("AttachmentName") + "\" /></a><p>" + ResHelper.GetString("attach.openfile") + "</p></div></div>",
"<img src=\"" + GetAbsoluteUrl(GetAttachmentUrl(Eval("AttachmentName"), Eval("NodeAliasPath")), Eval<int>("AttachmentSiteID")) + "?maxsidesize=1000\" alt=\"" + Eval("AttachmentTitle", true) + "\" title=\"" + Eval("AttachmentDescription", true) + "\" />") %>', N'ascx', 1095, N'7c2aa7a9-33e6-492a-929c-d203c62f80c4', 'fdad8271-1293-4444-9151-e74af81dcda6', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (841, N'AttachmentList', N'<div>
<img src="<%# GetAttachmentIconUrl(Eval("AttachmentExtension"), "List") %>" alt="<%# Eval("AttachmentName",true) %>" />
&nbsp;
<a target="_blank" href="<%# GetAbsoluteUrl(GetAttachmentUrl(Eval("AttachmentName"), Eval("NodeAliasPath")), EvalInteger("AttachmentSiteID")) %>">
<%# Eval("AttachmentName",true) %>
</a>
</div>', N'ascx', 1095, N'a89f3592-7d5a-47c5-baef-16711c28ab09', '4455961a-e81f-419b-8a68-19d1cdcef2a1', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (415, N'CategoryList', N'<asp:PlaceHolder ID="plcCategoryList" runat="server" EnableViewState="false"></asp:PlaceHolder><br />', N'ascx', 1095, N'5a29be2d-6bba-42df-9ccc-5a406ecd1b82', '4b6c6f44-ac26-45c1-920f-df48f92e94d0', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (915, N'CMSDeskSmartSearchResults', N'<div style="margin-bottom: 30px;">
  <%-- Search result image --%>
        <div style="border: solid 1px #eeeeee; width: 90px; height:90px; margin-right: 5px;" class="LeftAlign">
          <img src="<%# GetSearchImageUrl("CMSModules/CMS_SmartSearch/no_image.gif",90) %>" alt="" />
        </div>
        <div class="LeftAlign">
            <%-- Search result title --%>
            <div style="text-align: left;">
                <a style="font-weight: bold" href="<%# "javascript:SelectItem(" + CMS.ExtendedControls.ControlsHelper.RemoveDynamicControls(ValidationHelper.GetString(GetSearchValue("nodeId"), "")) + ", ''"+ ValidationHelper.GetString(GetSearchValue("DocumentCulture"), "") + "'')" %>">
                    <%#SearchHighlight(CMS.GlobalHelper.HTMLHelper.HTMLEncode(DataHelper.GetNotEmpty(Eval("Title"), "/")), "<span style=''font-weight:bold;''>", "</span>")%> (<%#ValidationHelper.GetString(GetSearchValue("DocumentCulture"), "")%>)
                </a>
            </div>
            <%-- Search result content --%>
            <div style="margin-top: 5px; width: 590px;min-height:40px">
                <%#SearchHighlight(CMS.GlobalHelper.HTMLHelper.HTMLEncode(TextHelper.LimitLength(HttpUtility.HtmlDecode(CMS.GlobalHelper.HTMLHelper.StripTags(CMS.ExtendedControls.ControlsHelper.RemoveDynamicControls(GetSearchedContent(DataHelper.GetNotEmpty(Eval("Content"), ""))), false, " ")), 280, "...")), "<span style=''background-color: #FEFF8F''>", "</span>")%><br />
            </div>
            <%-- Relevance, URL, Creattion --%>
            <div style="margin-top: 5px;">
                <%-- Relevance --%>
                <div title="Relevance: <%# Convert.ToInt32(ValidationHelper.GetDouble(Eval("Score"),0.0)*100) %>%"
                    style="width: 50px; border: solid 1px #aaaaaa; margin-top: 7px; margin-right: 6px;
                    float: left; color: #0000ff; font-size: 2pt; line-height: 4px; height: 4px;">
                    <div style="<%# "background-color:#a7d3a7;width:"+ Convert.ToString(Convert.ToInt32((ValidationHelper.GetDouble(Eval("Score"),0.0)/2)*100))  + "px;height:4px;line-height: 4px;"%>">
                    </div>
                </div>
                <%-- URL --%>
                <span style="color: #008000">
                    <%# TextHelper.BreakLine(SearchHighlight(SearchResultUrl(true),"<strong>","</strong>"),75,"<br />") %>
                </span>
                <%-- Creation --%>
                <span style="padding-left:5px;color: #888888; font-size: 9pt">
                    <%# GetDateTimeString(ValidationHelper.GetDateTime(Eval("Created"), DateTimeHelper.ZERO_TIME), true) %>
                </span>
            </div>
        </div>
        <div style="clear: both">
        </div>
    </div>', N'ascx', 1095, N'0a9202a8-ea53-4ccd-8bab-b2142e479b31', 'aadecc4c-1909-4804-b0bb-990c093fc4e0', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (916, N'CMSDeskSQLSearchResults', N'<div style="margin-bottom: 30px;">
  <%-- Search result image --%>
        <div style="margin-right: 5px;" class="LeftAlign">
           <img src="<%# UIHelper.GetDocumentTypeIconUrl(this.Page, ValidationHelper.GetString(DataBinder.Eval(((System.Web.UI.WebControls.RepeaterItem)(Container)).DataItem, "ClassName"), "")) %>" alt="" />
        </div>
        <div class="LeftAlign" style="width:95%;">
            <%-- Search result title --%>
            <div>
        <a style="font-weight: bold" href="<%# "javascript:SelectItem(" + Eval("NodeID") + ", \''" + Eval("DocumentCulture") + "\'')" %>"><%# IfEmpty(Eval("NodeName"), "/", HTMLHelper.HTMLEncode(ValidationHelper.GetString(Eval("DocumentName"), null))) %> (<%# Eval("DocumentCulture") %>)</a>
            </div>
</div>
<div class="LeftAlign">
  <div style="margin-top: 5px;">
<%-- URL --%>
                <span style="color: #008000">
                    <%#  GetAbsoluteUrl(GetDocumentUrl()) %>
                </span>
                <%-- Creation --%>
                <span style="padding-left:5px;;color: #888888; font-size: 9pt">
                    <%# GetDateTimeString(ValidationHelper.GetDateTime(Eval("DocumentCreatedWhen"), DateTimeHelper.ZERO_TIME), true) %>
                </span>
        </div>
  </div>
<div style="clear: both"></div>
</div>', N'ascx', 1095, N'375a9105-41c3-4b7a-9ea1-bc8396cc3dce', '914377c1-21ad-443e-956f-0b9646e5520b', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2226, N'Empty', N'', N'ascx', 1095, N'0b4a1336-ffc2-43d4-a761-d1d4f905d5fb', '8fe2f25d-5319-4c07-a9a1-1cc8c70aecdb', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (668, N'GoogleSiteMap', N'<url>
<%# GetSitemapItem("loc") %>
<%# GetSitemapItem("lastmod") %>
<%# GetSitemapItem("changefreq") %>
<%# GetSitemapItem("priority") %>
</url>', N'ascx', 1095, N'04830bdd-6431-4014-be43-580db3a34498', '8d5a6991-b2bf-436d-ba82-5159eb98fc71', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (153, N'Newsletter_Archive', N'<%#  FormatDateTime(Eval("IssueMailoutTime"),"d") %> - <a href="~/CMSModules/Newsletters/CMSPages/GetNewsletterIssue.aspx?issueId=<%# Eval("IssueID")%>" target="_blank"><%# Eval("IssueSubject",true) %></a> <br />', N'ascx', 1095, N'28693fbb-07e8-4519-bcc7-d055380b337a', '62116172-2118-4676-98eb-373c79fa6cc6', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (559, N'OnLineUsers', N'<%# Eval("UserName", true) %>&nbsp;', N'ascx', 1095, N'54811984-5e77-4ccd-9f17-67eea22a925f', '3b16b39e-3020-485d-8bae-6e7617e13894', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (3371, N'Parameters', N'<br />', N'ascx', 1095, N'1b1c3053-6464-43c2-ad8e-8daa4a891738', '14585af1-bf3a-4b68-8ad1-3aa5f40dda92', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (283, N'Print', N'<h3>Print transformation is missing</h3>
<div>Transformation of current document type is missing. You have to define the tranformation in the CMS Site Manager Development section.</div>', N'ascx', 1095, N'e51fbd68-cfb7-48f7-9201-98e1dcd46b73', 'dfba986c-38de-431c-89df-8ad3e8c7b451', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (15, N'RelatedDocuments', N'<strong><a href="<%# ResolveUrl(GetUrl( Eval("NodeAliasPath"), null)) %>">
<%# Eval("DocumentName",true) %></a></strong>
<br />', N'ascx', 1095, N'bddcc360-c7a0-4e9a-8304-f9e995927d7f', 'b96f0a40-8fb6-4ed5-8eaa-309867a18283', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (1019, N'RSSItem', N'<item>
     <guid isPermaLink="false"><%# Eval("NodeGUID") %></guid>
     <title><%# EvalCDATA("DocumentName") %></title>
     <description><%# EvalCDATA("NodeAliasPath") %></description>
     <pubDate><%# GetRSSDateTime(Eval("DocumentCreatedWhen")) %></pubDate>
     <link><![CDATA[<%# GetAbsoluteUrl(GetDocumentUrlForFeed(), Eval("SiteName")) %>]]></link>     	
</item>', N'ascx', 1095, N'94c6b3c2-870a-4b5d-9aec-6c797497f78e', 'e38315ed-fcef-46a9-b82a-b33d6902649b', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (20, N'SearchResults', N'<div class="SearchResult">
  <div class="ResultTitle">
    <a href="<%# GetDocumentUrl()%>"><%# IfEmpty(Eval("SearchResultName",true), "/", Eval("SearchResultName",true)) %></a>
  </div>
  <div class="ResultPath">
    Path: <%# Eval("DocumentNamePath",true) %><br />
  </div>
</div>', N'ascx', 1095, N'613f21c8-d104-4f6a-863c-a7373bce453d', 'a3c543c8-b855-4acd-9c03-9302a02f8f74', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (801, N'SmartSearchResults', N'<div style="margin-bottom: 30px;">
        <%-- Search result title --%>
        <div>
            <a style="font-weight: bold" href=''<%# SearchResultUrl(true) %>''>
                <%#SearchHighlight(CMS.GlobalHelper.HTMLHelper.HTMLEncode(CMS.ExtendedControls.ControlsHelper.RemoveDynamicControls(DataHelper.GetNotEmpty(Eval("Title"), "/"))), "<span style=''font-weight:bold;''>", "</span>")%>
            </a>
        </div>
        <%-- Search result content --%>
        <div style="margin-top: 5px; width: 590px;">
            <%#SearchHighlight(CMS.GlobalHelper.HTMLHelper.HTMLEncode(TextHelper.LimitLength(HttpUtility.HtmlDecode(CMS.GlobalHelper.HTMLHelper.StripTags(CMS.ExtendedControls.ControlsHelper.RemoveDynamicControls(GetSearchedContent(DataHelper.GetNotEmpty(Eval("Content"), ""))), false, " ")), 280, "...")), "<span style=''background-color: #FEFF8F''>", "</span>")%><br />
        </div>
        <%-- Relevance, URL, Creattion --%>
        <div style="margin-top: 5px;">
            <%-- Relevance --%>
            <div title="Relevance: <%# Convert.ToInt32(ValidationHelper.GetDouble(Eval("Score"),0.0)*100)%>%"
                style="width: 50px; border: solid 1px #aaaaaa; margin-top: 7px; margin-right: 6px; float: left; color: #0000ff; font-size: 2pt; line-height: 4px; height: 4px;">
                <div style=''<%# "background-color:#a7d3a7;width:"+ Convert.ToString(Convert.ToInt32((ValidationHelper.GetDouble(Eval("Score"),0.0)/2)*100))  + "px;height:4px;line-height: 4px;"%>''>
                </div>
            </div>
            <%-- URL --%>
            <span style="color: #008000">
                <%# SearchHighlight(SearchResultUrl(true),"<strong>","</strong>")%>
            </span>
            <%-- Creation --%>
            <span style="color: #888888; font-size: 9pt">
                <%# GetDateTimeString(ValidationHelper.GetDateTime(Eval("Created"), DateTimeHelper.ZERO_TIME), true) %>
            </span>
        </div>
    </div>', N'ascx', 1095, N'df175550-5824-45a2-a69d-9528f42b9b7c', '63b96721-59ae-4462-a842-10fedfc282e1', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (846, N'SmartSearchResultsWithImages', N'<div style="margin-bottom: 30px;">
  <%-- Search result image --%>
        <div style="float: left; border: solid 1px #eeeeee; width: 90px; height:90px; margin-right: 5px;">
           <img src="<%# GetSearchImageUrl("/CMSModules/CMS_SmartSearch/no_image.gif",90) %>" alt="" />
        </div>
        <div style="float: left">
            <%-- Search result title --%>
            <div>
                <a style="font-weight: bold" href=''<%# SearchResultUrl(true) %>''>
                    <%#SearchHighlight(CMS.GlobalHelper.HTMLHelper.HTMLEncode(CMS.ExtendedControls.ControlsHelper.RemoveDynamicControls(DataHelper.GetNotEmpty(Eval("Title"), "/"))), "<span style=''font-weight:bold;''>", "</span>")%>
                </a>
            </div>
            <%-- Search result content --%>
            <div style="margin-top: 5px; width: 590px;min-height:40px">
                <%#SearchHighlight(CMS.GlobalHelper.HTMLHelper.HTMLEncode(TextHelper.LimitLength(HttpUtility.HtmlDecode(CMS.GlobalHelper.HTMLHelper.StripTags(CMS.ExtendedControls.ControlsHelper.RemoveDynamicControls(GetSearchedContent(DataHelper.GetNotEmpty(Eval("Content"), ""))), false, " ")), 280, "...")), "<span style=''background-color: #FEFF8F''>", "</span>")%><br />
            </div>
            <%-- Relevance, URL, Creattion --%>
            <div style="margin-top: 5px;">
                <%-- Relevance --%>
                <div title="Relevance: <%#Convert.ToInt32(ValidationHelper.GetDouble(Eval("Score"),0.0)*100)%>%"
                    style="width: 50px; border: solid 1px #aaaaaa; margin-top: 7px; margin-right: 6px;
                    float: left; color: #0000ff; font-size: 2pt; line-height: 4px; height: 4px;">
                    <div style="<%# "background-color:#a7d3a7;width:"+ Convert.ToString(Convert.ToInt32((ValidationHelper.GetDouble(Eval("Score"),0.0)/2)*100))  + "px;height:4px;line-height: 4px;"%>">
                    </div>
                </div>
                <%-- URL --%>
                <span style="color: #008000">
                    <%# TextHelper.BreakLine(SearchHighlight(SearchResultUrl(true),"<strong>","</strong>"),75,"<br />") %>
                </span>
                <%-- Creation --%>
                <span style="padding-left:5px;color: #888888; font-size: 9pt">
                    <%# GetDateTimeString(ValidationHelper.GetDateTime(Eval("Created"), DateTimeHelper.ZERO_TIME), true) %>
                </span>
            </div>
        </div>
        <div style="clear: both">
        </div>
    </div>', N'ascx', 1095, N'e4b519fd-39a8-47e6-b041-7b17fca3fc66', 'fa253f7c-6705-4995-bb27-96c0042dee5b', '20120828 10:35:54', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2646, N'ChatError', N'<span style="color:#FF0000">{{html Message}}</span> 
    <a href="#" onclick="${Delete}" > [X]</a>', N'jquery', 3140, N'254675f6-54d1-44ed-b6be-cd1beeef8e76', '4a59194f-bd11-4351-bd38-de1ce84f7f1e', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2647, N'ChatErrorDeleteAllBtn', N'<a href="#" onclick="${DeleteAll}">{$chat.closeall$}</a>', N'jquery', 3140, N'82b32ece-dc75-41a1-b838-4e0ef011a492', '70e881e1-3189-4241-8369-214fa81147d6', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2648, N'ChatMessage', N'<div class="ChatMessage">
{{if System}}
	<span class="System">${LastModified.toLocaleTimeString()}:
	<span class="Message System{{if (System == 7) || (System == 10)}} Greeting{{/if}}"> ${MessageText}</span> </span>
{{else}}
	{{if RejectMessage}}
        	<div class="RejectButton">
                	<a href="#" onclick="${RejectMessage}">
                        	<img src=''{%GetImageUrl("CMSModules/CMS_Chat/reject.png")|(user)administrator|(hash)a3d1d46239c6eed35c7d78c536e06491d223e55dc3a18abaa5e086223597916e%}'' alt="{$chat.rejectmessage$}" title="{$chat.rejectmessage$}" width="8px" height="8px"/>
                	</a>
        	</div>
        {{/if}}
  	<span class="PostedTime">${PostedTime.toLocaleTimeString()}</span>
        {{if Modified}}
        	<span class="Modified">({$chat.messagemodified$} ${LastModified.toLocaleTimeString()})</span>
        {{/if}}
        
        {{if (Whisper && !IsOneOnOne)}}
        	<span class="Whisper">
                <strong>
                	{{if SelectRecipient}}
                		{$chat.from$} 
                         <a href="#" onclick="${SelectRecipient}">${Nickname}</a>   
                     {{else}}
                        {$chat.to$}
                          {{if (SelectPrevRecipient)}}
                             <a href="#" onclick="${SelectPrevRecipient}">${Recipient}</a>
                          {{else}}
                              ${Recipient}
                          {{/if}}
                     {{/if}}
                </strong>
                        	
        {{else}}
        	<strong>
                	{{if (SelectRecipient && !IsOneOnOne)}}
                        	<a href="#" onclick="${SelectRecipient}">${Nickname}</a>
                        {{else}}
                        	${Nickname}
                        {{/if}}
                </strong>
        {{/if}}:
        {{if Rejected}}
        	<span class="Rejected">{$chat.messagerejected$}</span>
        {{else}}
        	<span class="Message">${MessageText}</span>
        {{/if}}
        
        {{if (Whisper && !IsOneOnOne)}}
        	</span>
        {{/if}}
{{/if}}
</div>', N'jquery', 3140, N'e104deb5-5817-42da-b218-ae0fcb29c533', 'ca883224-656b-4018-afd6-0abeab006458', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2649, N'ChatNotification', N'{{if NotificationType == 0}}
	<td>{$chat.user$} <b><span>${SenderNickname}</span></b>
	{{if IsOneToOne}}
        	{$chat.invitedyoutoaprivateconversation$}.
        {{else}}
	 	{$chat.invitedyou$} <b><span>${RoomName}</span></b>.
        {{/if}}
        </td><td class="ChatNotificationButtons"><input class="SubmitButton ChatNotificationButton" onclick="${AcceptEvent}" type="button" value="{$chat.accept$}" /><input class="SubmitButton ChatNotificationButton" onclick="${DeclineEvent}" type="button" value="{$chat.decline$}" /></td>
{{else}}
	<td>
	{{if NotificationType == 1}}
        	{$chat.user$} <b><span>${SenderNickname}</span></b> 
                {{if IsOneToOne}}
                	{$chat.declinedprivate$}.
                {{else}}
                	{$chat.declined$} <b><span>${RoomName}</span></b>.
                {{/if}}
        {{/if}}
        {{if NotificationType == 2}}
        	{$chat.user$} <b><span>${SenderNickname}</span></b> 
                {{if IsOneToOne}}
                	{$chat.acceptedprivate$}.
                {{else}}
                	{$chat.accepted$} <b><span>${RoomName}</span></b>.
                {{/if}}
        {{/if}}
        {{if NotificationType == 3}}{$chat.nicknamechanged$}.{{/if}}
        {{if NotificationType == 4}}{$chat.user$} <b><span>${SenderNickname}</span></b> {$chat.kicked$} <b><span>${RoomName}</span></b>. {{if KickTime}} {$chat.kickreturn$} <b>${KickTime}</b>.{{/if}}{{/if}}
        {{if NotificationType == 5}}{$chat.user$} <b><span>${SenderNickname}</span></b> {$chat.kickedperm$} <b><span>${RoomName}</span></b>.{{/if}}
        {{if NotificationType == 6}}{$chat.user$} <b><span>${SenderNickname}</span></b> {$chat.adminadded$} <b><span>${RoomName}</span></b>.{{/if}}
        {{if NotificationType == 7}}{$chat.user$} <b><span>${SenderNickname}</span></b> {$chat.admindeleted$} <b><span>${RoomName}</span></b>.{{/if}}
        </td>
        <td class="ChatNotificationButtons">
        	<input class="SubmitButton ChatNotificationButton" onclick="${CloseEvent}" type="button" value="{$chat.delete$}" />
        </td>
{{/if}}', N'jquery', 3140, N'b82c7eb7-2609-4ebd-b067-2b61ce7c4901', '96c1e946-bde9-490d-ada9-e29c20b32e57', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2650, N'ChatOnlineUser', N'{{if IsCurrentUser}}<span style="color:#0000FF">${Nickname}</span> {{else}}<a href="#" onclick="${OnClick}" target="_blank">${Nickname}</a>{{/if}}', N'jquery', 3140, N'f6be653a-c7e9-429d-9fd3-c7d6a072726a', 'de0784dd-6b73-4188-84c3-3d9bf8700dd4', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2651, N'ChatRooms', N'<div class="ChatRoomListItem">
        {{if Abandon}}
        <div class="AbandonButton">
        	<a href="#" onclick="${Abandon}">
                	<img src=''{%GetImageUrl("CMSModules/CMS_Chat/delete.png")|(user)administrator|(hash)f1c16085718aac4f4cdd11f3b02191c57352fb034ff2f1cf37ebb263f2cedd53%}'' alt="{$chat.abandon$}" title="{$chat.abandon$}" width="12px" height="12px"/>
                </a>
        </div>        
        {{/if}}
        
        {{if Delete}}
        <div class="DeleteButton">
        	<a href="#" onclick="${Delete}">
                	<img src=''{%GetImageUrl("CMSModules/CMS_Chat/reject.png")|(user)administrator|(hash)a3d1d46239c6eed35c7d78c536e06491d223e55dc3a18abaa5e086223597916e%}'' alt="{$general.disable$}" title="{$general.disable$}" width="12px" height="12px"/>
                </a>
        </div>        
        {{/if}}
        
        {{if Edit}}
        <div class="EditButton">
        	<a href="#" onclick="${Edit}">
                	<img src=''{%GetImageUrl("CMSModules/CMS_Chat/edit.png")|(user)administrator|(hash)2311ac4df3f97480fb0661492a7485479a216cda0d427dce1adcebd23bdf8b7e%}'' alt="{$general.edit$}" title="{$general.edit$}" width="12px" height="12px"/>
                </a>
        </div>        
        {{/if}}
        
        <div class="ChatRoomTitle"><!-- Do not change this class name -->
	    {{if IsCurrentRoom}}
        	<strong><span style="color: blue;">
        {{else}}
        	<a href="#" title="{$chat.enter$}" class="JoinRoom"> <!-- Do not change this class name -->
                {{if IsCurrentUserIn}}
                	<strong>
                {{/if}}
        {{/if}}
	        
        ${DisplayName}
        (${OnlineUsersCount})
                
        {{if IsCurrentRoom}}
        	</span></strong>
        {{else}}
        	{{if IsCurrentUserIn}}
        		</strong>
            {{/if}}
            </a>
        {{/if}}  
  
        <span class="ChatRoomInfoIcons">   
        {{if IsPrivate}}
            <img src=''{%GetImageUrl("CMSModules/CMS_Chat/private_room16.png")|(user)administrator|(hash)0d6913df7ec8f6d683f49cfabe7a95bff11a146b08ea7e23369e7b7d71555d26%}'' alt="{$chat.privateroom$}" title="{$chat.privateroom$}" width="12px" height="12px"/>
        {{/if}}
        {{if HasPassword}}
            <img src=''{%GetImageUrl("CMSModules/CMS_Chat/password.png")|(user)administrator|(hash)5e9272e8fc8bcadc444ee335c7fb2fc956b33f5db14ff1e1e5e94ac2b659195c%}'' alt="{$chat.passwordprotected$}" title="{$chat.passwordprotected$}" width="12px" height="12px"/>
        {{/if}}
        </span>
        </div>
        
        {{if Description != ""}}
        	<div class="ChatRoomListItemDescription">${Description}</div>
        {{/if}}
</div>', N'jquery', 3140, N'5c1788a3-854c-4b8f-8e6b-fad00a4db9d0', 'd2396311-25ad-4f54-9c44-c80d071c72ac', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2652, N'ChatRoomUser', N'<div class="ChatRoomUser {{if IsOnline}}OnlineUser{{else}}OfflineUser{{/if}}">
  {{if KickUserPerm}}
      <div class="PermaKickButton">
              <a href="#" onclick="${KickUserPerm}">
                      <img src=''{%GetImageUrl("CMSModules/CMS_Chat/permakick.png")|(user)administrator|(hash)33985f1f0c0e623c5f2702dfa548b423b322bb3a6e55218f09ec85b2365ed9ee%}'' title="{$chat.kickuserperm$}" alt="{$chat.kickuserperm$}" width="12px" height="12px"/>
                  </a>
          </div>
  {{/if}}
  
  {{if KickUser}}
      <div class="KickButton">
              <a href="#" onclick="${KickUser}">
                      <img src=''{%GetImageUrl("CMSModules/CMS_Chat/kick.png")|(user)administrator|(hash)245b0e104f150a624be1a9c1f4b85796c618b99dc3b18b589aeb4f577ef065d0%}'' title="{$chat.kick$}" alt="{$chat.kick$}" width="12px" height="12px"/>
                  </a>
          </div>
  {{/if}}
  
  {{if DeleteAdmin}}
      <div class="DeleteAdminButton">
              <a href="#" onclick="${DeleteAdmin}">
                      <img src=''{%GetImageUrl("CMSModules/CMS_Chat/security_agent_delete.png")|(user)administrator|(hash)a242d80cf871a4fe4e2b9e5c5bd812523051332005a43d5983dcf70946871c84%}'' title="{$chat.deleteadmin$}" alt="{$chat.deleteadmin$}" width="12px" height="12px"/>
                  </a>
          </div>
  {{/if}}
  
  {{if AddAdmin}}
      <div class="AddAdminButton">
              <a href="#" onclick="${AddAdmin}">
                      <img src=''{%GetImageUrl("CMSModules/CMS_Chat/security_agent_add.png")|(user)administrator|(hash)43bbadccfd736c3d5f1f5df3e6ec1b7b55b578471837582c31ec171bd91aded6%}'' title="{$chat.addadmin$}" alt="{$chat.addadmin$}" width="12px" height="12px"/>
                  </a>
          </div>
  {{/if}}
  
  <div class="ChatRoomUserName"> <!-- Do not change this class name -->
    {{if IsOnline}}
        {{if IsCurrentUser}}<span class="CurrentUser"><strong>${Nickname}</strong></span> 
        {{else}}
            {{if OneOnOneChat}}
                <a href="#" onclick="${OneOnOneChat}" target="_blank">${Nickname}</a>
            {{else}}
                ${Nickname}
            {{/if}}
        {{/if}}
    {{else}}
        <span>
            <a href="#" onclick="return false;" title="{$chat.notpresent$}" style="text-decoration:none; cursor:default">${Nickname}</a>
        </span>
    {{/if}} 
    {{if IsAdmin && !IsCreator}} <span class="UserAdmin"> <img src=''{%GetImageUrl("CMSModules/CMS_Chat/security_agent.png")|(user)administrator|(hash)f7f9ddc2d9d3619db3cf0989e8e0e5891c6ef67174d71edb59915f48fabac67e%}'' title="{$chat.livesite.admin$}" alt="{$chat.livesite.admin$}" width="12px" height="12px"/></span>{{/if}}
    {{if IsCreator}} <span class="UserCreator"> <img src=''{%GetImageUrl("CMSModules/CMS_Chat/security_agent_creator.png")|(user)administrator|(hash)acb99dc154852d8354b7bbee2a01b945f8ccd857c300c75f071aab449a4c56a5%}'' title="{$chat.livesite.creator$}" alt="{$chat.livesite.creator$}" width="12px" height="12px"/></span>{{/if}}
  </div>
</div>', N'jquery', 3140, N'90a66b39-3ba5-498d-8b45-90f9720f5b9c', '07675e70-c478-4651-8f77-cf98d145409c', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2653, N'ChatSupportRequest', N'{{if LiveSupport}}
    <input type="button" value="{$chat.supportrequest.openchat$}" />
{{else}}
    {{if EmailEnabled}}
      <input type="button" value="{$chat.supportrequest.emailavailable$}" />
    {{else}}
      <input type="button" value="{$chat.supportrequest.unavailable$}" />
    {{/if}}
{{/if}}', N'jquery', 3140, N'd4af044e-c7af-49c2-a6f6-eb5f004a5374', 'daa06eca-9fe1-40ef-ab51-c8b72b09a5a7', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2654, N'CMSChatError', N'<span style="color:#FF0000">Error message: {{html Message}}</span><a href="#" onclick="${Delete}" > [X]</a>', N'jquery', 3140, N'43848c55-930f-4dec-ab9c-49ad3387c88b', '3d226508-ef50-4740-b47d-08af0688585b', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2655, N'CMSChatErrorDeleteAllButton', N'<br/><a href="#" onclick="${DeleteAll}">Close all errors.</a><br/><br/>', N'jquery', 3140, N'd88ec032-bc32-4c0a-9e48-926bf3c77859', 'd550a6ea-2f94-47aa-9d8a-8e5008df78f9', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2656, N'CMSChatMessage', N'<div class="ChatMessage">
{{if System}}
	<span class="System">${LastModified.toLocaleTimeString()}:
	<span class="Message System{{if (System == 7) || (System == 10)}} Greeting{{/if}}"> ${MessageText}</span> </span>
{{else}}
	{{if RejectMessage}}
        	<div class="RejectButton">
                	<a href="#" onclick="${RejectMessage}">
                        	<img src=''{%GetImageUrl("CMSModules/CMS_Chat/reject.png")|(user)administrator|(hash)a3d1d46239c6eed35c7d78c536e06491d223e55dc3a18abaa5e086223597916e%}'' alt="{$chat.rejectmessage$}" title="{$chat.rejectmessage$}" width="8px" height="8px"/>
                	</a>
        	</div>
        {{/if}}
  	<span class="PostedTime">${PostedTime.toLocaleTimeString()}</span>
        {{if Modified}}
        	<span class="Modified">({$chat.messagemodified$} ${LastModified.toLocaleTimeString()})</span>
        {{/if}}
        
        {{if (Whisper && !IsOneOnOne)}}
        	<span class="Whisper">
                <strong>
                	{{if SelectRecipient}}
                		{$chat.from$} 
                         <a href="#" onclick="${SelectRecipient}">${Nickname}</a>   
                     {{else}}
                        {$chat.to$}
                          {{if (SelectPrevRecipient)}}
                             <a href="#" onclick="${SelectPrevRecipient}">${Recipient}</a>
                          {{else}}
                              ${Recipient}
                          {{/if}}
                     {{/if}}
                </strong>
                        	
        {{else}}
        	<strong>
                	{{if (SelectRecipient && !IsOneOnOne)}}
                        	<a href="#" onclick="${SelectRecipient}">${Nickname}</a>
                        {{else}}
                        	${Nickname}
                        {{/if}}
                </strong>
        {{/if}}:
        {{if Rejected}}
        	<span class="Rejected">{$chat.messagerejected$}</span>
        {{else}}
        	<span class="Message">${MessageText}</span>
        {{/if}}
        
        {{if (Whisper && !IsOneOnOne)}}
        	</span>
        {{/if}}
{{/if}}
</div>', N'jquery', 3140, N'750370ab-41b3-4e28-9e17-80d6795ba0c8', 'f2210e38-139b-42ab-ba5d-f69f0063a231', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2657, N'CMSChatNotification', N'{{if NotificationType == 0}}
	<td>{$chat.user$} <b><span>${SenderNickname}</span></b>
	{{if IsOneToOne}}
        	{$chat.invitedyoutoaprivateconversation$}.
        {{else}}
	 	{$chat.invitedyou$} <b><span>${RoomName}</span></b>.
        {{/if}}
        </td><td><input class="SubmitButton ChatNotificationButton" onclick="${AcceptEvent}" type="button" value="{$chat.accept$}" /><input class="SubmitButton ChatNotificationButton" onclick="${DeclineEvent}" type="button" value="{$chat.decline$}" /></td>
{{else}}
	<td>
	{{if NotificationType == 1}}
        	{$chat.user$} <b><span>${SenderNickname}</span></b> 
                {{if IsOneToOne}}
                	{$chat.declinedprivate$}.
                {{else}}
                	{$chat.declined$} <b><span>${RoomName}</span></b>.
                {{/if}}
        {{/if}}
        {{if NotificationType == 2}}
        	{$chat.user$} <b><span>${SenderNickname}</span></b> 
                {{if IsOneToOne}}
                	{$chat.acceptedprivate$}.
                {{else}}
                	{$chat.accepted$} <b><span>${RoomName}</span></b>.
                {{/if}}
        {{/if}}
        {{if NotificationType == 3}}{$chat.nicknamechanged$}.{{/if}}
        {{if NotificationType == 4}}{$chat.user$} <b><span>${SenderNickname}</span></b> {$chat.kicked$} <b><span>${RoomName}</span></b>. {{if KickTime}} {$chat.kickreturn$} <b>${KickTime}</b>.{{/if}}{{/if}}
        {{if NotificationType == 5}}{$chat.user$} <b><span>${SenderNickname}</span></b> {$chat.kickedperm$} <b><span>${RoomName}</span></b>.{{/if}}
        {{if NotificationType == 6}}{$chat.user$} <b><span>${SenderNickname}</span></b> {$chat.adminadded$} <b><span>${RoomName}</span></b>.{{/if}}
        {{if NotificationType == 7}}{$chat.user$} <b><span>${SenderNickname}</span></b> {$chat.admindeleted$} <b><span>${RoomName}</span></b>.{{/if}}
        </td>
        <td class="ChatNotificationButtons">
        	<input class="SubmitButton ChatNotificationButton" onclick="${CloseEvent}" type="button" value="{$chat.delete$}" />
        </td>
{{/if}}', N'jquery', 3140, N'a6988eaf-9ce4-4beb-ad1e-2a706bc99c0b', '5f569586-f6f1-447a-a640-8010f7c4156b', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2658, N'CMSChatRoomUser', N'<div class="ChatRoomUser {{if IsOnline}}OnlineUser{{else}}OfflineUser{{/if}}">
  {{if KickUserPerm}}
      <div class="PermaKickButton">
              <a href="#" onclick="${KickUserPerm}">
                      <img src=''{%GetImageUrl("CMSModules/CMS_Chat/permakick.png")|(user)administrator|(hash)33985f1f0c0e623c5f2702dfa548b423b322bb3a6e55218f09ec85b2365ed9ee%}'' title="{$chat.kickuserperm$}" alt="{$chat.kickuserperm$}" width="12px" height="12px"/>
                  </a>
          </div>
  {{/if}}
  
  {{if KickUser}}
      <div class="KickButton">
              <a href="#" onclick="${KickUser}">
                      <img src=''{%GetImageUrl("CMSModules/CMS_Chat/kick.png")|(user)administrator|(hash)245b0e104f150a624be1a9c1f4b85796c618b99dc3b18b589aeb4f577ef065d0%}'' title="{$chat.kick$}" alt="{$chat.kick$}" width="12px" height="12px"/>
                  </a>
          </div>
  {{/if}}
  
  {{if DeleteAdmin}}
      <div class="DeleteAdminButton">
              <a href="#" onclick="${DeleteAdmin}">
                      <img src=''{%GetImageUrl("CMSModules/CMS_Chat/security_agent_delete.png")|(user)administrator|(hash)a242d80cf871a4fe4e2b9e5c5bd812523051332005a43d5983dcf70946871c84%}'' title="{$chat.deleteadmin$}" alt="{$chat.deleteadmin$}" width="12px" height="12px"/>
                  </a>
          </div>
  {{/if}}
  
  {{if AddAdmin}}
      <div class="AddAdminButton">
              <a href="#" onclick="${AddAdmin}">
                      <img src=''{%GetImageUrl("CMSModules/CMS_Chat/security_agent_add.png")|(user)administrator|(hash)43bbadccfd736c3d5f1f5df3e6ec1b7b55b578471837582c31ec171bd91aded6%}'' title="{$chat.addadmin$}" alt="{$chat.addadmin$}" width="12px" height="12px"/>
                  </a>
          </div>
  {{/if}}
  
  <div class="ChatRoomUserName"> <!-- Do not change this class name -->
    {{if IsOnline}}
        {{if IsCurrentUser}}<span class="CurrentUser"><strong>${Nickname}</strong></span> 
        {{else}}
            {{if OneOnOneChat}}
                <a href="#" onclick="${OneOnOneChat}" target="_blank">${Nickname}</a>
            {{else}}
                ${Nickname}
            {{/if}}
        {{/if}}
    {{else}}
        <span>
            <a href="#" onclick="return false;" title="{$chat.notpresent$}" style="text-decoration:none; cursor:default">${Nickname}</a>
        </span>
    {{/if}} 
    {{if IsAdmin && !IsCreator}} <span class="UserAdmin"> <img src=''{%GetImageUrl("CMSModules/CMS_Chat/security_agent.png")|(user)administrator|(hash)f7f9ddc2d9d3619db3cf0989e8e0e5891c6ef67174d71edb59915f48fabac67e%}'' title="{$chat.livesite.admin$}" alt="{$chat.livesite.admin$}" width="12px" height="12px"/></span>{{/if}}
    {{if IsCreator}} <span class="UserCreator"> <img src=''{%GetImageUrl("CMSModules/CMS_Chat/security_agent_creator.png")|(user)administrator|(hash)acb99dc154852d8354b7bbee2a01b945f8ccd857c300c75f071aab449a4c56a5%}'' title="{$chat.livesite.creator$}" alt="{$chat.livesite.creator$}" width="12px" height="12px"/></span>{{/if}}
  </div>
</div>', N'jquery', 3140, N'7c07afc1-b0f3-40d8-9fac-86a3d12f522b', 'abfda7d0-4571-4523-bfbd-9183085b58c2', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2659, N'CMSRoomName', N'<h1>${RoomName}</h1>', N'jquery', 3140, N'daf775b9-f1f4-4c2f-abc9-9292f4dd5df2', '781c93b4-6dbf-4080-8b0e-2fe0ca848903', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2694, N'InitiatedChat', N'{{if MessagesTemplate}}
  <div class="InitiateChatMessage">${Text}</div>
{{else}}
<div class="InitiatedChatBubble">
  <div class="InitiateChatSupporterName">
    ${InitiatorName}
  </div>
  <div class="InitiateChatMessages">
    {{html Messages}}
  </div>
  <div class="InitiateChatButtons">
      <a href="#" onclick="${Accept}" class="InitiateChatAcceptButton">{$chat.initiatechat.accept$}</a>
      <a href="#" onclick="${Reject}" class="InitiateChatRejectButton">{$chat.initiatechat.reject$}</a>
  </div>
</div>
{{/if}}', N'jquery', 3140, N'fc61eafd-1c37-47f7-904c-6621a3b90888', '69b4a850-dce7-43a8-bd68-7f0fd49203e8', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2660, N'RoomName', N'<h1>${RoomName}</h1>', N'jquery', 3140, N'54cc73ed-666e-42eb-996e-778f10a90a7c', '445871e0-ed65-4db6-bddb-3c8b18d42e61', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (3398, N'RoomNameWebPartsExamples', N'<div style="border: 2px solid gray; padding: 8px; background:#DADADA;">
<span style="font-size: 14px; font-weight: bold">${RoomName}</span>
</div>', N'jquery', 3140, N'95da2328-d9d5-4d94-b437-56183801920d', 'fbdb3524-b3e1-44fb-a9e2-37e3e85cf055', '20120828 10:36:03', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (1143, N'AtomItem', N'<entry>
  <title><%# EvalCDATA("FileName") %></title>
  <link href="<%# GetAbsoluteUrl(GetDocumentUrlForFeed(), Eval("SiteName")) %>"/>
  <id>urn:uuid:<%# Eval("NodeGUID") %></id>
  <published><%# GetAtomDateTime(Eval("DocumentCreatedWhen")) %></published>
  <updated><%# GetAtomDateTime(Eval("DocumentModifiedWhen")) %></updated>
  <author>
    <name><%# Eval("NodeOwnerFullName") %></name>
  </author>
  <summary><%# EvalCDATA("FileDescription") %></summary>
</entry>', N'ascx', 1685, N'073f6246-4df4-45e3-b5f4-228dae6bf779', 'f696f2d5-70d0-4cce-93d0-3108df11abaa', '20120828 10:35:55', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (299, N'AttachmentList', N'<a target="_blank" href="<%# GetFileUrl("FileAttachment") %>">
<%# IfImage("FileAttachment", GetImage("FileAttachment", 400, 400, 400, Eval("FileDescription")), "") %>
<br /><%# Eval("FileName",true) %></a><br />', N'ascx', 1685, N'ce2369cd-4218-4d53-b690-fe3db291c993', '74f430bc-627c-4867-b21c-dbe6134e54c3', '20120828 10:35:55', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (296, N'ImageGallery_detail400', N'<%#IfEmpty(Eval("FileAttachment"), "no image", "<img alt=''" + Eval("FileName", true) + "'' src=''" + GetFileUrl("FileAttachment") + "?maxsidesize=400'' />")%>', N'ascx', 1685, N'431ae8b9-cced-4cb8-b646-d09eadadd126', '9f9fda7c-4695-48d3-8014-88a3bc670a76', '20120828 10:35:55', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (302, N'ImageGallery_detail500', N'<%#IfEmpty(Eval("FileAttachment"), "no image", "<img alt=''" + Eval("FileDescription") + "'' src=''" + GetFileUrl("FileAttachment") + "?maxsidesize=500'' />")%>', N'ascx', 1685, N'706723ef-aba8-4e51-908f-1a74c8988b43', 'b7ce1195-a490-4808-b9c9-802922f35b7b', '20120828 10:35:55', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (297, N'ImageGallery_detail600', N'<%#IfEmpty(Eval("FileAttachment"), "no image", "<img alt=''" + Eval("FileDescription") + "'' src=''" + GetFileUrl("FileAttachment") + "?maxsidesize=600'' />")%>', N'ascx', 1685, N'e81566b1-4803-4877-8b70-56ece1876b4b', 'f08449f5-74a0-4e73-a777-63e2ec95cb4e', '20120828 10:35:55', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (298, N'ImageGallery_detail800', N'<%#IfEmpty(Eval("FileAttachment"), "no image", "<img alt=''" + Eval("FileDescription") + "'' src=''" + GetFileUrl("FileAttachment") + "?maxsidesize=800'' />")%>', N'ascx', 1685, N'4bf61f71-0abf-48e9-9a33-3c6cb70f39c7', '1876199f-187e-41ea-8145-8a5fa9aaf78d', '20120828 10:35:55', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (1738, N'ImageGallery_LightBoxList', N'<%#IfEmpty(Eval("FileAttachment"), "no image", "<a href=''" + GetFileUrl("FileAttachment") + "'' class=''ImgLightBox''><img alt=''" + Eval("FileDescription") + "'' src=''" + GetFileUrl("FileAttachment") + "?maxsidesize=800'' /></a>")%>', N'ascx', 1685, N'99537d55-c80a-45a1-b057-434ca536bd2c', 'f297745a-1089-44f1-a9cb-645f899addfe', '20120828 10:35:55', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (293, N'ImageGallery_thumbnails100', N'<a href="?imagepath=<%# System.Web.HttpUtility.UrlEncode(DataBinder.Eval(Container, "DataItem.NodeAliasPath").ToString()) %>">
<%#IfEmpty(Eval("FileAttachment"), "no image", "<img alt=''" + Eval("FileName", true) + "'' src=''" + GetFileUrl("FileAttachment") + "?maxsidesize=100'' border=''0'' />")%>
</a>', N'ascx', 1685, N'ccb9941b-8cb8-4f7e-adcd-9877a11201e2', 'c8365347-59be-4353-88d0-9ae8fde751db', '20120828 10:35:55', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (303, N'ImageGallery_thumbnails180', N'<a href="?imagepath=<%# System.Web.HttpUtility.UrlEncode(DataBinder.Eval(Container, "DataItem.NodeAliasPath").ToString()) %>">
<%#IfEmpty(Eval("FileAttachment"), "no image", "<img alt=''" + Eval("FileDescription") + "'' src=''" + GetFileUrl("FileAttachment") + "?maxsidesize=180'' border=''0'' />")%>
</a>', N'ascx', 1685, N'ee275bad-0f3e-4b6d-b37f-2ed2cc030d93', '376eb9e5-13a8-4baf-a9e9-f20d11dfea2a', '20120828 10:35:55', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (294, N'ImageGallery_thumbnails200', N'<a href="?imagepath=<%# System.Web.HttpUtility.UrlEncode(DataBinder.Eval(Container, "DataItem.NodeAliasPath").ToString()) %>">
<%#IfEmpty(Eval("FileAttachment"), "no image", "<img alt=''" + Eval("FileName", true) + "'' src=''" + GetFileUrl("FileAttachment") + "?maxsidesize=200'' border=''0'' />")%>
</a>', N'ascx', 1685, N'8d551276-4ac6-409e-b968-b2d4af680dee', 'bc05b40a-fba1-4f66-9730-6bb35fc85e85', '20120828 10:35:55', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (295, N'ImageGallery_thumbnails300', N'<a href="?imagepath=<%# System.Web.HttpUtility.UrlEncode(DataBinder.Eval(Container, "DataItem.NodeAliasPath").ToString()) %>">
<%#IfEmpty(Eval("FileAttachment"), "no image", "<img alt=''" + Eval("FileName") + "'' src=''" + GetFileUrl("FileAttachment") + "?maxsidesize=300'' border=''0'' />")%>
</a>', N'ascx', 1685, N'30c2a84e-b613-4fcb-8f58-0337b4b7a671', '10a47820-4a54-4fec-8a69-0e04853155c7', '20120828 10:35:55', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (300, N'Lightbox', N'<a href="<%# GetDocumentUrl() %>" rel="lightbox[group]" rev="<%# Eval("NodeAliasPath") %>" title="<%# Eval("FileDescription", true) %>"><img src="<%# GetFileUrl("FileAttachment") %>?maxsidesize=150" alt="<%# Eval("FileName", true) %>" /></a>', N'ascx', 1685, N'18601d73-97a4-405a-ba9c-8579ec7315b6', '2673a82a-c87b-47aa-bc33-544d5c8bbc79', '20120828 10:35:55', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (301, N'LightboxSelected', N'<img src="<%# GetFileUrl("FileAttachment") %>" title="<%# Eval("FileName",true) %>" alt="" />', N'ascx', 1685, N'5a2b1f2e-d03c-4750-b9c4-2a11548619d2', '6440767f-166e-4e66-960a-41048df70eb6', '20120828 10:35:55', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (2309, N'LightBoxSimple', N'<a href="<%# GetDocumentUrl() %>" rel="lightbox" rev="<%# Eval("NodeAliasPath") %>" title="<%# Eval("FileDescription", true) %>"><img src="<%# GetFileUrl("FileAttachment") %>?maxsidesize=150" alt="<%# Eval("FileName", true) %>" /></a>', N'ascx', 1685, N'c3f3a5a0-330d-496e-a2f6-5c94026e2e0f', 'd73baf6c-e8ca-45ec-ba9a-8c9ca440e7d6', '20120828 10:35:55', 0, N'', N'')
INSERT INTO [CMS_Transformation] ([TransformationID], [TransformationName], [TransformationCode], [TransformationType], [TransformationClassID], [TransformationVersionGUID], [TransformationGUID], [TransformationLastModified], [TransformationIsHierarchical], [TransformationHierarchicalXML], [TransformationCSS]) VALUES (1082, N'RSSItem', N'<item>
  <guid isPermaLink="false"><%# Eval("NodeGUID") %></guid>
  <title><%# EvalCDATA("FileName") %></title>
  <description><%# EvalCDATA("FileDescription") %></description>
  <pubDate><%# GetRSSDateTime(Eval("DocumentCreatedWhen")) %></pubDate>
  <link><![CDATA[<%# GetAbsoluteUrl(GetDocumentUrlForFeed(), Eval("SiteName")) %>]]></link>
</item>', N'ascx', 1685, N'37de8cfd-ce95-4772-a714-4071c4067d9e', 'b365d59a-46fb-46e8-b27c-7f9a220f930b', '20120828 10:35:55', 0, N'', N'')
SET IDENTITY_INSERT [CMS_Transformation] OFF
