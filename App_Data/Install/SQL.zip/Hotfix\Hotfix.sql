/********************* RESOURCE STRINGS ***********************/
DECLARE @stringId AS int;
DECLARE @cultureId AS int;
DECLARE @cultureCode AS nvarchar(50);

-- Change value of this parameter if your default UI culture is not 'en-US' (see details in hotfix instructions)
SET @cultureCode = 'en-US';

-- Get culture ID
SET @cultureId = (SELECT UICultureID FROM [CMS_UICulture] WHERE UICultureCode=@cultureCode);
IF  @cultureId IS NULL
BEGIN
  SET @cultureId = (SELECT UICultureID FROM [CMS_UICulture] WHERE UICultureCode='en-US');
END

SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'board.messageedit.alreadyrated' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('board.messageedit.alreadyrated'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'You''ve already rated.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'doctype.ecommerce.mappingwarning' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('doctype.ecommerce.mappingwarning'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'These settings provide backward compatibility after upgrading or importing from older versions.</br> It is not necessary to use mapping in current version of CMS.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'DocumentType_List.DefaultPageClass' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('DocumentType_List.DefaultPageClass'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'The document type ({0}) cannot be deleted since it is default page menu item document type. Please change the default document type in the web.config file.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'general.actionfinished' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('general.actionfinished'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Action finished successfully')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'general.copyfiles.precompiled' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('general.copyfiles.precompiled'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Cannot copy physical files in precompiled website.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Update macro signatures')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.currentsaltisconnectionstring' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.currentsaltisconnectionstring'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'(Current salt is a connection string, not shown for security reasons)')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.currentsaltiscustomvalue' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.currentsaltiscustomvalue'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'(Current salt is a custom value, not shown for security reasons)')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.description' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.description'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Whenever a user saves a macro expression, the system automatically adds a security signature containing the user name of the macro''s author and a hash of the expression. The hash function also appends a <strong>salt</strong> to the input. By default, the system uses the application''s database connection string as the salt. 
<br /><br />
If your application''s hash salt value changes, the security signatures of existing macro expressions become invalid. This may lead to problems with unresolved macros in certain scenarios:
<ul>
<li>
The connection string of your application has changed, e.g. when moving to a different server or after setting a new database password.
</li><li>
You are using content staging to transfer data containing macros to another instance with a different connection string.
</li><li>
You have set a new custom salt via the <strong>CMSHashStringSalt</strong> web.config key.
</li></ul>
To re-sign all occurrences of macros in the system, enter the appropriate hash salt values and click <strong>Update macro signatures</strong>.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.newsalt' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.newsalt'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'New salt')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.newsaltempty' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.newsaltempty'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Please enter the new salt.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.oldsalt' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.oldsalt'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Old salt')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.oldsaltempty' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.oldsaltempty'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Please enter the old salt.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.processing' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.processing'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Processing ''{0}'' objects ...')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.refreshall' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.refreshall'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Sign all macros')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.refreshalldescription' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.refreshalldescription'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'(Re-signs all macros based on the current user)')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.refreshalltooltip' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.refreshalltooltip'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'If enabled, the macro re-signing process skips the signature integrity check, so you do not need to enter the old salt value. Check this option to re-sign all macros, including those that are unsigned or have invalid signatures.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.usecurrentsalt' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.usecurrentsalt'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Use the current salt')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'mem.facebook.enterapikey' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('mem.facebook.enterapikey'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Please enter an API key.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'mem.facebook.enterappsecret' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('mem.facebook.enterappsecret'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Please enter an application secret.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'mem.facebook.enterpageid' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('mem.facebook.enterpageid'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Please enter a Facebook Page ID.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'objecttype.om_membershipsubscriber' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('objecttype.om_membershipsubscriber'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Contact-subscriber relation')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'settingskey.screenlockinterval.description' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('settingskey.screenlockinterval.description'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Time (in minutes) that has to pass before the screen is locked. This value has to be greater than 0 and lower than session timeout.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'settingskey.cmswebanalyticsusejavascriptlogging' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('settingskey.cmswebanalyticsusejavascriptlogging'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Log via JavaScript snippet')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'settingskey.cmswebanalyticsusejavascriptlogging.description' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('settingskey.cmswebanalyticsusejavascriptlogging.description'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'If enabled, the system will log majority of Web analytic statistics and certain On-line marketing Activities using JavaScript snippet. JavaScript logging filters out all browsers and devices that do not support JavaScript or have it disabled (typically non-human tools such as RSS readers, web crawlers, etc.). Switching to JavaScript logging does not affect performance of the website. Activities logged by JavaScript snippet include Page view, Landing page and External search.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'socialnetworking.lengthafterprocessing' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('socialnetworking.lengthafterprocessing'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Length of post after processing: {0}')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.macrorule.emptystring' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.macrorule.emptystring'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'(empty string)')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.macrorule.whitespaces' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.macrorule.whitespaces'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'(whitespaces)')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'sf.noattributemappingavailable.tooltip' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('sf.noattributemappingavailable.tooltip'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'There are currently no contact fields matching the data type of the target Salesforce field. You can add custom contact fields in Site Manager -> Development -> System tables.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'sf.noattributemappingavailabledefault.tooltip' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('sf.noattributemappingavailabledefault.tooltip'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'There are currently no contact fields matching the data type of the target Salesforce field. The field''s default value will be used. You can add custom contact fields in Site Manager -> Development -> System tables.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'general.start' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('general.start'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Start')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'importsite.subscribernotfound' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('importsite.subscribernotfound'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Subscriber {0} not found')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'importsite.unsubscribing' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('importsite.unsubscribing'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Unsubscribing {0}')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'ImportSubscribers.deleting' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('ImportSubscribers.deleting'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Deleting subscriber {0}')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'ImportSubscribers.notfound' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('ImportSubscribers.notfound'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Subscriber not found {0}')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'newsletters.importingsubscribers' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('newsletters.importingsubscribers'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Importing subscribers')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'Subscriber_Import.cancelled' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('Subscriber_Import.cancelled'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Process was cancelled.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'subscriber_import.lblnote' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('subscriber_import.lblnote'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'One subscriber per line in format: e-mail;first name;last name (first name and last name may be omitted)')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'Subscriber_Import.notimported' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('Subscriber_Import.notimported'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'No subscribers were imported.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'general.errorocurred' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('general.errorocurred'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Exception occurred: {0}')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'Subscriber_Import.nosubscribers' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('Subscriber_Import.nosubscribers'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Please enter at least one subscriber.')
END


GO
/*********************  END RESOURCE STRINGS ***********************/

-- B5433 - Team development - My desk > Checked out objects - edit action for email template is missing
GO
UPDATE [CMS_Class] SET [ClassEditingPageURL] = N'~/CMSModules/EmailTemplates/Pages/Frameset.aspx?templateid={%EditedObject.ID%}&&tabmode=1&editonlycode=1' WHERE [ClassName] = N'cms.emailtemplate'
GO

-- B5477 - [Team development] - UIForm checks out all new objects, not only objects that support locking
GO
DELETE FROM [CMS_ObjectSettings] WHERE [ObjectSettingsObjectType] NOT IN ('cms.layout','cms.templatedevicelayout','cms.pagetemplate','cms.emailtemplate','cms.transformation','cms.cssstylesheet','cms.webpartcontainer','cms.webpartlayout')
GO

-- B5563 - [General] - SQL exception while deleting module
GO
ALTER PROCEDURE [Proc_CMS_Resource_RemoveDependencies]
	@ID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRANSACTION;    
    DELETE FROM [CMS_ResourceSite] WHERE ResourceID = @ID;
	
	-- Permissions
    DELETE FROM [Forums_ForumRoles]				WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
    DELETE FROM [CMS_RolePermission]			WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
    DELETE FROM [Community_GroupRolePermission]	WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
    DELETE FROM [Media_LibraryRolePermission]	WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
    DELETE FROM [CMS_WidgetRole]				WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
	DELETE FROM [CMS_Permission] WHERE ResourceID = @ID;

    -- UI elements
    DELETE FROM [CMS_RoleUIElement] WHERE ElementID IN (SELECT ElementID FROM CMS_UIElement WHERE ElementResourceID = @ID);
    DELETE FROM [CMS_UIElement] WHERE ElementResourceID = @ID;
    
    UPDATE [CMS_WebPart] SET WebPartResourceID = NULL WHERE WebPartResourceID = @ID;
    UPDATE [CMS_FormUserControl] SET UserControlResourceID = NULL WHERE UserControlResourceID = @ID;
    UPDATE [CMS_InlineControl] SET ControlResourceID = NULL WHERE ControlResourceID = @ID;
    UPDATE [CMS_ScheduledTask] SET TaskResourceID = NULL WHERE TaskResourceID = @ID;
	UPDATE [CMS_WorkflowAction] SET ActionResourceID = NULL WHERE ActionResourceID = @ID;
        
	COMMIT TRANSACTION;
END
GO

-- B6148 - [Workflow] - SQL exception while deleting culture assigned to workflow scope
GO
ALTER PROCEDURE [Proc_CMS_Culture_RemoveDependencies] 
    @ID int
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    -- Delete dependencies from CMS_UserCulture
    DELETE FROM CMS_UserCulture WHERE CultureID = @ID;
	-- CMS_WorkflowScope
    DELETE FROM CMS_WorkflowScope WHERE ScopeCultureID = @ID;
    -- CMS_SiteCulture
    DELETE FROM CMS_SiteCulture WHERE CultureID = @ID;
    -- BadWords_WordCulture
    DELETE FROM BadWords_WordCulture WHERE CultureID = @ID;   
    -- Search index
    DELETE FROM [CMS_SearchIndexCulture] WHERE IndexCultureID = @ID;
    
    -- CMS Page template scopes
    DELETE FROM [CMS_PageTemplateScope] WHERE PageTemplateScopeCultureID = @ID;
    
    COMMIT TRANSACTION;
END
GO


-- B5621 - [Web parts] - Google analytics doesn't support some multiple subdomain scenarios
GO
UPDATE [CMS_WebPart]
SET [WebPartProperties] = '<form><category name="Google Analytics Settings" visible="True" /><field column="TrackingCode" fieldcaption="Tracking code" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="20" fielddescription="This code is obtained from the Google Analytics service at www.google.com/analytics." publicfield="false" spellcheck="false" guid="47bb33c6-3432-4fee-8dd2-204d2552ad5d" visibility="none"><settings><controlname>textboxcontrol</controlname></settings></field><field column="TrackingType" fieldcaption="Tracking type" visible="true" defaultvalue="0" columntype="integer" fieldtype="CustomUserControl" allowempty="true" fielddescription="Type of the tracking depending on the domain model." publicfield="false" spellcheck="false" guid="0b69524d-3de0-440d-9c07-ec39ab5ecae5" visibility="none"><settings><controlname>radiobuttonscontrol</controlname><RepeatDirection>vertical</RepeatDirection><Options>0; Single domain (e.g. only www.example.com)
1; One domain with multiple subdomains (e.g. sub1.example.com, sub2.example.com, sub3.example.com)
2; Multiple top-level domains (e.g. www.example.com, www.example.net, www.example.org)</Options></settings></field><field column="MainWebsiteDomain" fieldcaption="Website main domain" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" fielddescription="Use this property to specify a custom domain name used for tracking purposes in non-trivial scenarios. For example, if you want to track visits to &quot;my.first.example.com&quot; and &quot;my.second.example.com&quot;, which  are both subdomains of &quot;example.com&quot;, fill in &quot;example.com&quot;. If you leave the property empty, the web part will use the current domain." publicfield="false" guid="9b514025-ca06-44d1-8f9a-c8a503ef8926" visibility="none"><settings><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><controlname>textboxcontrol</controlname></settings></field><field column="UseAsyncScript" fieldcaption="Use asynchronous script" visible="true" defaultvalue="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" fielddescription="Indicates if asynchronous variant of Google analytics script should be used." publicfield="false" spellcheck="false" guid="3f158398-bbf7-4061-8131-5777c6b2b04f" visibility="none"><settings><controlname>checkboxcontrol</controlname></settings></field></form>'
WHERE [WebPartName]= N'GoogleAnalytics'
GO


-- B5562 - Custom table item selector form control in not working
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 2
BEGIN
	UPDATE [CMS_FormUserControl] SET UserControlParameters = '<form><field column="CustomTable" fieldcaption="Custom table" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="200" fielddescription="Selects from which custom table the items will be offered." publicfield="false" guid="ecbd7716-cf7f-4b30-a62d-112b2c301a95" visibility="none"><settings><controlname>customtableselector</controlname></settings></field><field column="DisplayNameFormat" fieldcaption="Format of the display name" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="400" fielddescription="Determines the format of the item names displayed in the selector. You can use macros in format {%ColumnName%} to dynamically retrieve values of specific items." publicfield="false" guid="610bf2db-dffb-446f-b9e8-a2b45cdb1eee" visibility="none"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="ReturnColumnName" fieldcaption="Name of the value column" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="200" fielddescription="Specifies the column from which the value stored by the selector will be loaded. This must be a unique identifier for the given custom table." publicfield="false" guid="add37892-aca1-403c-8714-444fb950765a" visibility="none"><settings><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><controlname>textboxcontrol</controlname></settings></field></form>'
		WHERE UserControlCodeName = 'CustomTableItemSelector'
END
GO

-- B5657 - Facebook - Update setting (from global setting to site setting)
GO
IF (SELECT TOP 1 KeyIsGlobal FROM CMS_SettingsKey WHERE KeyName LIKE 'CMSFacebookConnectApiKey') = 1
BEGIN
	DECLARE @categoryID int;
	DECLARE @currentSiteID int;
	DECLARE @counter int;
	DECLARE @rowCount int;
	DECLARE @siteTable TABLE (SiteID INT NOT NULL);


	INSERT INTO @siteTable SELECT SiteID FROM CMS_Site ORDER BY SiteID ASC;
	SET @rowCount = (SELECT COUNT(SiteID) FROM @siteTable);
	SET @counter = 0;
	SET @currentSiteID = (SELECT TOP 1 SiteID FROM @siteTable ORDER BY SiteID ASC);
	SET @categoryID = (SELECT TOP 1 KeyCategoryID FROM CMS_SettingsKey WHERE KeyName LIKE 'CMSFacebookConnectApiKey');

	UPDATE CMS_SettingsKey SET
		KeyIsGlobal = 0
	WHERE KeyName LIKE 'CMSFacebookConnectApiKey';

	WHILE @counter < @rowCount
	BEGIN
		INSERT INTO CMS_SettingsKey
		(KeyName, KeyDisplayName, KeyDescription, KeyType, KeyCategoryID, KeyGUID, KeyLastModified, KeyOrder, SiteID)
		VALUES ('CMSFacebookConnectApiKey', '{$settingskey.cmsfacebookconnectapikey$}', '{$settingskey.cmsfacebookconnectapikey.description$}',
		'string', @categoryID, NEWID(), GETDATE(), 1, @currentSiteID );
		DELETE FROM @siteTable WHERE SiteID = @currentSiteID;
		SET @currentSiteID = (SELECT TOP 1 SiteID FROM @siteTable ORDER BY SiteID ASC);
		SET @counter = @counter + 1    
	END;
END;
GO

--B5726 - Route documen aliases are not redirected to the main alias
DROP VIEW [View_CMS_DocumentAlias_Joined]
GO

CREATE VIEW [View_CMS_DocumentAlias_Joined]
AS
SELECT     CMS_Tree.NodeAliasPath, CMS_DocumentAlias.AliasNodeID, CMS_DocumentAlias.AliasCulture, CMS_DocumentAlias.AliasURLPath, 
                      CMS_DocumentAlias.AliasSiteID, CMS_DocumentAlias.AliasActionMode
FROM         CMS_DocumentAlias INNER JOIN
                      CMS_Tree ON CMS_DocumentAlias.AliasNodeID = CMS_Tree.NodeID
GO

--B5756 - Update stored procedure Proc_CMS_Class_Insert
GO
ALTER PROCEDURE [Proc_CMS_Class_Insert]
	@ClassID int = NULL,
    @ClassDisplayName nvarchar(100),
    @ClassName nvarchar(100),
    @ClassUsesVersioning bit,
    @ClassIsDocumentType bit,
    @ClassIsCoupledClass bit,
    @ClassXmlSchema ntext,
    @ClassFormDefinition ntext,
    @ClassNewPageUrl nvarchar(450),
    @ClassEditingPageUrl nvarchar(450),
    @ClassListPageUrl nvarchar(450),
    @ClassNodeNameSource nvarchar(100),
    @ClassTableName nvarchar(100),
    @ClassViewPageUrl nvarchar(450),
    @ClassPreviewPageUrl nvarchar(450),
    @ClassFormLayout ntext,
    @ClassShowAsSystemTable bit,
    @ClassUsePublishFromTo bit,
    @ClassShowTemplateSelection bit,
    @ClassSKUMappings ntext,
    @ClassIsMenuItemType bit,
    @ClassNodeAliasSource nvarchar(100),
    @ClassDefaultPageTemplateID int,    
    @ClassSKUDefaultDepartmentID int,
    @ClassSKUDefaultDepartmentName nvarchar(200),
    @ClassLastModified datetime,
    @ClassGUID uniqueidentifier,
    @ClassCreateSKU int,
    @ClassIsProduct bit,    
    @ClassIsCustomTable bit,
    @ClassShowColumns nvarchar(1000),
    @ClassLoadGeneration int,
	@ClassSearchTitleColumn nvarchar(200),
	@ClassSearchContentColumn nvarchar(200),
	@ClassSearchImageColumn nvarchar(200),
    @ClassSearchCreationDateColumn nvarchar(200),
    @ClassSearchSettings ntext,
    @ClassInheritsFromClassID int,
    @ClassSearchEnabled bit,
    @ClassContactMapping ntext,
    @ClassContactOverwriteEnabled bit,
    @ClassSKUDefaultProductType nvarchar(50),
    @ClassConnectionString nvarchar(100),
    @ClassIsProductSection bit,
    @ClassPageTemplateCategoryID int
AS
BEGIN
INSERT INTO [CMS_Class] (
    [ClassDisplayName],
    [ClassName],
    [ClassUsesVersioning],
    [ClassIsDocumentType],
    [ClassIsCoupledClass],
    [ClassXmlSchema],
    [ClassFormDefinition],
    [ClassNewPageUrl],
    [ClassEditingPageUrl],
    [ClassListPageUrl],
    [ClassNodeNameSource],    
    [ClassTableName],
    [ClassViewPageUrl],
    [ClassPreviewPageUrl],
    [ClassFormLayout],
    [ClassShowAsSystemTable],
    [ClassUsePublishFromTo],
    [ClassShowTemplateSelection],
    [ClassSKUMappings],
    [ClassIsMenuItemType],
    [ClassNodeAliasSource],
    [ClassDefaultPageTemplateID],    
    [ClassSKUDefaultDepartmentID],
    [ClassSKUDefaultDepartmentName],
    [ClassLastModified],
    [ClassGUID],
    [ClassCreateSKU],
    [ClassIsProduct],    
    [ClassIsCustomTable],
    [ClassShowColumns],
    [ClassLoadGeneration],
	[ClassSearchTitleColumn],
	[ClassSearchContentColumn],
	[ClassSearchImageColumn],
    [ClassSearchCreationDateColumn],
    [ClassSearchSettings],
    [ClassInheritsFromClassID],
    [ClassSearchEnabled],
    [ClassContactMapping],
    [ClassContactOverwriteEnabled],
    [ClassSKUDefaultProductType],
    [ClassConnectionString],
    [ClassIsProductSection],
    [ClassPageTemplateCategoryID]
)
VALUES (
    @ClassDisplayName, 
    @ClassName, 
    @ClassUsesVersioning, 
    @ClassIsDocumentType, 
    @ClassIsCoupledClass, 
    @ClassXmlSchema, 
    @ClassFormDefinition, 
    @ClassNewPageUrl, 
    @ClassEditingPageUrl, 
    @ClassListPageUrl, 
    @ClassNodeNameSource, 
    @ClassTableName,
    @ClassViewPageUrl,
    @ClassPreviewPageUrl,
    @ClassFormLayout,
    @ClassShowAsSystemTable,
    @ClassUsePublishFromTo,
    @ClassShowTemplateSelection,
    @ClassSKUMappings,
    @ClassIsMenuItemType,
    @ClassNodeAliasSource,
    @ClassDefaultPageTemplateID,    
    @ClassSKUDefaultDepartmentID,
    @ClassSKUDefaultDepartmentName,
    @ClassLastModified,
    @ClassGUID,
    @ClassCreateSKU,
    @ClassIsProduct,    
    @ClassIsCustomTable,
    @ClassShowColumns,
    @ClassLoadGeneration,
	@ClassSearchTitleColumn,
	@ClassSearchContentColumn,
	@ClassSearchImageColumn,
    @ClassSearchCreationDateColumn,
    @ClassSearchSettings,
    @ClassInheritsFromClassID,
    @ClassSearchEnabled,
    @ClassContactMapping,
    @ClassContactOverwriteEnabled,
    @ClassSKUDefaultProductType,
    @ClassConnectionString,
    @ClassIsProductSection,
    @ClassPageTemplateCategoryID
)
SELECT SCOPE_IDENTITY()
END
GO

--B5756 - Update stored procedure Proc_CMS_Class_Update
GO
ALTER PROCEDURE [Proc_CMS_Class_Update]
	@ClassID int,
    @ClassDisplayName nvarchar(100),
    @ClassName nvarchar(100),
    @ClassUsesVersioning bit,
    @ClassIsDocumentType bit,
    @ClassIsCoupledClass bit,
    @ClassXmlSchema ntext,
    @ClassFormDefinition ntext,
    @ClassNewPageUrl nvarchar(450),
    @ClassEditingPageUrl nvarchar(450),
    @ClassListPageUrl nvarchar(450),
    @ClassNodeNameSource nvarchar(100),
    @ClassTableName nvarchar(100),
    @ClassViewPageUrl nvarchar(450),
    @ClassPreviewPageUrl nvarchar(450),
    @ClassFormLayout ntext,
    @ClassShowAsSystemTable bit,
    @ClassUsePublishFromTo bit,
    @ClassShowTemplateSelection bit,
    @ClassSKUMappings ntext,
    @ClassIsMenuItemType bit,
    @ClassNodeAliasSource nvarchar(100),
    @ClassDefaultPageTemplateID int,
    @ClassSKUDefaultDepartmentID int,
    @ClassSKUDefaultDepartmentName nvarchar(200),
    @ClassLastModified datetime,
    @ClassGUID uniqueidentifier,
    @ClassCreateSKU int,
    @ClassIsProduct bit,
    @ClassIsCustomTable bit,
    @ClassShowColumns nvarchar(1000),
    @ClassLoadGeneration int,
	@ClassSearchTitleColumn nvarchar(200),
	@ClassSearchContentColumn nvarchar(200),
	@ClassSearchImageColumn nvarchar(200),
    @ClassSearchCreationDateColumn nvarchar(200),
    @ClassSearchSettings ntext,
    @ClassInheritsFromClassID int,
    @ClassSearchEnabled bit,
    @ClassContactMapping ntext,
    @ClassContactOverwriteEnabled bit,
    @ClassSKUDefaultProductType nvarchar(50),
    @ClassConnectionString nvarchar(100),
    @ClassIsProductSection bit,
    @ClassPageTemplateCategoryID int
AS
BEGIN
UPDATE [CMS_Class] 
SET 
    ClassDisplayName = @ClassDisplayName,
    ClassName = @ClassName,
    ClassUsesVersioning = ClassUsesVersioning,
    ClassIsDocumentType = @ClassIsDocumentType,
    ClassIsCoupledClass = @ClassIsCoupledClass,
    ClassXmlSchema = @ClassXmlSchema,
    ClassFormDefinition = @ClassFormDefinition,
    ClassNewPageUrl = @ClassNewPageUrl,
    ClassEditingPageUrl = @ClassEditingPageUrl,
    ClassListPageUrl = @ClassListPageUrl,
    ClassNodeNameSource = @ClassNodeNameSource,
    ClassTableName = @ClassTableName,
    ClassViewPageUrl = @ClassViewPageUrl,
    ClassPreviewPageUrl = @ClassPreviewPageUrl,
    ClassFormLayout = @ClassFormLayout,
    ClassShowAsSystemTable = @ClassShowAsSystemTable,
    ClassUsePublishFromTo = @ClassUsePublishFromTo,
    ClassShowTemplateSelection = @ClassShowTemplateSelection,
    ClassSKUMappings = @ClassSKUMappings,
    ClassIsMenuItemType = @ClassIsMenuItemType,
    ClassNodeAliasSource = @ClassNodeAliasSource,
    ClassDefaultPageTemplateID = @ClassDefaultPageTemplateID, 
    ClassSKUDefaultDepartmentID = @ClassSKUDefaultDepartmentID,
    ClassSKUDefaultDepartmentName = @ClassSKUDefaultDepartmentName,
    ClassLastModified = @ClassLastModified,
    ClassGUID = @ClassGUID,
    ClassCreateSKU = @ClassCreateSKU,
    ClassIsProduct = @ClassIsProduct,
    ClassIsCustomTable = @ClassIsCustomTable,
    ClassShowColumns = @ClassShowColumns,
    ClassLoadGeneration = @ClassLoadGeneration,
    ClassSearchTitleColumn = @ClassSearchTitleColumn,
    ClassSearchContentColumn = @ClassSearchContentColumn,
    ClassSearchImageColumn = @ClassSearchImageColumn,
    ClassSearchCreationDateColumn = @ClassSearchCreationDateColumn,
    ClassSearchSettings = @ClassSearchSettings,
    ClassInheritsFromClassID = @ClassInheritsFromClassID,
    ClassSearchEnabled = @ClassSearchEnabled,
    ClassContactMapping = @ClassContactMapping,
    ClassContactOverwriteEnabled = @ClassContactOverwriteEnabled,
    ClassSKUDefaultProductType = @ClassSKUDefaultProductType,
    ClassConnectionString = @ClassConnectionString,
    ClassIsProductSection = @ClassIsProductSection,
    ClassPageTemplateCategoryID = @ClassPageTemplateCategoryID
WHERE
    ClassID = @ClassID
END
GO

-- B5756 - Update stored procedures for ordering attachment history
ALTER PROCEDURE [Proc_CMS_AttachmentHistory_InitAttachmentOrders]
@AttachmentGUID uniqueidentifier,
@VersionHistoryID int
AS
BEGIN
	/* Get Attachment ID */
	DECLARE @AttachmentHistoryID int;
	SET @AttachmentHistoryID = (SELECT TOP 1 AttachmentHistoryID FROM CMS_AttachmentHistory WHERE (AttachmentGUID = @AttachmentGUID) AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)));

	/* Get attachment's document ID */
	DECLARE @AttachmentDocumentID int;
	SET @AttachmentDocumentID = (SELECT TOP 1 AttachmentDocumentID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);

	/* Get ID of group */
	DECLARE @AttachmentGroupGUID uniqueidentifier;
	SET @AttachmentGroupGUID = (SELECT TOP 1 AttachmentGroupGUID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	/* Declare the selection table */
	DECLARE @attachmentTable TABLE (
		AttachmentHistoryID int NOT NULL,
		AttachmentName nvarchar(255) NOT NULL,
		AttachmentOrder int NULL
		
	);
	
	/* Get the grouped or unsorted attachments */
	IF @AttachmentGroupGUID IS NOT NULL
		INSERT INTO @attachmentTable SELECT AttachmentHistoryID, AttachmentName,  AttachmentOrder FROM CMS_AttachmentHistory WHERE  AttachmentGroupGUID = @AttachmentGroupGUID AND AttachmentDocumentID=@AttachmentDocumentID AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
	ELSE 
		INSERT INTO @attachmentTable SELECT AttachmentHistoryID, AttachmentName,  AttachmentOrder FROM CMS_AttachmentHistory WHERE  AttachmentGroupGUID IS NULL AND AttachmentDocumentID=@AttachmentDocumentID AND AttachmentIsUnsorted=1 AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
	
	
	
	
	/* Declare the cursor to loop through the table */
	DECLARE @attachmentCursor CURSOR;
    SET @attachmentCursor = CURSOR FOR SELECT AttachmentHistoryID, AttachmentName, AttachmentOrder FROM @attachmentTable ORDER BY AttachmentOrder, AttachmentName, AttachmentHistoryID;
    
	/* Assign the numbers to the attachments */
	DECLARE @currentIndex int, @currentAttachmentOrder int, @currentAttachmentHistoryID int;
	SET @currentIndex = 1;
	
	DECLARE @currentAttachmentName nvarchar(255);
	
	/* Loop through the table */
	OPEN @attachmentCursor
	FETCH NEXT FROM @attachmentCursor INTO @currentAttachmentHistoryID,@currentAttachmentName, @currentAttachmentOrder;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		/* Set the attachments' index if different */
		IF @currentAttachmentOrder IS NULL OR @currentAttachmentOrder <> @currentIndex
			UPDATE CMS_AttachmentHistory SET AttachmentOrder = @currentIndex WHERE AttachmentHistoryID = @currentAttachmentHistoryID;
		/* Get next record */
		SET @currentIndex = @currentIndex + 1;
		FETCH NEXT FROM @attachmentCursor INTO @currentAttachmentHistoryID,@currentAttachmentName, @currentAttachmentOrder;
	END
	CLOSE @attachmentCursor;
	DEALLOCATE @attachmentCursor;
END
GO
ALTER PROCEDURE [Proc_CMS_AttachmentHistory_MoveAttachmentDown]
	@AttachmentGUID uniqueidentifier,
	@VersionHistoryID int
AS
BEGIN
	/* Get Attachment ID */
	DECLARE @AttachmentHistoryID int;
	SET @AttachmentHistoryID = (SELECT TOP 1 AttachmentHistoryID FROM CMS_AttachmentHistory WHERE (AttachmentGUID = @AttachmentGUID) AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)));

	/* Get attachment's document ID */
	DECLARE @AttachmentDocumentID int;
	SET @AttachmentDocumentID = (SELECT TOP 1 AttachmentDocumentID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	/* Get ID of group */
	DECLARE @AttachmentGroupGUID uniqueidentifier;
	SET @AttachmentGroupGUID = (SELECT TOP 1 AttachmentGroupGUID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	DECLARE @MaxAttachmentOrder int
	IF @AttachmentGroupGUID IS NOT NULL
		SET @MaxAttachmentOrder = (SELECT TOP 1 AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID = @AttachmentGroupGUID AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)) ORDER BY AttachmentOrder DESC);
	ELSE
		SET @MaxAttachmentOrder = (SELECT TOP 1 AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID IS NULL AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)) ORDER BY AttachmentOrder DESC);		
	
	/* Move the next attachment(s) up */	
	IF @AttachmentGroupGUID IS NOT NULL
		UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder - 1 WHERE AttachmentOrder = ((SELECT AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID) + 1 ) AND AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID = @AttachmentGroupGUID AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
	ELSE
		UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder - 1 WHERE AttachmentOrder = ((SELECT AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID) + 1 ) AND AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID IS NULL AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
		
	/* Move the current attachment down */
	UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder + 1 WHERE AttachmentHistoryID = @AttachmentHistoryID AND AttachmentOrder < @MaxAttachmentOrder
END
GO
ALTER PROCEDURE [Proc_CMS_AttachmentHistory_MoveAttachmentUp]
	@AttachmentGUID uniqueidentifier,
	@VersionHistoryID int
AS
BEGIN
	/* Get Attachment ID */
	DECLARE @AttachmentHistoryID int;
	SET @AttachmentHistoryID = (SELECT TOP 1 AttachmentHistoryID FROM CMS_AttachmentHistory WHERE (AttachmentGUID = @AttachmentGUID) AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)));

	/* Get attachment's document ID */
	DECLARE @AttachmentDocumentID int;
	SET @AttachmentDocumentID = (SELECT TOP 1 AttachmentDocumentID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	/* Get ID of group */
	DECLARE @AttachmentGroupGUID uniqueidentifier;
	SET @AttachmentGroupGUID = (SELECT TOP 1 AttachmentGroupGUID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	/* Move the previous attachment down */
	IF @AttachmentGroupGUID IS NOT NULL
		UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder + 1 WHERE AttachmentOrder = ((SELECT AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID) - 1 ) AND AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID = @AttachmentGroupGUID AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
	ELSE 
		UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder + 1 WHERE AttachmentOrder = ((SELECT AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID) - 1 ) AND AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID IS NULL AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
		
	/* Move the current attachment up */
	UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder - 1 WHERE AttachmentHistoryID = @AttachmentHistoryID AND AttachmentOrder > 1
END
GO

-- B5822 Page template category didn't remove referencing value in cms_class column
DECLARE @QueryClassID int;
SELECT @QueryClassID=ClassID FROM CMS_Class WHERE ClassName = N'cms.pagetemplatecategory '
IF (@QueryClassID > 0) AND NOT EXISTS(SELECT QueryID FROM CMS_Query WHERE ClassID=@QueryClassID AND QueryName= N'removedependencies' )
BEGIN
INSERT INTO CMS_Query ([QueryName], [QueryTypeID], [QueryText], [QueryRequiresTransaction], [ClassID], [QueryIsLocked],
  [QueryLastModified], [QueryGUID], [QueryLoadGeneration], [QueryIsCustom] ) 
  VALUES ( 'removedependencies', 1, 'Proc_CMS_PageTemplateCategory_RemoveDependencies', 0, @QueryClassID, 0, GETDATE(), NEWID(), 0, 0)
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE [ROUTINE_NAME]= N'Proc_CMS_PageTemplateCategory_RemoveDependencies' AND [ROUTINE_TYPE]= N'PROCEDURE')
DROP PROCEDURE [Proc_CMS_PageTemplateCategory_RemoveDependencies]
GO

CREATE PROCEDURE [Proc_CMS_PageTemplateCategory_RemoveDependencies]
	@ID int
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRANSACTION;
	-- CMS_Class
	UPDATE CMS_Class SET ClassPageTemplateCategoryID = NULL WHERE ClassPageTemplateCategoryID = @ID
	COMMIT TRANSACTION;
END
GO

-- B5820 Conversion values listed in AB tests with same name and same node were joined through multiple sites. (the same for MVT)
UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT ABTestID,ABTestName, ABTestDisplayName, ABTestSiteID,  ABTestCulture, ABTestOriginalPage, ABTestOpenFrom, ABTestOpenTo, ABTestEnabled, ABTestMaxConversions, ABTestConversions, ABTestTargetConversionType, SUM (HitsValue) AS HitsValue FROM OM_ABTest 
LEFT JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''abconversion;''+ ABTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_ABTest.ABTestSiteID
LEFT JOIN Analytics_YearHits ON Analytics_Statistics.StatisticsID = Analytics_YearHits.HitsStatisticsID
GROUP BY ABTestName, ABTestDisplayName, ABTestID, ABTestCulture, ABTestOriginalPage, ABTestOpenFrom, ABTestOpenTo, ABTestEnabled, ABTestConversions, ABTestSiteID, ABTestMaxConversions, ABTestTargetConversionType) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'selectwithhits' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.ABTest')
GO

UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, SUM (HitsValue) AS HitsValue,
   HitsStartTime,HitsEndTime, MVTestPage, MVTestMaxConversions, MVTestTargetConversionType  FROM OM_MVTest
LEFT JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
LEFT JOIN Analytics_YearHits ON Analytics_Statistics.StatisticsID = Analytics_YearHits.HitsStatisticsID
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID
,HitsStartTime,HitsEndTime, MVTestMaxConversions, MVTestTargetConversionType
) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'selectwithhits' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO

UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_DayHits ON Analytics_Statistics.StatisticsID = Analytics_DayHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsDays' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO

UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_HourHits ON Analytics_Statistics.StatisticsID = Analytics_HourHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsHours' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO


UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_MonthHits ON Analytics_Statistics.StatisticsID = Analytics_MonthHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsMonths' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO

UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_WeekHits ON Analytics_Statistics.StatisticsID = Analytics_WeekHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsWeeks' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO


UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_YearHits ON Analytics_Statistics.StatisticsID = Analytics_YearHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsYears' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO

-- B5878 - incorrect password form control for SQLDastaSource
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 9
BEGIN
	IF (SELECT UserControlID FROM CMS_FormUserControl WHERE UserControlCodeName = N'encryptedpassword') IS NOT NULL BEGIN
		UPDATE CMS_WebPart SET WebPartProperties = REPLACE(WebPartProperties, N'<settings><controlname>password</controlname></settings>', N'<settings><controlname>encryptedpassword</controlname></settings>') WHERE WebPartName = N'SQLDataSource'
	END
END 
GO

-- B5906 - slow loading of Newsletter issue list
IF NOT EXISTS (SELECT name FROM sys.indexes WHERE name = 'IX_OM_Activity_ActivityItemDetailID')
BEGIN
CREATE NONCLUSTERED INDEX IX_OM_Activity_ActivityItemDetailID ON OM_Activity
(
ActivityItemDetailID ASC
)
END
GO

-- B5730 - Chat.CreateNewRoom UI element has it's from version field set to 6.0 not 7.0
GO
UPDATE [CMS_UIElement]
SET [ElementFromVersion] = '7.0'
WHERE [ElementName] = 'Chat.CreateNewRoom' AND [ElementFromVersion] = '6.0'
GO

-- B6076 - Room protected by a password and created in CMS Desk is not accessible to users that know the password.
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 17
BEGIN
	UPDATE [CMS_Class]
	SET [ClassFormDefinition] = REPLACE([ClassFormDefinition],'<settings><controlname>passwordconfirmator</controlname><showstrength>False</showstrength></settings>','<settings><controlname>passwordstrength</controlname></settings>')
	WHERE [ClassName] = 'Chat.Room'
END
GO

-- B5948 - Global scheduled tasks did not run without a site
ALTER PROCEDURE [Proc_CMS_ScheduledTask_FetchTasksToRun]
@TaskSiteID int,
@DateTime datetime,
@TaskServerName nvarchar(100),
@UseExternalService bit = null
AS
BEGIN
DECLARE @TaskIDs TABLE (TaskID int);
BEGIN TRAN
    IF (@TaskSiteID IS NOT NULL)
    BEGIN
      /* Get tasks for specified site and global tasks that should be processed by application */
      IF (@UseExternalService = 0)
        BEGIN
          INSERT INTO @TaskIDs SELECT TaskID FROM CMS_ScheduledTask WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1
              AND (TaskSiteID = @TaskSiteID OR TaskSiteID IS NULL) AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName) AND (TaskUseExternalService = 0 OR TaskUseExternalService IS NULL);
        END
      ELSE IF (@UseExternalService = 1)
        /* Get tasks for specified site and global tasks that should be processed by external service */
        BEGIN
          INSERT INTO @TaskIDs SELECT TaskID FROM CMS_ScheduledTask WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1
              AND (TaskSiteID = @TaskSiteID OR TaskSiteID IS NULL) AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName) AND (TaskUseExternalService = 1);
        END
      ELSE IF (@UseExternalService IS NULL)
        /* Get tasks for specified site and global tasks */
        BEGIN
          INSERT INTO @TaskIDs SELECT TaskID FROM CMS_ScheduledTask WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1
              AND (TaskSiteID = @TaskSiteID OR TaskSiteID IS NULL) AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName);
        END
    END
    ELSE
    BEGIN
      IF (@UseExternalService = 1)
      /* Get sites and global tasks for external service (only for running sites) */
        BEGIN
            INSERT INTO @TaskIDs SELECT TaskID FROM CMS_ScheduledTask
              WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1 AND (TaskSiteID IN (SELECT SiteID FROM CMS_Site WHERE SiteStatus = N'RUNNING') OR TaskSiteID IS NULL)
              AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName) AND (TaskUseExternalService = 1);
        END
      ELSE IF (@UseExternalService IS NULL)
      /* Get only global tasks if there is no site */
        BEGIN
            INSERT INTO @TaskIDs SELECT TaskID FROM CMS_ScheduledTask
              WHERE TaskNextRunTime IS NOT NULL AND TaskNextRunTime <= @DateTime AND TaskEnabled = 1 AND (TaskSiteID IS NULL)
              AND (TaskServerName IS NULL OR TaskServerName = '' OR TaskServerName = @TaskServerName);
        END
    END

UPDATE CMS_ScheduledTask SET TaskNextRunTime = NULL WHERE TaskID IN (SELECT TaskID FROM @TaskIDs);
COMMIT TRAN
SELECT * FROM @TaskIDs;
END
GO

-- B6021 - Missing index over UserAuthenticationGUID 
IF NOT EXISTS (SELECT name FROM sys.indexes WHERE name = 'IX_CMS_UserSettings_UserAuthenticationGUID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_CMS_UserSettings_UserAuthenticationGUID] ON [CMS_UserSettings] 
(
	[UserAuthenticationGUID]
)
END
GO

-- F21032 - Settings for JS WA logging
DECLARE @ActivityCategoryID int;
SELECT @ActivityCategoryID=[CategoryID] FROM [CMS_SettingsCategory] WHERE [CategoryName]='CMS.WebAnalytics.General'

IF @ActivityCategoryID IS NOT NULL
BEGIN
  DECLARE @GlobalActivityKey int;
  SELECT @GlobalActivityKey=[KeyID] FROM [CMS_SettingsKey] WHERE [KeyName] = 'CMSWebAnalyticsUseJavascriptLogging'  

  IF @GlobalActivityKey IS NULL
  BEGIN
    -- Insert global key
    INSERT INTO CMS_SettingsKey ([KeyName], [KeyDisplayName], [KeyDescription], [KeyValue], [KeyType], [KeyCategoryID], [SiteID], [KeyGUID], [KeyLastModified], [KeyDefaultValue], [KeyOrder])
    SELECT 'CMSWebAnalyticsUseJavascriptLogging', '{$settingskey.cmswebanalyticsusejavascriptlogging$}', '{$settingskey.cmswebanalyticsusejavascriptlogging.description$}', 'false', 'boolean', @ActivityCategoryID, NULL, NEWID(), GETDATE(), 'true', 100
    INSERT INTO CMS_SettingsKey ([KeyName], [KeyDisplayName], [KeyDescription], [KeyValue], [KeyType], [KeyCategoryID], [SiteID], [KeyGUID], [KeyLastModified], [KeyDefaultValue], [KeyOrder])
    -- Insert site key for all sites
    SELECT 'CMSWebAnalyticsUseJavascriptLogging', '{$settingskey.cmswebanalyticsusejavascriptlogging$}', '{$settingskey.cmswebanalyticsusejavascriptlogging.description$}', NULL, 'boolean', @ActivityCategoryID, SiteID, NEWID(), GETDATE(), NULL, 100
    FROM CMS_Site
  END
END
GO

-- B6078 - [Chat] - Chat old records cleaner did not delete references correctly
GO
ALTER PROCEDURE [Proc_Chat_CleanOldChatRecords]
	@DaysOld INT
AS
BEGIN
	DECLARE @Now DATETIME
	SET @Now = GETDATE()

	DECLARE @MessagesDeleted INT
	DECLARE @RoomsDeleted INT
	DECLARE @UsersDeleted INT

	-- First step: delete old messages
	DELETE CM 
	FROM Chat_Message AS CM 
	WHERE DATEDIFF(DD, CM.ChatMessageLastModified, @Now) > @DaysOld

	SET @MessagesDeleted = @@ROWCOUNT

	-- Second step: delete old rooms which are not used anymore
	DECLARE @RoomsToDelete TABLE (RoomID INT);

	-- Find unused rooms and store their IDs to table variable
	INSERT @RoomsToDelete
	SELECT CR.ChatRoomID
	FROM Chat_Room CR
	WHERE CR.ChatRoomPrivate = 1 -- private rooms only
	AND NOT EXISTS (SELECT ChatMessageID FROM Chat_Message CM WHERE CM.ChatMessageRoomID = CR.ChatRoomID) -- without messages
	AND DATEDIFF(dd, CR.ChatRoomCreatedWhen, @Now) > @DaysOld -- was created more than @DaysOld days ago
	AND NOT EXISTS (
		SELECT ChatUserID 
		FROM Chat_RoomUser CRU
		LEFT JOIN Chat_User CU ON CU.ChatUserID = CRU.ChatRoomUserChatUserID
		WHERE
		CRU.ChatRoomUserRoomID = CR.ChatRoomID
		AND
		(
			(CU.ChatUserUserID IS NOT NULL AND CRU.ChatRoomUserAdminLevel > 0) -- without non anonymous users with more than 'None' permissions
			OR (CU.ChatUserUserID IS NULL AND (CRU.ChatRoomUserJoinTime IS NOT NULL OR DATEDIFF(dd, CRU.ChatRoomUserLeaveTime, @Now) < @DaysOld)) -- without anonymous users who are online or were online less than @DaysOld days ago
		))

	-- Delete room's dependencies
	DELETE [Chat_SupportTakenRoom] WHERE [ChatSupportTakenRoomRoomID] IN (SELECT RoomID FROM @RoomsToDelete);
	DELETE [Chat_InitiatedChatRequest] WHERE [InitiatedChatRequestRoomID] IN (SELECT RoomID FROM @RoomsToDelete);
	DELETE [Chat_RoomUser] WHERE [ChatRoomUserRoomID] IN (SELECT RoomID FROM @RoomsToDelete);
	DELETE [Chat_Notification] WHERE [ChatNotificationRoomID] IN (SELECT RoomID FROM @RoomsToDelete);
	DELETE [Chat_Message] WHERE [ChatMessageRoomID] IN (SELECT RoomID FROM @RoomsToDelete);

	-- Delete rooms
	DELETE [Chat_Room] WHERE [ChatRoomID] IN (SELECT RoomID FROM @RoomsToDelete);

	SET @RoomsDeleted = @@ROWCOUNT

	-- Third step: delete inactive anonymous users
	DECLARE @ChatUsersToDelete TABLE (ChatUserID INT);

	-- Find inactive users and store their IDs to table variable
	INSERT @ChatUsersToDelete
	SELECT CU.ChatUserID
	FROM Chat_User AS CU
	WHERE CU.ChatUserUserID IS NULL -- anonymous users only
	AND NOT EXISTS (SELECT ChatMessageID FROM Chat_Message CM WHERE CM.ChatMessageUserID = CU.ChatUserID OR CM.ChatMessageRecipientID = CU.ChatUserID) -- without messages
	AND NOT EXISTS (SELECT ChatOnlineUserID FROM Chat_OnlineUser COU WHERE COU.ChatOnlineUserChatUserID = CU.ChatUserID AND (COU.ChatOnlineUserJoinTime IS NOT NULL OR DATEDIFF(dd, COU.ChatOnlineUserLeaveTime, @Now) < @DaysOld)) -- user is not online and was online more than @DaysOld days ago
	
	-- Delete user's dependencies
	DELETE FROM [Chat_OnlineUser] WHERE [ChatOnlineUserChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	DELETE FROM [Chat_InitiatedChatRequest] WHERE [InitiatedChatRequestInitiatorChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	DELETE FROM [Chat_OnlineSupport] WHERE [ChatOnlineSupportChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	DELETE FROM [Chat_SupportCannedResponse] WHERE [ChatSupportCannedResponseChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	DELETE FROM [Chat_Message] WHERE [ChatMessageRecipientID] IN (SELECT ChatUserID FROM @ChatUsersToDelete) OR [ChatMessageUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	DELETE FROM [Chat_RoomUser] WHERE [ChatRoomUserChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	DELETE FROM [Chat_SupportTakenRoom] WHERE [ChatSupportTakenRoomChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	DELETE FROM [Chat_Notification] WHERE [ChatNotificationReceiverID] IN (SELECT ChatUserID FROM @ChatUsersToDelete) OR [ChatNotificationSenderID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)
	UPDATE [Chat_Room] SET [ChatRoomCreatedByChatUserID] = NULL WHERE [ChatRoomCreatedByChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)

	-- Delete users
	DELETE FROM [Chat_User] WHERE [ChatUserID] IN (SELECT ChatUserID FROM @ChatUsersToDelete)

	SET @UsersDeleted = @@ROWCOUNT

	SELECT @MessagesDeleted AS MessagesDeleted, @RoomsDeleted AS RoomsDeleted, @UsersDeleted AS UsersDeleted
END
GO

-- B6119 - [Marketing automation] - Missing automation actions in ribbon
UPDATE [CMS_Workflow] SET [WorkflowAllowedObjects] = N';om.contact;' WHERE [WorkflowType] = 3
GO

-- B6116 - [Web Analytics] - "mobile devices" section should be under section "visitors" not under "traffic sources"
DECLARE @parentPrefix VARCHAR(450);
DECLARE @parentID VARCHAR(450);

SET @parentID = (SELECT ElementID FROM CMS_UIElement WHERE ElementName = 'Visitors')
SET @parentPrefix = (SELECT ElementIDPath FROM CMS_UIElement WHERE ElementID = @parentID)

UPDATE CMS_UIElement SET ElementParentID = @parentID, ElementOrder = '5', ElementIDPath = @parentPrefix + SUBSTRING(ElementIDPath, LEN(ElementIDPath) - 8, LEN(ElementIDPath)) WHERE ElementParentID <> @parentID AND ElementName = 'crawler'
UPDATE CMS_UIElement SET ElementParentID = @parentID, ElementOrder = '6', ElementIDPath = @parentPrefix + SUBSTRING(ElementIDPath, LEN(ElementIDPath) - 8, LEN(ElementIDPath)) WHERE ElementParentID <> @parentID AND ElementName = 'MobileDevice'

GO

-- B6139 - [Lead Scoring] - Missing index causes performance problems
IF NOT EXISTS (SELECT name FROM sys.indexes WHERE name = 'IX_OM_ScoreContactRule_ScoreID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_OM_ScoreContactRule_ScoreID]
ON [OM_ScoreContactRule] ([ScoreID])
END
GO

IF NOT EXISTS (SELECT name FROM sys.indexes WHERE name = 'IX_OM_ScoreContactRule_RuleID')
BEGIN
CREATE NONCLUSTERED INDEX [IX_OM_ScoreContactRule_RuleID]
ON [OM_ScoreContactRule] ([RuleID])
END
GO

-- B6189 - [Web Analytics] - Settings for enabling web crawler tracking and mobile devices tracking were in wrong category
DECLARE @categoryID VARCHAR(450);
SET @categoryID = (SELECT TOP 1 CategoryID FROM CMS_SettingsCategory WHERE CategoryName = 'CMS.WebAnalytics.Visitors')
UPDATE CMS_SettingsKey SET KeyCategoryID = @categoryID WHERE (KeyName = 'CMSTrackMobileDevices' OR KeyName = 'CMSTrackSearchCrawlers') AND KeyCategoryID <> @categoryID
GO

-- B6239 - [ProjectManagement] - ProjectTaskDescription field missing in ProjectTaskListInfo
ALTER VIEW [View_PM_ProjectTaskStatus_Joined]
AS
SELECT        PM_ProjectTask.ProjectTaskID, PM_ProjectTask.ProjectTaskDisplayName, tblAssignee.FullName AS AssigneeFullName, 
                         tblAssignee.UserName AS AssigneeUserName, tblOwner.FullName AS OwnerFullName, tblOwner.UserName AS OwnerUserName, 
                         PM_ProjectTaskPriority.TaskPriorityDisplayName, PM_ProjectTaskStatus.TaskStatusDisplayName, PM_ProjectTask.ProjectTaskHours, 
                         PM_ProjectTask.ProjectTaskProgress, PM_ProjectTask.ProjectTaskProjectID, PM_ProjectTaskStatus.TaskStatusColor, 
                         PM_ProjectTask.ProjectTaskProjectOrder, PM_ProjectTask.ProjectTaskUserOrder, PM_ProjectTaskStatus.TaskStatusIcon, 
                         PM_ProjectTask.ProjectTaskAssignedToUserID, PM_ProjectTask.ProjectTaskOwnerID, PM_ProjectTask.ProjectTaskDeadline, 
                         PM_ProjectTask.ProjectTaskIsPrivate, PM_Project.ProjectDisplayName, PM_ProjectTaskStatus.TaskStatusIsFinished, 
                         PM_ProjectTaskPriority.TaskPriorityOrder, PM_Project.ProjectSiteID, PM_Project.ProjectOwner, PM_Project.ProjectGroupID, 
                         PM_Project.ProjectAccess, PM_Project.ProjectID, PM_ProjectTask.ProjectTaskDescription
FROM            PM_ProjectTask LEFT OUTER JOIN
                         PM_ProjectTaskStatus ON PM_ProjectTaskStatus.TaskStatusID = PM_ProjectTask.ProjectTaskStatusID LEFT OUTER JOIN
                         PM_ProjectTaskPriority ON PM_ProjectTask.ProjectTaskPriorityID = PM_ProjectTaskPriority.TaskPriorityID LEFT OUTER JOIN
                         PM_Project ON PM_ProjectTask.ProjectTaskProjectID = PM_Project.ProjectID LEFT OUTER JOIN
                         CMS_User AS tblAssignee ON PM_ProjectTask.ProjectTaskAssignedToUserID = tblAssignee.UserID LEFT OUTER JOIN
                         CMS_User AS tblOwner ON PM_ProjectTask.ProjectTaskOwnerID = tblOwner.UserID

GO

-- B6321 [DocumentAlias] - Inssuficion join where clause in select all query (same campaign name in different sites issue)
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 29
BEGIN
	UPDATE CMS_QUERY SET QueryText =
	'SELECT ##TOPN## ##COLUMNS## FROM CMS_DocumentAlias LEFT JOIN Analytics_Campaign ON AliasCampaign = CampaignName AND AliasSiteID = CampaignSiteID WHERE ##WHERE## ORDER BY ##ORDERBY##'
	WHERE QueryName = 'selectall' AND ClassID IN (SELECT ClassID FROM CMS_Class WHERE ClassName='CMS.DocumentAlias')
END
GO

-- B6351 CategoryInfoProvider.GetDocumentCategories(where, orderby, topn) method used badly formed query
UPDATE CMS_Query
SET QueryText = 
'WITH AllData (CategoryID, CategoryDisplayName, CategoryName, CategoryCount, CategoryNamePath, CategoryIDPath, CategoryUserID, CategorySiteID, CategoryParentID)
AS
(
SELECT CMS_Category.CategoryID, CMS_Category.CategoryDisplayName, CMS_Category.CategoryName, count(DocumentID) as CategoryCount, CMS_Category.CategoryNamePath, CMS_Category.CategoryIDPath, CMS_Category.CategoryUserID, CMS_Category.CategorySiteID, CMS_Category.CategoryParentID
FROM CMS_Category INNER JOIN CMS_DocumentCategory ON CMS_Category.CategoryID = CMS_DocumentCategory.CategoryID WHERE DocumentID IN (SELECT DocumentID FROM View_CMS_Tree_Joined WHERE ##WHERE##) 
GROUP BY CMS_Category.CategoryID, CMS_Category.CategoryDisplayName, CMS_Category.CategoryName, CMS_Category.CategoryNamePath, CMS_Category.CategoryIDPath, CMS_Category.CategoryUserID, CMS_Category.CategorySiteID, CMS_Category.CategoryParentID
)

SELECT ##TOPN## CategoryID, CategoryDisplayName, CategoryName, CategoryCount, CategoryNamePath, CategoryIDPath, CategoryUserID, CategorySiteID, CategoryParentID 
FROM AllData AS cats
WHERE NOT EXISTS (SELECT CategoryID FROM AllData WHERE CategoryParentID = cats.CategoryID)
ORDER BY ##ORDERBY##'
WHERE QueryName = N'selectDocumentsCategories' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'cms.category')
GO

/* ----------------------------------------------------------------------------*/
/* This SQL command must be at the end and must contain current hotfix version */
/* ----------------------------------------------------------------------------*/
UPDATE [CMS_SettingsKey] SET KeyValue = '34' WHERE KeyName = N'CMSHotfixVersion'
GO
